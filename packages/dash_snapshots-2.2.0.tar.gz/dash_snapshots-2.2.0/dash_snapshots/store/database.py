import os
import redis
import logging
from sqlalchemy import Column, Integer, String, LargeBinary, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import create_engine, exc
from sqlalchemy.orm import sessionmaker
import base64
import json
import textwrap
from dash_snapshots import constants
import re
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.schema import CreateTable
import sqlite3
from packaging import version

from future.moves.urllib.parse import urlparse

logging.basicConfig(level=os.environ.get("LOGLEVEL", "INFO"))
log = logging.getLogger("database")


# The following is a workaround until https://github.com/sqlalchemy/sqlalchemy/issues/4936
# and https://github.com/sqlalchemy/sqlalchemy/issues/2843 are fixed
# or when we move to Alembic to manage migrations
@compiles(CreateTable)
def compile_create_table_if_not_exists(element, ddlcompiler, **kw):
    default_create_ddl = ddlcompiler.visit_create_table(element, **kw)
    default_create_ddl = default_create_ddl.lstrip()
    create_if_not_exists = re.sub(
        r"^CREATE TABLE ", "CREATE TABLE IF NOT EXISTS ", default_create_ddl, flags=re.IGNORECASE
    )
    return create_if_not_exists


def get_tables(dialect, suffix=""):
    # Use a table suffix
    if suffix == "":
        table_suffix = ""
    else:
        table_suffix = "_" + suffix.lower()

    Base = declarative_base()
    BBase = declarative_base()

    # For SQLite
    class Blob(Base):
        __tablename__ = 'blob{}'.format(table_suffix)
        id = Column(Integer, primary_key=True)
        snapshot_id = Column(String(128), ForeignKey("snapshot{}.id".format(table_suffix), ondelete='cascade'))
        key = Column(String(128), nullable=False)
        blob = Column(LargeBinary)

        def __repr__(self):
            return '<Blob %r.%r>' % self.snapshot_id, self.key

    class Snapshot(Base):
        __tablename__ = 'snapshot{}'.format(table_suffix)
        id = Column(String(128), primary_key=True)
        meta = Column(JSON, nullable=False)

        def __repr__(self):
            return '<Snapshot %r>' % self.id

    # For POSTGRESQL
    class BBlob(BBase):
        __tablename__ = 'blob{}'.format(table_suffix)
        id = Column(Integer, primary_key=True)
        snapshot_id = Column(String(128), ForeignKey("snapshot{}.id".format(table_suffix), ondelete='cascade'))
        key = Column(String(128), nullable=False)
        blob = Column(LargeBinary)

        def __repr__(self):
            return '<Blob %r.%r>' % self.snapshot_id, self.key

    class BSnapshot(BBase):
        __tablename__ = 'snapshot{}'.format(table_suffix)
        id = Column(String(128), primary_key=True)
        meta = Column(JSONB, nullable=False)

        def __repr__(self):
            return '<Snapshot %r>' % self.id

    if dialect == "postgresql":
        return BBase, BSnapshot, BBlob
    if dialect == "sqlite":
        return Base, Snapshot, Blob


def get_dialect(uri):
    dialect = uri.split(":")[0]
    dialect = dialect.split('+')[0]
    if dialect not in ["postgres", "postgresql", "sqlite", "redis"]:
        raise Exception("The only databases supported are `postgres(ql)`, `sqlite` and `redis`")
    if dialect == "postgres":
        return "postgresql"
    return dialect


def is_sql_database(uri):
    dialect = get_dialect(uri)
    return dialect != "redis"


def coerce_database_url(uri):
    dialect = get_dialect(uri)
    try:
        driver = uri.split("://")[0].split("+")[1]
    except IndexError:
        if dialect == "postgresql":
            try:
                import psycopg2
                driver = "psycopg2"
            except ImportError:
                driver = "pg8000"
        else:
            driver = None

    dialect_driver = dialect
    if driver is not None:
        dialect_driver += "+%s" % driver

    if dialect == "redis" and os.environ.get("DASH_ENTERPRISE_ENV", "") == "WORKSPACE":
        # use the next database number
        p = urlparse(uri)
        if p.path == "" or p.path == "/":
            i = 0
        else:
            try:
                i = int(p.path[1:])
            except:
                raise Exception("Redis database should be a number")
        p = p._replace(path="/{}".format((i + 1) % 16))
        uri = p.geturl()

    return "%s://%s" % (dialect_driver, uri.split("://")[1])


def assert_sqlite_supports_json(session):
    # Check version
    required_version = "3.9.0"
    current_version = sqlite3.sqlite_version

    err_msg = """
        Your current version of SQLite (v%s) was not built with JSON support
        (a feature introduced in v%s).
        SQLite built with JSON support is included in official Python releases EXCEPT ON WINDOWS:
        The standard Windows Python distribution
        is not expected to include JSON support in SQLite until Python 3.9.
        Also, note that only relatively recent Python versions ship SQLite
        with JSON support on MacOS and Linux.
        For example, Python 3.6.2's version does not include JSON support but Python 3.6.10's
        version does.
        To get an upgraded version of SQLite that supports JSON, you will need to upgrade your Python version.
        Alternatively, you can save your snapshots to an external Postgres or Redis database by setting
        the `database_url` argument or environment variable.
    """ % (current_version, required_version)
    err_msg = textwrap.dedent(err_msg).replace("\n", " ")

    if version.parse(current_version) <= version.parse(required_version):
        raise Exception(err_msg)

    # Check JSON extension is loaded
    try:
        session.execute("SELECT json_object('ex','[52,3.14159]');")
    except exc.OperationalError:
        raise Exception(err_msg)


def _commitSessionOrRollback(session):
    try:
        session.commit()
    except exc.IntegrityError:
        session.rollback()
        raise


def save_blob(session, schema, snapshot_id, key, data):
    if isinstance(data, (bytes, bytearray)):
        blob = data
    else:
        blob = bytearray(data, encoding='utf8')

    existing_blob = session.query(schema).filter_by(snapshot_id=snapshot_id, key=key).one_or_none()
    if existing_blob is None:
        record = schema(snapshot_id=snapshot_id, key=key, blob=blob)
        session.add(record)
    else:
        existing_blob.blob = blob
    _commitSessionOrRollback(session)


def migrate_from_redis_v0():
    database_url = os.environ.get("SNAPSHOT_DATABASE_URL", False)
    if not database_url:
        msg = """
            SNAPSHOT_DATABASE_URL is not in the env.

            The migration needs to know where to insert the data.
            The typtical form of a database URL is: `dialect://username:password@host:port/database`
        """
        raise Exception(textwrap.dedent(msg))
    dialect = get_dialect(database_url)
    if not is_sql_database(database_url):
        raise Exception("The target database is not a supported SQL database")
    database_url = coerce_database_url(database_url)
    engine = create_engine(database_url)

    base, snapshotSchema, blobSchema = get_tables(dialect)

    base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()

    log.info("Running database migration")
    redisClient = redis.StrictRedis.from_url(
        os.environ.get("REDIS_URL", "redis://127.0.0.1:6379"),
        decode_responses=True,
    )
    ids = redisClient.zrevrange(constants.KEYS["snapshot-list"], 0, -1)
    number_of_skips, number_of_hits = 0, 0
    for id in ids:
        if redisClient.sismember(constants.KEYS["migrated-snapshots"], id):
            log.info("[HIT] snapshot %s: already migrated" % id)
            number_of_hits += 1
            continue
        log.info("Migrating snapshot %s" % id)
        meta = redisClient.hgetall("%s.meta" % id)

        # Every value is JSON encoded so let's decode
        for k, v in meta.items():
            meta[k] = json.loads(v)

        # Check if snapshot has a schema version
        schema = meta.pop('schema', 'v0')
        if schema != 'v0':
            log.info("[SKIP] snapshot %s: only schema version 'v0' are supported" % id)
            number_of_skips += 1
            continue

        # Check if a PDF was generated
        pdf = meta.pop('pdf', None)

        # Parse created_time
        timestamp = redisClient.zscore(constants.KEYS["snapshot-list"], id)
        meta["_created_time"] = timestamp

        # Save snapshot
        snap = snapshotSchema(id=id, meta=meta)
        session.add(snap)
        _commitSessionOrRollback(session)

        if pdf is not None:
            pdf_base64 = redisClient.hget(id, constants.KEYS["pdf"])
            # The PDF binary is stored in base64
            blob = base64.b64decode(pdf_base64)
            save_blob(session, blobSchema, id, constants.KEYS["pdf"], blob)

        data = redisClient.hget(id, constants.KEYS["layout-json"])
        save_blob(session, blobSchema, id, constants.KEYS["layout-json"], data)

        redisClient.sadd(constants.KEYS["migrated-snapshots"], id)

    log.info("Done migrating %d snapshots (%d skipped, %d already migrated)" % (len(ids), number_of_skips, number_of_hits))
