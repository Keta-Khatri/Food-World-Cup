import jwt
import os


def get_relative_path(requests_pathname, path):
    if requests_pathname == "/" and path == "":
        return "/"
    elif requests_pathname != "/" and path == "":
        return requests_pathname
    elif not path.startswith("/"):
        raise Exception(
            "Paths that aren't prefixed with a leading / are not supported.\n"
            + "You supplied: {}".format(path)
        )
    return "/".join([requests_pathname.rstrip("/"), path.lstrip("/")])


def create_token(payload):
    encoded_jwt = jwt.encode(
        payload,
        os.environ.get("DASH_SECRET_KEY"),
        algorithm='HS256'
    )
    return encoded_jwt.decode("utf-8") if isinstance(encoded_jwt, bytes) else encoded_jwt
