from retrying import retry
import requests
import os
import json
from . import constants
import subprocess
from builtins import bytes
from ._utils import create_token
PRINT_TO_PDF_EXECUTABLE_PATH = os.environ.get("PRINT_TO_PDF_EXECUTABLE_PATH", "print-to-pdf")


@retry(stop_max_attempt_number=5, wait_fixed=500)
def _save_pdf(
    username,
    relpath,
    store,
    snapshot_id,
    embedded,
    page_size="Letter",
    orientation="portrait",
    wait=20,
    margins=False,
    ignore_wait_exception=False,
    ssl_verify=None,
    pdf_url=None
):
    # TODO - Assuming that the app url is /{snapshot_id}

    # check to see if ssl verification is disabled in an env var
    if ssl_verify is None:
        ssl_verify = (os.getenv('PDF_SSL_VERIFY', 'true') == 'true')

    # PDF saving is only available if the app is deployed on DDS
    if (not pdf_url) and ("DASH_URL" not in os.environ) and ("DASH_APP_NAME" not in os.environ):
        return

    if orientation not in ["portrait", "landscape"]:
        raise Exception(
            "orientation must be landscape or portrait, "
            + "you supplied {}".format(orientation)
        )

    if isinstance(wait, (int, float)) and wait >= 30 and not ignore_wait_exception:
        raise Exception(
            "The wait time you supplied ({}) ".format(wait)
            + "was greater than 30. "
            + "By default, the PDF generation times out after 30 seconds "
            + "(for performance reasons). This can be increased in the "
            + "Dash Enterprise admin panel. If you increase this, "
            + "you can ignore this message with `ignore_wait_exception=True`"
        )

    if page_size not in [
        "Letter",
        "A3",
        "A4",
        "A5",
        "Legal",
        "Tabloid",
    ] and not isinstance(page_size, dict):
        raise Exception(
            'page_size must be one of "Letter", "A3", "A4", "A5", "Legal", "Tabloid", '
            + 'or a dict with shape {"width": ..., "height": ...} where width and height'
            + " are integers specified in microns.\n"
            + "You supplied {}".format(page_size)
        )

    if isinstance(page_size, dict) and (
            not isinstance(page_size.get("width", None), (int, float))
            or not isinstance(page_size.get("height", None), (int, float))
    ):
        raise Exception(
            'page_size must be one of "Letter", "A3", "A4", "A5", "Legal", "Tabloid", '
            + 'or a dict with shape {"width": ..., "height": ...} where width and height'
            + " are integers specified in microns.\n"
            + "You supplied {}".format(page_size)
        )

    # The following environment variables prefixed by DASH
    # are supplied automatically by Dash Enterprise.
    # Users should not have to set any of them manually.
    # Only the integration test suite changes those.
    if pdf_url:
        dash_url = pdf_url
    else:
        dash_url = os.environ.get("DASH_URL", "https://{domain}/{app}/{snapshot_id}?print=true")

    # Request payload is compatible with DDS/Orca release 3.2.3.
    request_payload = {
        "pdf_options": {
            "marginsType": 1 if not margins else 0,
            "landscape": (orientation == "landscape"),
        },
        "appname": os.environ.get("DASH_APP_NAME"),
        "secret_key": os.environ.get("DASH_SECRET_KEY"),
        "url": dash_url.format(
            domain=os.environ.get("DASH_DOMAIN_BASE", ""),
            app=os.environ.get("DASH_APP_NAME", ""),
            snapshot_id=snapshot_id,
        )
    }

    # The following handling of page_size is necessary for compatibility with DDS/Orca release 3.2.3.
    if isinstance(page_size, str):
        request_payload["pdf_options"]["pageSize"] = page_size
    else:
        # customized page size dict {width:, height:}
        request_payload["page_size"] = page_size

    if isinstance(wait, (int, float)):
        request_payload["wait_time"] = wait
        request_payload["timeout"] = wait
    else:
        request_payload["wait_selector"] = wait
        request_payload["selector"] = wait

    # Create PDF
    if "PRINT_TO_PDF_ORCA" in os.environ:
        # Overriding env var PDF_API_URL is only useful for testing.
        # Users should not have to set it manually
        pdf_api_url = os.environ.get("PDF_API_URL", "https://{}/Manager/api/generate_report")
        res = requests.post(
            pdf_api_url.format(
                os.environ.get("DASH_DOMAIN_BASE", "")
            ),
            headers={
                "content-type": "application/json",
                "plotly-client-platform": "dash-snapshots",
            },
            data=json.dumps(request_payload),
            verify=ssl_verify,
        )

        if res.status_code != 200:
            print(res.content)
            raise Exception(
                "PDF generation failed with status code {}".format(res.status_code)
            )
        pdf_output = res.content
    else:
        if "DASH_APP_NAME" in os.environ:
            if os.environ.get("DASH_ENTERPRISE_ENV", "") == "WORKSPACE":
                # In workspace, connect to app locally
                dash_url = "http://127.0.0.1:8050" + relpath("/{snapshot_id}?print=true")
                request_payload["url"] = dash_url.format(
                    snapshot_id=snapshot_id,
                )
            # Checks whether the app is running on DE5
            elif (
                os.environ.get("DASH_APP_INTERNAL_HOST") and
                os.environ.get("PORT")
            ):
                dash_url = "http://{}:{}{}".format(
                    os.environ.get("DASH_APP_INTERNAL_HOST"),
                    os.environ.get("PORT"),
                    relpath("/{snapshot_id}?print=true")
                )
                request_payload["url"] = dash_url.format(
                    snapshot_id=snapshot_id
                )
            else:
                # Retrieve internal URL
                res = requests.post(
                    "https://{}/Manager/api/get_internal_address".format(os.environ.get("DASH_DOMAIN_BASE", "")),
                    headers={
                        "content-type": "application/json",
                        "plotly-client-platform": "dash-snapshots",
                    },
                    data=json.dumps(request_payload),
                    verify=ssl_verify
                )
                if res.status_code != 200:
                    print(res.content)
                    raise Exception("Retrieval of internal URL failed with status code {}".format(res.status_code))
                # Use internal URL for the request
                request_payload["url"] = res.json()["url"]

        # Set extra HTTP headers
        request_payload["http_headers"] = {}

        # If embedded, supply JWT authorization
        if embedded:
            request_payload["http_headers"]["Plotly-User-Agent"] = "SNAPSHOT-ENGINE"
            jwt = create_token({"username": username, "from": "SNAPSHOT-ENGINE"})
            request_payload["http_headers"]["Authorization"] = "Bearer " + jwt

        # Add HTTP header for authentication
        request_payload["http_headers"]["Plotly-User-Data"] = json.dumps({"username": username})

        # Create PDF via subprocess
        process = subprocess.Popen(
            PRINT_TO_PDF_EXECUTABLE_PATH,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            shell=True
        )

        # Launch the shell command:
        request_payload = bytes(json.dumps(request_payload), 'utf-8')
        output, error = process.communicate(input=request_payload)
        if process.returncode != 0:
            print(error)
            raise Exception(
                "PDF generation failed with status code {}".format(process.returncode)
            )
        pdf_output = output

    store._save_blob(snapshot_id, constants.KEYS["pdf"], pdf_output)
