import dash_enterprise_auth


def get_current_username(snap=None):
    if snap is not None and hasattr(snap, "context"):
        username = snap.context["username"]
    else:
        try:
            username = dash_enterprise_auth.get_username()
        except:
            # When the snapshot is generated on a schedule,
            # the request context won't be available and
            # therefore there won't be a username available
            # TODO - What should we save the username as?
            # Should we make this configurable?
            username = "Scheduler"

        # When developing locally, username will be None
        if username is None:
            username = "Anonymous"

    return username
