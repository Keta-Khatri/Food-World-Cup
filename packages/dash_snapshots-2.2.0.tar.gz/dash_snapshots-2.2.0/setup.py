import os
from setuptools import setup

ns = {}
exec(open(os.path.join(
    "dash_snapshots",
    "_version.py"
)).read(), ns)

setup(
    name='dash_snapshots',
    license='Commercial',
    version=ns['version'],
    author='Chris Parmer',
    author_email='chris@plotly.com',
    packages=[
        'dash_snapshots',
        'dash_snapshots.store',
        'dash_snapshots.server'
    ],
    scripts=['dash_snapshots/bin/dash-snapshots-migrate-from-redis'],
    install_requires=[
        'redis>=3.5.*,<4',
        'celery[redis]==5.*',
        'dash',
        'dash-enterprise-auth',
        'future==0.*',
        'requests[security]==2.*',
        'requests==2.*',
        'sqlalchemy>=1.3.*,<2',
        'Flask-SQLAlchemy==2.*',
        'pg8000>=1.12.*,<2',
        'packaging==20.*',
        'retrying==1.*',
        'cryptography<3.4;python_version<"3.7"',
        'PyJWT>=1.*,<3'
    ],
    include_package_data=True,
)
