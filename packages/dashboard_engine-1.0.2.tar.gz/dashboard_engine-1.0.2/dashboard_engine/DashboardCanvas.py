# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DashboardCanvas(Component):
    """A DashboardCanvas component.
The Dashboard Canvas is the primary component in Dashboard Engine. This
component is meant to be created via the
`DashboardEngine.make_state_and_canvas()` function, rather than directly. The
`arrangement` property of this component is the key for capturing dashboard
layouts in callbacks.

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The children of this component.

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- arrangement (dict; default {    grid: {lg: []},}):
    The arrangement for the children.

- editable (boolean; default False):
    Whether the canvas is editable or not.

- inspect_n_clicks (number; default 0):
    The number of times the inspect button has been clicked.

- inspectable (boolean; default True):
    Whether the inspect button appears or not.

- selected_children (number; default -1):
    The element being edited."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, editable=Component.UNDEFINED, arrangement=Component.UNDEFINED, selected_children=Component.UNDEFINED, inspectable=Component.UNDEFINED, inspect_n_clicks=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'arrangement', 'editable', 'inspect_n_clicks', 'inspectable', 'selected_children']
        self._type = 'DashboardCanvas'
        self._namespace = 'dashboard_engine'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'arrangement', 'editable', 'inspect_n_clicks', 'inspectable', 'selected_children']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(DashboardCanvas, self).__init__(children=children, **args)
