from typing import Any, Optional

from .connections._helpers import (
    aggfuncs,
    weighted_aggfuncs,
    groupfuncs,
    virtual_column_name,
)

from abc import ABC, abstractmethod

select_funcs = aggfuncs + weighted_aggfuncs
group_by_funcs = list(groupfuncs.keys()) + ["none"]


class DotDict(dict):
    """dot.notation access to dictionary attributes"""

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    # this getattr allows us to pickle
    def __getattr__(self, attr):
        if attr.startswith("__"):
            raise AttributeError
        return self.get(attr, None)


class Select(DotDict):
    function: Any
    args: Any
    key: Any


class Filter(ABC, DotDict):
    type: Any
    target: Any

    @abstractmethod
    def get_values(self):
        pass


class RangeFilter(Filter):
    range: Any

    def get_values(self):
        return self.type, self.target, self.range


class PointFilter(Filter):
    values: Any

    def get_values(self):
        return self.type, self.target, self.values


class GroupBy(DotDict):
    function: Any
    args: Any
    key: Any


class InfIter:
    def __iter__(self):
        self.num = 0
        return self

    def __next__(self):
        num = self.num
        self.num += 1
        return num


query_id = iter(InfIter())


class RasterizationOptions(DotDict):
    plot_width: int
    plot_height: int
    x_column: str
    y_column: str
    color: Optional[str]

    def __init__(
        self,
        *,
        plot_width,
        plot_height,
        x_column,
        y_column,
        color=None,
        x_limits=None,
        y_limits=None,
    ):
        self.plot_width = plot_width
        self.plot_height = plot_height
        self.x_column = x_column
        self.y_column = y_column
        self.color = color
        self.x_limits = x_limits
        self.y_limits = y_limits


class Query:
    """A data query that can be fulfilled by a connection"""

    def __init__(
        self,
        columns=[],
        crossfilters=[],
        filters=[],
        order_by=[],
        limit=-1,
        offset=0,
        crossfilter_mask_key=None,
        exclude_filtering_group=None,
        rasterization={},
    ):
        """Create an instance of Query

        Args:
            columns: list of dicts (each with the following items):
                1. function:[str]: aggregation method one of (selection functions
                   %s or aggregation functions %s)
                2. args[str|tuple|dict]: function arguments
                3. key[str]: used to look up column names in the query result
            crossfilters (list of dict): list of filter conditions that apply to
                other queries. Conditions can either be a "range" or "points".
            filters (list of dict): list of filter conditions that apply to
                this query. Conditions can either be a "range" or "points".
            order_by (list of tuple): order rows according to tuple's elements:
                1. column name (str): the name of the column used for ordering
                2. order (str): "asc" for ascending or "desc" for descending
            limit (int): number of rows to return. Defaults to -1 for an
                unlimited number of rows.
            offset (int): number of rows to skip before beginning to return the rows.
                Default to 0.
            crossfilter_mask_key (str): key for column which will contain a boolean mask
                representing which rows of the data frame match the crossfilters clause
                of the Query. Setting this variable causes extra commputation
                so leave it unset unless the mask is needed.

        """ % (
            ",".join(select_funcs),
            ",".join(group_by_funcs),
        )

        self._id = next(query_id)
        self._group_by = []
        self._select = []
        self._keys = []

        if exclude_filtering_group is None:
            self.exclude_filtering_group = []
        else:
            self.exclude_filtering_group = exclude_filtering_group

        for col in columns:
            if col:
                func = col.get("function")
                if func in select_funcs:
                    self._add_col(Select(col), "select")
                elif func in group_by_funcs:
                    self._add_col(GroupBy(col), "group_by")
                else:
                    raise ValueError(f"Unknown function '{func}' in columns")

        self.crossfilters = []
        for w in crossfilters:
            if w.get("type") == "range":
                self.crossfilters.append(RangeFilter(w))
            elif w.get("type") == "points":
                self.crossfilters.append(PointFilter(w))
            else:
                raise ValueError("crossfilters is does not have a valid type")

        self.filters = filters
        self.limit = limit
        self.order_by = order_by
        self.offset = offset
        self.crossfilter_mask_key = crossfilter_mask_key
        self.rasterization = (
            RasterizationOptions(**rasterization) if rasterization else None
        )

    @property
    def id(self):
        return self._id

    def _add_col(self, col, col_type):
        # validation
        # TODO: fk: this can be done at the class level
        assert set(["function", "args", "key"]) == set(
            col.keys()
        ), "select and group_by must have keys function, args, key"

        key = col.get("key", None)
        if key and key in self._keys:
            raise ValueError("Key '%s' already used" % key)
        self._keys.append(key)

        func = col.get("function")
        if col_type == "select":
            if func not in select_funcs:
                raise ValueError(f"Unknown function '{func}' in select")
            self._select.append(col)
        else:
            if func not in group_by_funcs:
                raise ValueError(f"Unknown function '{func}' in group_by")
            self._group_by.append(col)

    @property
    def group_by(self):
        return [
            (groupby.function, groupby.args, groupby.key) for groupby in self._group_by
        ]

    @property
    def select(self):
        return [(select.function, select.args, select.key) for select in self._select]

    def crossfilter_values(self):
        return [crossfilters.get_values() for crossfilters in self.crossfilters]

    def is_nop(self):
        return (
            len(self.crossfilters) == 0
            and len(self._group_by) == 0
            and len(self._select) == 0
        )

    def __repr__(self):
        items = ("\t%s=%r" % (k, v) for k, v in self.__dict__.items())
        return "%s(\n {%s}\n)" % (self.__class__.__name__, ",\n".join(items))


class QueryResult:
    """The result of a data query that can be fulfilled by a connection"""

    def __init__(
        self,
        element_df,
        key_to_label,
        order_for_category,
        colormap_for_category,
        data_schema,
        rasterized_array=None,
        query=None,
    ):
        """Construct a QueryResult

        Args:
            element_df (Pandas DataFrame): the result of the corresponding
                Query
            key_to_label (dict): mapping of keys from Query to columns
                in data frame
            order_for_category (function): function returning stable order of
                categorical values for this dataset
            colormap_for_category (function): function returning stable color
                mapping for categorical values for this dataset
        """

        self._df = element_df
        self._key_to_label = key_to_label
        self.order_for_category = order_for_category
        self.colormap_for_category = colormap_for_category
        self._xr = rasterized_array
        self._query = query
        self.data_schema = data_schema
        self.theme = None

    @property
    def rasterized_array(self):
        return self._xr

    @property
    def df(self):
        if self._df is None:
            return None
        df = self._df
        for key, label in self._key_to_label.items():
            if label not in df.columns:
                # a previous key already renamed this label
                # need to get a copy of the original column
                df[key] = self._df[label]
            else:
                df = df.rename({label: key}, axis=1, copy=False)
        return df

    def is_empty(self):
        return (self.df is None or len(self.df) == 0) and (
            self.rasterized_array is None
        )

    def _is_categorical(self, cat):  # lifted from PX
        if (
            self._df is None
            and self._xr is not None
            and cat is not None
            and cat == self._xr.color
        ):
            return True

        if self._df is None or cat is None or cat not in self._df.columns:
            return False

        return self._df[cat].dtype.kind not in "ifc"

    def make_category_orders(self, cats):
        cat_orders = {}

        for key, cat in cats.items():
            if self._query:
                for s_func, s_args, s_key in self._query.group_by:
                    if s_key == key:
                        if s_func == "top_n":
                            cat = virtual_column_name(
                                "top_n",
                                [
                                    s_args["n"],
                                    s_args["base_column"],
                                    s_args["sort_order"],
                                    s_args["include_others"],
                                ],
                            )
                            # there can only be one groupby for the one key
                            break
            if self._is_categorical(cat):
                existing_orders = self.order_for_category(cat)
                return_orders = list(self._df[cat].unique())

                if not existing_orders:
                    cat_orders[key] = [x for x in return_orders if x != "OTHER"]
                    if len(return_orders) > len(cat_orders[key]):
                        cat_orders[key].append("OTHER")
                else:
                    cat_orders[key] = [x for x in existing_orders if x in return_orders]
                    diff_rem = list(set(return_orders) - set(existing_orders))
                    if diff_rem:
                        import pandas as pd

                        if len(diff_rem) == 1 and (
                            pd.isna(diff_rem[0]) or diff_rem[0] == " "
                        ):
                            cat_orders[key].append(" ")
                        else:
                            cat_orders[key].append("OTHER")

        return cat_orders

    def make_color_map(self, cat_key, cat_value, color_type=None):
        base_column = cat_value
        found = False
        if self._query:
            for s_func, s_args, s_key in self._query.group_by:
                if s_key == cat_key:
                    if s_func == "top_n":
                        base_column = s_args["base_column"]
                        vcat = virtual_column_name(
                            "top_n",
                            [
                                s_args["n"],
                                s_args["base_column"],
                                s_args["sort_order"],
                                s_args["include_others"],
                            ],
                        )
                        # there can only be one groupby for the one key
                        found = True
                        break

        if not self._is_categorical(vcat if found else base_column):
            return None

        return self.colormap_for_category(
            base_column, self.theme, color_type=color_type
        )

    def get_colorscale(self, color_type=None):
        # a theme should always be present
        return self.theme.get_colorscale(color_type)
