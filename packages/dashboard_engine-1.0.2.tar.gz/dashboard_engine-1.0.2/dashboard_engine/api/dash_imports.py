import dash

if hasattr(dash, "dcc"):
    dcc = dash.dcc
else:
    import dash_core_components as dcc

if hasattr(dash, "html"):
    html = dash.html
else:
    import dash_html_components as html

if hasattr(dash, "dash_table"):
    dash_table = dash.dash_table
    from dash.dash_table.Format import Format, Scheme
else:
    import dash_table  # noqa: F401
    from dash_table.Format import Format, Scheme

import dash_design_kit as ddk
import dash_enterprise_auth as auth

__all__ = ["dash", "dcc", "html", "ddk", "auth", "dash_table", "Format", "Scheme"]
