import plotly.express.data as data
import pandas as pd


def world_bank():
    df = data.gapminder(pretty_names=True, centroids=True)
    df["Reporting Date"] = pd.to_datetime(df["Year"].astype(str) + "-01-01")
    df["Pre-1980"] = df["Year"].apply(lambda x: "Yes" if x < 1980 else "No")
    return df


def restaurant_bills(pretty_names=True):
    df = data.tips(pretty_names=pretty_names)
    return df


def tech_stocks():
    df = data.stocks(datetimes=True).melt(id_vars="date")
    df = df.rename(dict(variable="Ticker", value="Change", date="Date"), axis=1)
    return df


def carshare():
    return data.carshare()
