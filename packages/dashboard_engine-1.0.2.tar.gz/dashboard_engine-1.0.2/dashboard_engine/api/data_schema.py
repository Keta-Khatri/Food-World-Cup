from enum import Enum
import pandas as pd
import datetime

import functools
import numpy as np

DATE_TYPES = [
    "datetime64[{unit}]".format(unit=unit)
    for unit in ["Y", "M", "W", "D", "h", "m", "s", "ms", "us", "ns", "ps", "fs", "as"]
]

NUMERIC_TYPES = [
    "uint8",
    "uint16",
    "uint32",
    "uint64",
    "int8",
    "int16",
    "int32",
    "int64",
    "float16",
    "float32",
    "float64",
    "float128",
    "complex64",
    "complex128",
    "complex256",
    # A few extension types
    "UInt8",
    "UInt16",
    "UInt32",
    "UInt64",
    "Int8",
    "Int16",
    "Int32",
    "Int64",
]


class DeltaPeriodTypes(Enum):
    year = "timedelta64[Y]"
    month = "timedelta64[M]"
    day = "timedelta64[D]"
    hour = "timedelta64[h]"
    minute = "timedelta64[m]"
    second = "timedelta64[s]"


# date_part_extractor's "date part" argument with more user-friendly keys
# TODO: exludes named date parts until sorting of dates has been figured out
DatePartInfo = {
    "Month number": {
        "date_part": "month",  # the month of the year as a number (1-12)
        "cardinality": 12,
        "unit": DeltaPeriodTypes.month.value,
    },
    "Day of month number": {
        "date_part": "dayofmonth",
        "cardinality": 31,
        "unit": DeltaPeriodTypes.day.value,
    },
    "Day of week number": {
        "date_part": "dayofweek",  # the day of the week as a number (0-6)
        "cardinality": 7,
        "unit": DeltaPeriodTypes.day.value,
    },
    "Hour number": {
        "date_part": "hour",
        "cardinality": 24,
        "unit": DeltaPeriodTypes.hour.value,
    },
    "Minute number": {
        "date_part": "minute",
        "cardinality": 60,
        "unit": DeltaPeriodTypes.minute.value,
    },
    "Second number": {
        "date_part": "second",
        "cardinality": 60,
        "unit": DeltaPeriodTypes.second.value,
    },
}

DateParts = {k: v["date_part"] for k, v in DatePartInfo.items()}

# The maximum number of unique values a date part can take on, e.g., "day of
# week" can take on 7 unique values.
DatePartCardinality = {k: v["cardinality"] for k, v in DatePartInfo.items()}

DatePartUnit = {k: v["unit"] for k, v in DatePartInfo.items()}


def _timedelta_to_numpy(timedelta):
    if isinstance(timedelta, pd._libs.tslibs.timedeltas.Timedelta):
        return timedelta.to_numpy()
    elif isinstance(timedelta, datetime.timedelta):
        return np.array([timedelta], dtype="timedelta64")
    return timedelta


def number_of_periods_in_timedelta(timedelta, period):
    timedelta = _timedelta_to_numpy(timedelta)
    return timedelta.astype(period).astype("int")


def dateparts_in_timedelta(timedelta, datepart):
    return min(
        number_of_periods_in_timedelta(timedelta, DatePartUnit[datepart]),
        DatePartCardinality[datepart],
    )


def deltaperiods_in_date_range(mindate, maxdate):
    timedelta = maxdate - mindate
    return {
        period.name: number_of_periods_in_timedelta(timedelta, period.value)
        for period in list(DeltaPeriodTypes)
    }


def dateparts_in_date_range(mindate, maxdate):
    timedelta = maxdate - mindate
    return {k: dateparts_in_timedelta(timedelta, k) for k in DateParts.keys()}


class DataSchema:
    def __init__(self, df, cache=None):
        self._df = df
        self._data_schema: dict[str, dict] = {
            k: {"dtype": str(v)} for k, v in self._df.dtypes.items()
        }

    def all(self):
        return self._exclude([])

    def numeric(self):
        return self.include_types(NUMERIC_TYPES)

    def dates(self):
        return self.include_types(DATE_TYPES)

    def non_numeric(self):
        return self._exclude(self.numeric())

    def discrete(self):
        return self.exclude_types(NUMERIC_TYPES + DATE_TYPES)

    def cardinality(self, col):
        if "cardinality" not in self._data_schema[col]:
            self._data_schema[col]["cardinality"] = self._df[col].nunique()

        return self._data_schema[col].get("cardinality")

    def include_types(self, types):
        return [
            col
            for col, meta in self._data_schema.items()
            if meta.get("dtype", None) in types
        ]

    def exclude_types(self, types):
        return self._exclude(self.include_types(types))

    def _exclude(self, to_exclude):
        return [col for col in self._data_schema if col not in to_exclude]

    def first_value(self, col):
        # TODO: remove this when the self._order_cache is lifted
        # to ConnecctionProvider

        if "first" not in self._data_schema[col]:

            def cmp_func(x, y):
                if pd.isna(x) or y == "OTHER":
                    return 1
                elif pd.isna(y) or x == "OTHER":
                    return -1

                if x < y:
                    return -1
                elif x == y:
                    return 0
                elif x > y:
                    return 1

            sorted_values = sorted(
                [c for c in self._df[col].unique() if c is not None],
                key=functools.cmp_to_key(cmp_func),
            )

            self._data_schema[col]["first"] = sorted_values[0]

        return self._data_schema[col].get("first")

    def is_discrete(self, col):
        return not self.is_continuous(col)

    def is_continuous(self, col):
        return self.is_numeric(col) or self.is_date(col)

    def is_numeric(self, col):
        return self._data_schema[col]["dtype"] in NUMERIC_TYPES

    def is_date(self, col):
        return self._data_schema[col]["dtype"] in DATE_TYPES

    def min_value(self, col):
        if not self.is_continuous(col):
            return None

        if "min" not in self._data_schema[col]:
            min_val = self._df[col].min()
            if isinstance(min_val, np.ndarray):
                if min_val.dtype != "<M8[ns]":
                    min_val = min_val.item()

            self._data_schema[col]["min"] = min_val

        return self._data_schema[col]["min"]

    def max_value(self, col):
        if not self.is_continuous(col):
            return None

        if "max" not in self._data_schema[col]:
            max_val = self._df[col].max()
            if isinstance(max_val, np.ndarray):
                if max_val.dtype != "<M8[ns]":
                    max_val = max_val.item()

            self._data_schema[col]["max"] = max_val

        return self._data_schema[col]["max"]

    def datebinned_cardinality(self, col, bin_size):
        if not self.is_date(col):
            return None

        if "datebinned_cardinality" not in self._data_schema[col]:
            c = dict(
                **deltaperiods_in_date_range(self.min_value(col), self.max_value(col)),
                **dateparts_in_date_range(self.min_value(col), self.max_value(col))
            )
            self._data_schema[col]["datebinned_cardinality"] = c

        return self._data_schema[col]["datebinned_cardinality"][bin_size]
