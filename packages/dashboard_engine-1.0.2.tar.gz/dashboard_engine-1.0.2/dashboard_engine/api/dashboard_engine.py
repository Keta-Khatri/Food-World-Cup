import itertools
import morph
import json
import logging
from functools import reduce

from .dash_imports import dash, dcc, html, ddk, auth
from dash.dependencies import Input, Output, ALL, MATCH, State

import dashboard_engine
from .elements import builtin_elements
from .canvas_config import CanvasConfig
from .dx_helpers import CodeDisplayModal

from .timer import Timer
from flask_request_id import RequestID

from textwrap import dedent

from .query import Query, QueryResult
from .theme import Theme, default_theme


HANDLER_SEPARATOR = "_"
HANDLER_SCOPES = ["editor", ""]


def _inflate_query_results(query_results, original_struct) -> "list[list]":
    """
    query_results is a flat list but multiple adjacent queries might belong to
    the same element, so we use the lengths of the lists in original_struct to
    associate multiple query_results with the same element.
    """
    sizes = list(map(lambda x: len(x), original_struct))
    inflated_result = []
    sum_size = 0
    for size in sizes:
        sum_size += size
        inflated_result.append(query_results[sum_size - size : sum_size])
    return inflated_result


def _query_data(connection, conn_queries, elem_queries_struct):
    query_results: list = connection._execute_queries(conn_queries)
    query_results = _inflate_query_results(query_results, elem_queries_struct)
    return query_results


def _build_queries(element_types, elements, extract_crossfilters=False):
    """
    Build selection queries. element_types is a dict containing keys that are
    stringified class identifiers created with _get_element_type_from_class and
    the values are classes corresponding to the elements on the canvas. elements
    are dicts containing the state of the elements on the canvas.
    extract_crossfilters, if True, will extract all the "crossfilters clauses"
    from the list of SelectionQueries given by the elements on the page and make
    a single Query using the concatenation of these "crossfilters clauses". This
    can be used to speed up queries where a final query simply groups by some
    columns. See DashboardEngine.query for an example where it is used.
    """
    conn_queries = []
    elem_queries_struct: list[list] = []
    for i, element in enumerate(elements):
        element_type = element.get("type", "_blank")
        if element_type == "_blank" or element_has_error(element):
            conn_queries.append(None)
            elem_queries_struct.append([None])
            continue

        cls = element_types[element_type]
        query_generator = getattr(cls, "get_queries", None)

        if callable(query_generator):
            query_list = query_generator(element)

            if isinstance(query_list, list):
                for sq in query_list:
                    if sq and sq.is_nop():
                        sq = None
                    conn_queries.append(sq)

                elem_queries_struct.append(query_list)
            else:
                raise ValueError("Selection Query should be a list")
        else:
            conn_queries.append(None)
            elem_queries_struct.append([None])
    if extract_crossfilters:
        crossfilters = reduce(
            lambda x, y: x + y,
            [
                sq.crossfilters
                if sq is not None and sq.crossfilters is not None
                else []
                for sq in conn_queries
            ],
            [],
        )
        sq = Query(crossfilters=crossfilters, crossfilter_mask_key="crossfilter_mask")
        conn_queries = [sq]
        elem_queries_struct = [[sq]]
    return (conn_queries, elem_queries_struct)


def _do_query(
    element_types, connection, elements, extra_queries=[], extract_crossfilters=False
):
    with Timer("render", "build_queries"):
        (conn_queries, elem_queries_struct,) = _build_queries(
            element_types, elements, extract_crossfilters=extract_crossfilters
        )

    for q in extra_queries:
        conn_queries += q
        elem_queries_struct.append(q)

    # Load data
    with Timer("render", "query_data"):
        query_results = _query_data(connection, conn_queries, elem_queries_struct)
    return query_results


class DashboardEngine:
    """
    An object linked to a Dash app instance and a Connection Provider for
    generating dashboards.

    Arguments:
      - `app`: A Dash app instance
      - `connection_provider`: A DBE connection provider
      - `element_types`: Optional; A list of element classes. It defaults to an
            official set of elements.
      - `id`: Optional; A unique identifier in order to properly support
            multiple independent instances of DashboardEngine.
      - `theme`: Optional; a Dash Design Kit theme object. When this parameter
        is used, all elements use server-determined color information and so no
        longer respond to changes to the Dash Design Kit Theme Editor UI.
    """

    def __init__(
        self,
        app,
        connection_provider,
        element_types=None,
        id="A",
        theme=None,
    ):
        """
        Create a DashboardEngine instance
        Arguments:
            app: A Dash app instance
            connection_provider: A DBE connection provider
            element_types: Optional; A list of element classes to register in
                the engine. It defaults to an official set of elements.
            id: Optional; A unique identifier in order to properly support
                multiple independent instances of DashboardEngine.
        """
        RequestID(app.server)
        self._app = app

        self._id = id

        # Initialize empty
        self._element_types = {}
        self._inputs = []
        self._schemas = {}
        self._theme = Theme(theme) if theme else Theme(default_theme)

        # Register element types
        for element_type in element_types or builtin_elements():
            self._register(element_type)

        self._connection_provider = connection_provider
        self._attach_callback()

    def _register(self, cls):
        name = _get_element_type_from_class(cls)
        prefix = "handle_"
        handlers = [
            func
            for func in dir(cls)
            if func.startswith(prefix) and callable(getattr(cls, func))
        ]
        for handler in handlers:
            for scope in HANDLER_SCOPES:
                scoped_prefix = prefix + scope + ("_" if scope != "" else "")
                if handler.startswith(scoped_prefix):
                    handler_scope = scope
                    prefix_len = len(scoped_prefix)
                    break

            handler_target = handler[prefix_len:].split(HANDLER_SEPARATOR)
            if len(handler_target) < 2:
                raise Exception(
                    """In "{}", handler method "{}" should contain
                    character "{}" at least twice""".format(
                        name, handler, HANDLER_SEPARATOR
                    )
                )

            prop_name = HANDLER_SEPARATOR.join(handler_target[1:])

            signature = {
                "id": MATCH,
                "index": ALL,
                "type": name,
                "engine-id": self._id,
            }

            if handler_scope != "":
                signature["scope"] = handler_scope

            pmc = False
            if handler_target[0] != "" and handler_target[0] != "ROOT":
                child_id = handler_target[0]
                if child_id == "ALL":
                    child_id = ALL
                    pmc = True

                signature["child-id"] = child_id

            input = {
                "callback_signature": Input(
                    signature,
                    prop_name,
                ),
                "handler": getattr(cls, handler),
                "pmc": pmc,
            }

            self._inputs.append(input)

        # TODO: make sure cls has a render method, else give warning
        # TODO: error out if name is already taken
        self._element_types[name] = cls

    def _make_id(self, **kwargs):
        id = {"engine-id": self._id}
        for key, value in kwargs.items():
            id[key] = value
        if "id" not in kwargs or "type" not in kwargs:
            raise Exception('It is mandatory to specify an "id" and a "type"!')
        return id

    def state_id(self, dashboard_id):
        """
        Get the state component's ID for a given dashboard ID. This method is
        meant to be used in callback dependency decorators.

        Arguments:
          - `dashboard_id` (str): the ID that was passed in to
            `make_state_and_canvas` or `make_state_and_components`

        Returns:
          - `state_id` (dict): the composite state_id
        """
        return self._make_id(type="dashboard-state", id=dashboard_id)

    def canvas_id(self, dashboard_id):
        """
        Get the canvas component's ID for a given dashboard ID. This method is
        meant to be used in callback dependency decorators.

        Arguments:
          - `dashboard_id` (str): the ID that was passed in to
            `make_state_and_canvas` or `make_state_and_components`

        Returns:
          - `canvas_id` (dict): the composite canvas_id
        """
        return self._make_id(type="dashboard-canvas", id=dashboard_id, related="canvas")

    def _editor_id(self, dashboard_id):
        """
        Get the editor component's ID for a given dashboard ID. This method is
        meant to be used in callback dependency decorators.

        Arguments:
          - `dashboard_id` (str): the ID that was passed in to
            `make_state_and_canvas` or `make_state_and_components`

        Returns:
          - `editor_id` (dict): the composite editor_id
        """
        return self._make_id(type="dashboard-editor", id=dashboard_id, related="canvas")

    def make_state_and_canvas(
        self,
        dashboard_id,
        connection_params=None,
        elements=None,
        arrangement=None,
        editable=True,
        inspectable=True,
    ):
        """
        Create a canvas linked to a new dashboard state

        Arguments:
          - `dashboard_id`: A string identifier used to build composite IDs for
            this linked set of components
          - `connection_params`: A value passed to the engine's connection
            provider
          - `elements`: A list of elements. Usually retrieved from a
            `DashboardState` instance, either via a callback or from the
            inspector button.
          - `arrangement`: A dictionary describing the visual arrangement of
            elements. Usually retrieved from a `DashboardCanvas` instance,
            either via a callback or from the inspector button.
          - `editable`: should the pencil be visible and usable to edit the
            canvas
          - `inspectable`: should the inspector button be visible

        Returns:
          - A tuple of 2 items:
            1. An instance of `DashboardState` component
            2. A tuple containing an instance of `DashboardCanvas` component and
               other components

            that are linked to one another.
        """
        elements = [] if elements is None else elements
        elements = [_coerce_element(e) for e in elements]
        if arrangement is None:
            config = CanvasConfig()
            for el in elements:
                config.add_card(el)
            arrangement = config.arrangement
        elements = _relayout(elements, arrangement)

        return tuple(
            [
                dashboard_engine.DashboardState(
                    id=self.state_id(dashboard_id),
                    connection_params=connection_params,
                    elements=elements,
                ),
                html.Div(
                    [
                        dashboard_engine.DashboardCanvas(
                            id=self.canvas_id(dashboard_id),
                            editable=editable,
                            inspectable=inspectable,
                            arrangement=arrangement,
                        ),
                        dashboard_engine.DashboardEditor(
                            id=self._editor_id(dashboard_id),
                            children=[],
                        ),
                        CodeDisplayModal.make_code_display_modal(self, dashboard_id),
                    ]
                ),
            ]
        )

    def make_state_and_components(
        self, dashboard_id, connection_params=None, elements=None
    ):
        """
        Create a set of components linked to a new dashboard state

        Arguments:
          - `dashboard_id`: A string identifier used to build composite IDs for
            this linked set of components.
          - `connection_params`: A value passed to the engine's connection
            provider
          - `elements`: A list of elements. Usually retrieved from a
            `DashboardState` instance, either via a callback or from the
            inspector button.

        Returns:
          - A tuple of 2 items:
            1. An instance of DashboardState component
            2. A tuple of Dash components

            that are linked to each another.
        """
        elements = [] if elements is None else elements
        elements = [_coerce_element(e) for e in elements]
        return (
            dashboard_engine.DashboardState(
                id=self.state_id(dashboard_id),
                connection_params=connection_params,
                elements=elements,
            ),
            tuple(
                [
                    html.Div(
                        id={
                            "type": "engine-element",
                            "id": dashboard_id,
                            "index": index,
                            "engine-id": self._id,
                        },
                    )
                    for index, el in enumerate(elements)
                ]
            ),
        )

    def component_id_generator(self, correlation_id, index, element_type, scope=None):
        def id(child_id="ROOT", strict=True):
            d = {
                "id": correlation_id,
                "index": index,
                "type": element_type,
                "engine-id": self._id,
            }

            if scope is not None:
                d["scope"] = scope

            if child_id != "ROOT":
                if strict and HANDLER_SEPARATOR in child_id:
                    raise Exception(
                        'Children id must not contain any "{}"'.format(
                            HANDLER_SEPARATOR
                        )
                    )
                if child_id in (HANDLER_SCOPES + ["ALL"]):
                    raise Exception(
                        "Children id cannot use reserved name '{}'".format(child_id)
                    )
                d["child-id"] = child_id
            return d

        return id

    def _attach_callback(self):
        # The callback flow is:
        #  - user interaction
        #  - causes callback which calls handle_* (on the server)
        #  - which returns an updated state from the client
        #  - which triggers a second callback (on the server)
        #  - which does validate_and_coerce and render
        #  - which updates the UI (on the client)

        ############
        # Pattern-matching callbacks for vanilla Dash
        ############
        pmc_state = self._make_id(type="dashboard-state", id=MATCH)
        pmc_elements = self._make_id(type="engine-element", id=MATCH, index=ALL)

        # Generate children
        def generate_children(connection_params, elements):
            output_list = dash.callback_context.outputs_list[0]

            # Get list of elements on page
            indices = [output["id"]["index"] for output in output_list]

            # Get id of the set of components
            id = output_list[0]["id"]["id"]

            children = self._render()(connection_params, elements, -1)[0][0]

            return [
                [
                    html.Div(
                        id={
                            "type": "engine-element",
                            "id": id,
                            "index": i,
                            "engine-id": self._id,
                        },
                        children=children[i],
                    )
                    for i in indices
                ]
            ]

        self._app.callback(
            [Output(pmc_elements, "children")],
            [Input(pmc_state, "connection_params"), Input(pmc_state, "elements")],
        )(generate_children)

        ############
        # Pattern-matching callbacks for RGL + editor
        ############
        pmc_canvas = self._make_id(type="dashboard-canvas", id=MATCH, related=ALL)
        pmc_editor_canvas = self._make_id(
            type="dashboard-editor", id=MATCH, related=ALL
        )
        pmc_editor_element_type = self._make_id(
            type="dashboard-editor-element-type", id=MATCH, related=ALL
        )

        # Main callback, generating children for canvas
        self._app.callback(
            [Output(pmc_canvas, "children"), Output(pmc_editor_canvas, "children")],
            [
                Input(pmc_state, "connection_params"),
                Input(pmc_state, "elements"),
                Input(pmc_editor_canvas, "selected_element"),
            ],
        )(self._render())

        # UI interaction callback
        elements_inputs = list(input["callback_signature"] for input in self._inputs)
        plugin_inputs = [
            Input(pmc_editor_canvas, "selected_element"),
            Input(pmc_canvas, "selected_children"),
            Input(pmc_canvas, "arrangement"),
            Input(pmc_editor_element_type, "value"),
        ]
        inputs = [] + elements_inputs + plugin_inputs

        self._app.callback(
            [
                Output(pmc_state, "elements"),
                Output(pmc_canvas, "selected_children"),
                Output(pmc_editor_canvas, "selected_element"),
            ],
            inputs,
            [State(pmc_state, "elements"), State(pmc_state, "connection_params")],
        )(self._handle(plugin_inputs))

        # Code displaying callback
        CodeDisplayModal.register_code_display_callbacks(self)

    def _generate_editor_spec(self):
        def generate(connection_params):
            element_types = []
            element_labels = []
            for i, cls in enumerate(self._element_types.items()):
                type = cls[0]
                cls = cls[1]

                if hasattr(cls, "label"):
                    element_types.append(type)
                    element_labels.append(cls.label)

            schema = {
                "element_types": {
                    "type": "string",
                    "title": "Element type",
                    "enum": element_types,
                    "enumNames": element_labels,
                },
                "connection_params": connection_params,
            }

            return schema

        return generate

    def _do_query(
        self, connection, elements, extra_queries=[], extract_crossfilters=False
    ):
        return _do_query(
            self._element_types,
            connection,
            elements,
            extra_queries=extra_queries,
            extract_crossfilters=extract_crossfilters,
        )

    def _render(self):
        def render(connection_params, elements, selected_element):
            with Timer("render"):
                if isinstance(selected_element, list):
                    selected_element = selected_element[0]

                correlation_id = dash.callback_context.inputs_list[0]["id"]["id"]

                # Open connection
                with Timer("render", "get_data_schema"):
                    connection = self._connection_provider.get_connection(
                        connection_params, auth.get_user_data()
                    )

                    data_schema = connection.get_data_schema()

                # Generate editor spec
                with Timer("render", "generate_editor_spec"):
                    editor_spec = self._generate_editor_spec()(connection_params)

                # Validate
                with Timer("render", "validate"):
                    self._validate_elements_and_insert_defaults(data_schema, elements)

                query_results: list[QueryResult] = self._do_query(connection, elements)

                # Build views
                with Timer("render", "build_views"):
                    views = []
                    for (i, element) in enumerate(elements):
                        element_type = element.get("type", "_blank")
                        with Timer(
                            "render", "build_views", "%d-%s" % (i, element_type)
                        ):
                            if element_type == "_blank":
                                current_view = new_card()
                            elif element_has_error(element):
                                error_card_paramters = make_error_card_parameters(
                                    editor_spec, element
                                )
                                current_view = error_card(**error_card_paramters)
                            else:
                                id = self.component_id_generator(
                                    correlation_id, i, element["type"]
                                )
                                try:
                                    results_for_rendering = []
                                    for result in query_results[i]:
                                        result.theme = self._theme
                                        results_for_rendering.append(result)

                                    current_view = self._element_types[
                                        element["type"]
                                    ].render(id, element, results_for_rendering)

                                except Exception as e:  # noqa: E722
                                    logging.exception(e)
                                    current_view = error_card(
                                        "Render error",
                                        "An internal error has occurred, more "
                                        "information is available in the "
                                        "application logs.",
                                    )

                            views.append(current_view)

                # Generate imperative editor
                editor_view = [None]
                if selected_element is not None and selected_element > -1:
                    element = elements[selected_element]

                    # Element type selector
                    editor_children = [
                        ddk.ControlCard(
                            ddk.ControlItem(
                                dcc.Dropdown(
                                    id=self._make_id(
                                        type="dashboard-editor-element-type",
                                        id=correlation_id,
                                        related="canvas",
                                    ),
                                    options=[
                                        {
                                            "label": a[0],
                                            "value": a[1],
                                        }
                                        for a in zip(
                                            editor_spec["element_types"]["enumNames"],
                                            editor_spec["element_types"]["enum"],
                                        )
                                    ],
                                    value=element["type"],
                                    clearable=False,
                                ),
                                label="Element type",
                                label_style={"paddingBottom": "0px"},
                            ),
                            style={"marginBottom": "0px"},
                        )
                    ]

                    # Element render editor
                    if element.get("type", "_blank") != "_blank":
                        cls = self._element_types[element["type"]]
                        render_editor = getattr(cls, "render_editor", None)

                        if callable(render_editor):
                            id = self.component_id_generator(
                                correlation_id,
                                selected_element,
                                element["type"],
                                scope="editor",
                            )
                            editor_children.append(
                                render_editor(
                                    id, element, query_results[selected_element]
                                )
                            )

                    editor_view = [html.Div(children=editor_children)]

                return [[views], editor_view]

        return render

    def _handle(self, plugin_inputs):
        inputs = self._inputs

        # For plugin inputs, build map from name to input index
        plugin_inputs_length = len(plugin_inputs)
        plugin_inputs_lookup_index = {}
        for index, plugin_input in enumerate(plugin_inputs):
            d = plugin_input.to_dict()
            id = json.loads(d["id"])
            tuple_id = (id["type"], d["property"])
            plugin_inputs_lookup_index[tuple_id] = -plugin_inputs_length + index

        def get_first_value(o):
            return next(iter(o), {}).get("value", None)

        def handle(*argv):
            with Timer("handler"):
                ctx = dash.callback_context

                # Retrieve ID of input that was triggered
                triggered_tuple = ()
                triggered_id = None
                if ctx.triggered:
                    triggered_id = ctx.triggered[0]["prop_id"]
                    if triggered_id != ".":
                        s = triggered_id.split(".")
                        triggered_id = json.loads(".".join(s[0:-1]))
                        triggered_prop = s[-1]
                        triggered_tuple = (
                            triggered_id.get("type", None),
                            triggered_prop,
                        )

                    triggered_value = get_first_value(ctx.triggered)

                def get_trigger_value(t):
                    return triggered_value if triggered_tuple == t else None

                def get_input_value(tuple_id):
                    if tuple_id in plugin_inputs_lookup_index:
                        index = plugin_inputs_lookup_index[tuple_id]
                        return get_first_value(ctx.inputs_list[index])
                    else:
                        return None

                # Get index of selected_element
                selected_element = next(
                    i
                    for i in [
                        get_trigger_value(("dashboard-canvas", "selected_children")),
                        get_trigger_value(("dashboard-editor", "selected_element")),
                        get_input_value(("dashboard-canvas", "selected_children")),
                        get_input_value(("dashboard-editor", "selected_element")),
                        -1,
                    ]
                    if i is not None
                )

                # Get elements
                elements = argv[-2]  # the elements currently in the state

                # Use element type definition from editor if it triggered
                editor_element_element_type = get_trigger_value(
                    ("dashboard-editor-element-type", "value")
                )
                if editor_element_element_type:
                    elements[selected_element] = dict(type=editor_element_element_type)

                # Retrieve connection_params
                connection_params = argv[-1]

                # Get data_schema
                with Timer("handler", "get_data_schema"):
                    connection = self._connection_provider.get_connection(
                        connection_params, auth.get_user_data()
                    )
                    data_schema = connection.get_data_schema()

                # Generate specifications to insert defaults
                with Timer("handler", "validate"):
                    self._validate_elements_and_insert_defaults(data_schema, elements)

                # Call element's callbacks
                # We use ctx.inputs_list here because it is already parsed
                for input_index, input_list in enumerate(
                    ctx.inputs_list[:-plugin_inputs_length]
                ):
                    if not input_list:
                        continue

                    # Group by element_index
                    sorted_input_by_index = sorted(
                        input_list, key=lambda i: i["id"]["index"]
                    )
                    grouped_input_by_index = [
                        {"index": k, "input_list": list(v)}
                        for k, v in itertools.groupby(
                            sorted_input_by_index, key=lambda i: i["id"]["index"]
                        )
                    ]
                    for grouped_input in grouped_input_by_index:
                        element_index = grouped_input["index"]
                        element = elements[element_index]

                        if inputs[input_index]["pmc"]:
                            # Skip if triggered from root component
                            if "child-id" not in triggered_id:
                                continue

                            z = itertools.groupby(
                                grouped_input["input_list"],
                                key=lambda i: i["id"]["child-id"],
                            )

                            first_input = grouped_input["input_list"][0]
                            if (
                                all(
                                    triggered_id[a] == first_input["id"][a]
                                    for a in ["engine-id", "id", "index", "type"]
                                )
                                and triggered_prop == first_input["property"]
                            ):
                                values = {k: next(v).get("value") for k, v in z}
                                values = morph.unflatten(values)
                                inputs[input_index]["handler"](
                                    values,
                                    elements,
                                    element_index,
                                    data_schema,
                                )
                        else:
                            input = grouped_input["input_list"][0]
                            if (
                                triggered_id == input["id"]
                                and triggered_prop == input["property"]
                                # the element has no error
                                and not element_has_error(element)
                                # the input was triggered
                                and "value" in input
                                # and types are the same (see issue #434)
                                and element["type"] == input["id"]["type"]
                            ):
                                inputs[input_index]["handler"](
                                    input["value"], elements, element_index, data_schema
                                )

                # Handle layout changes
                arrangement = get_input_value(("dashboard-canvas", "arrangement"))
                if arrangement:
                    elements = _relayout(elements, arrangement)

                # TODO: create helper to write "set_output_value(tuple_id, value)"
                output = [
                    elements,
                    [selected_element],
                    [selected_element],
                ]
                # If the output is not present in callback_context, return empty list
                # otherwise the renderer will complain
                for i, value in enumerate(ctx.outputs_list):
                    if not value:
                        output[i] = []

                return output

        return handle

    def _validate_elements_and_insert_defaults(self, data_schema, elements):
        # Validate elements and provide defaults
        for element in elements:
            element_type = element.get("type", "_blank")
            if element_type == "_blank":
                continue

            cls = self._element_types[element_type]
            validator = getattr(cls, "validate_and_coerce", None)

            if callable(validator):
                error = validator(data_schema, element)
                if not error:
                    element.pop("_error", None)
                else:
                    element["_error"] = error

    def execute_query(self, connection_params, elements, columns=None):
        """
        Retrieve a data frame representing the active selection for a set of
        elements. Note: in the absence of a selection, the entire dataset is
        returned


        Arguments:
          - `connection_params`: A value passed to the engine's connection
            provider
          - `elements`: A list of elements. Usually retrieved from a
            `DashboardCanvas` instance, either via a callback or from the
            inspector button.
          - `columns`: a list of data frame columns to be returned

        Returns:
          - A Pandas Dataframe
        """
        if columns is not None:
            sq = Query(
                columns=[{"function": "none", "args": c, "key": c} for c in columns]
            )
            connection = self._connection_provider.get_connection(
                connection_params, auth.get_user_data()
            )
            query_results = self._do_query(
                connection, elements, extra_queries=[[sq]], extract_crossfilters=True
            )
            if len(query_results) and len(query_results[-1]):
                return query_results[-1][0].df
        return None


def _get_element_type_from_class(cls):
    return ".".join(cls.__module__.split(".")[:-1] + [cls.__name__])


def _coerce_element(element):
    if isinstance(element, dict):
        return element
    else:
        return dict(type=_get_element_type_from_class(type(element)), **element._config)


def _relayout(elements, arrangement):
    grid = arrangement.setdefault("grid", {})
    cards = grid.setdefault("lg", [])

    # Collect children index from cards
    children_index = []
    for card in cards:
        card_children = card.setdefault("children", [])
        for i in card_children:
            children_index.append(i)

    # Pad elements to desired length
    try:
        desired_length = max(children_index) + 1
    except ValueError:
        desired_length = 0

    while len(elements) < desired_length:
        elements.append(dict(type="_blank"))

    # Turn invisible elements to new
    for (i, element) in enumerate(elements):
        if i not in children_index:
            elements[i] = dict(type="_blank")

    for (i, card) in enumerate(cards):
        card_children = card.setdefault("children", [])

        for children_index in card["children"]:
            if (
                elements[children_index] is None
                or elements[children_index].get("type", "_blank") == "_blank"
            ):
                elements[children_index] = dict(type="_blank")

    return elements


def element_has_error(element):
    return element.get("_error", False) is not False


def make_error_card_parameters(editor_spec, element):
    element_label = ""
    for e_type, e_label in zip(
        editor_spec["element_types"]["enum"],
        editor_spec["element_types"]["enumNames"],
    ):
        if e_type == element["type"]:
            element_label = e_label
    if "is a required property" in element["_error"].get("message", ""):
        params = dict(
            error_label="Required Field Missing",
            element_label=element_label,
            msg=dedent(
                """
            The {} field is missing.\n
            Required fields are identified with a star (*****)
            in the editor.
            """
            ).format("**{}**".format(element["_error"].get("title"))),
            icon_name="tasks",
        )
    else:
        params = dict(
            error_label="validation error",
            element_label=element_label,
            msg=element["_error"].get("message", ""),
        )

    return params


def error_card(
    error_label=None, msg=None, element_label=None, icon_name="exclamation-circle"
):

    title = "{} {}".format(element_label or "", error_label or "").strip()

    children = [
        ddk.CardHeader(
            ddk.Icon(icon_name=icon_name),
            title=title if len(title) else None,
            style={"fontSize": "20px"},
        )
    ]

    if msg is not None:
        children.append(html.Div(dcc.Markdown(msg), style={"fontSize": "16px"}))

    return ddk.Card(
        className="placeholder error-card",
        style={"padding": 0},
        type="flat",
        children=children,
    )


def new_card():
    return html.Div(
        className="placeholder",
        children=[
            ddk.Icon(icon_name="tasks"),
            html.P(
                "Element type unspecified",
                style={"fontSize": "20px", "textAlign": "center"},
            ),
        ],
    )
