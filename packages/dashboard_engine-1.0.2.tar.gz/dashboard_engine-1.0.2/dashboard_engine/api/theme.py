from enum import Enum

default_theme = {
    "colorway": [
        "var(--colorway-0)",
        "var(--colorway-1)",
        "var(--colorway-2)",
        "var(--colorway-3)",
        "var(--colorway-4)",
        "var(--colorway-5)",
        "var(--colorway-6)",
        "var(--colorway-7)",
        "var(--colorway-8)",
        "var(--colorway-9)",
    ],
    "colorscale": [
        "var(--colorscale-0)",
        "var(--colorscale-1)",
        "var(--colorscale-2)",
        "var(--colorscale-3)",
        "var(--colorscale-4)",
        "var(--colorscale-5)",
        "var(--colorscale-6)",
        "var(--colorscale-7)",
        "var(--colorscale-8)",
        "var(--colorscale-9)",
    ],
}


class ConversionFunctions(dict):
    @staticmethod
    def _hex_to_tuple(hex_color):
        """Takes a hex rgb string (#ffffff) and returns an RGB tuple:floats."""
        return tuple(
            int(hex_color[i : i + 2], 16) / 255.0 for i in (1, 3, 5)
        )  # skip '#'

    @staticmethod
    def _hex_to_rgb(hex_color):
        r, g, b = ConversionFunctions._hex_to_tuple(hex_color)
        r, g, b = int(r * 255), int(g * 255), int(b * 255)
        return f"rgb({r}, {g}, {b})"

    @staticmethod
    def _rgb_to_hex(rgb_color):
        r, g, b = map(int, rgb_color[4:-1].split(","))
        ret_color = ConversionFunctions._tuple_to_hex((r, g, b), normalized=False)
        return ret_color

    @staticmethod
    def _rgb_to_tuple(rgb_color):
        r, g, b = map(int, rgb_color[4:-1].split(","))
        return tuple(i / 255.0 for i in (r, g, b))

    @staticmethod
    def _tuple_to_hex(rgb_tuple, normalized=True):
        scale_value = 255 if normalized else 1
        """Takes an RGB tuple or list and returns a hex RGB string."""
        r = int(rgb_tuple[0] * scale_value)
        g = int(rgb_tuple[1] * scale_value)
        b = int(rgb_tuple[2] * scale_value)
        return f"#{r:02x}{g:02x}{b:02x}"

    @staticmethod
    def _tuple_to_rgb(rgb_tuple, normalized=True):
        r, g, b = map(lambda x: int(x * 255), rgb_tuple)
        return f"rgb({r}, {g}, {b})"

    @staticmethod
    def _raise_css_to_rgb_error(color):
        raise ValueError(f"Cannot convert {color} to rgb")

    @staticmethod
    def _raise_css_to_hex_error(color):
        raise ValueError(f"Cannot convert {color} to hex")

    @staticmethod
    def _raise_css_to_tuple_error(color):
        raise ValueError(f"Cannot convert {color} to tuple")

    def __init__(self):
        mapping = {
            "hex": {
                "rgb": ConversionFunctions._hex_to_rgb,
                "tuple": ConversionFunctions._hex_to_tuple,
            },
            "rgb": {
                "hex": ConversionFunctions._rgb_to_hex,
                "tuple": ConversionFunctions._rgb_to_tuple,
            },
            "tuple": {
                "hex": ConversionFunctions._tuple_to_hex,
                "rgb": ConversionFunctions._tuple_to_rgb,
            },
            "css": {
                "rgb": ConversionFunctions._raise_css_to_rgb_error,
                "hex": ConversionFunctions._raise_css_to_hex_error,
                "tuple": ConversionFunctions._raise_css_to_tuple_error,
            },
        }
        self.update(mapping)

    def get_function(self, from_type, to_type):
        return self[from_type][to_type]


class DotDict(dict):
    """dot.notation access to dictionary attributes"""

    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__

    # this getattr allows us to pickle
    def __getattr__(self, attr):
        if attr.startswith("__"):
            raise AttributeError
        return self.get(attr, None)


class ColorType(Enum):
    RGB = "rgb"
    HEX = "hex"
    CSS = "css"
    TUPLE = "tuple"

    @staticmethod
    def get_type(color):
        if isinstance(color, tuple):
            return ColorType.TUPLE
        elif isinstance(color, str):
            if color.startswith("rgb"):
                return ColorType.RGB
            elif color.startswith("#"):
                return ColorType.HEX
            elif color.startswith("var"):
                return ColorType.CSS


class Theme(DotDict):
    def __init__(self, theme: dict):
        # this is so we can preserve the rest of the items in theme
        # self.update(theme)

        self["colorway"] = Theme._colorway_validation(theme.get("colorway"))
        self["colorscale"] = Theme._colorscale_validation(theme.get("colorscale"))
        super().__init__(self)

    @staticmethod
    def _colorway_validation(colorway):
        if not colorway:
            return default_theme["colorway"]
        elif len(colorway) > 10:
            raise ValueError("Length of colorway cannot exceed 10")
        return colorway

    @staticmethod
    def _colorscale_validation(colorscale):
        if not colorscale:
            return default_theme["colorscale"]
        elif len(colorscale) > 10:
            raise ValueError("Length of colorscale cannot exceed 10")
        return colorscale

    def get_discrete_color(self, i: int, color_type=None):
        colorway = self.colorway[i % len(self.colorway)]
        curr_type = ColorType.get_type(colorway)

        if color_type and curr_type != color_type:
            function_map = ConversionFunctions()[curr_type.value][color_type.value]
            colorway = function_map(colorway)
            return colorway

        return colorway

    def get_continuous_color_step(self, i: int, color_type=None):
        colorscale = self.colorscale[i % len(self.colorscale)]
        curr_type: ColorType = ColorType.get_type(colorscale)

        assert curr_type is not None, "returned type cannot be None"

        if color_type and curr_type != color_type:
            function_map = ConversionFunctions()[curr_type.value][color_type.value]
            colorscale = function_map(colorscale)
            return colorscale

        return colorscale

    def get_colorway(self, color_type=None):
        ret_colors = [
            self.get_discrete_color(i, color_type=color_type)
            for i in range(len(self.colorway))
        ]
        return ret_colors

    def get_colorscale(self, color_type=None):
        ret_colors = [
            self.get_continuous_color_step(i, color_type=color_type)
            for i in range(len(self.colorscale))
        ]
        return ret_colors
