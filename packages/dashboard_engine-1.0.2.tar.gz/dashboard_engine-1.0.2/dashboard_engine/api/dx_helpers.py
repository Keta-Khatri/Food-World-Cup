from .dash_imports import dash, html, ddk
from dash.dependencies import Input, Output, MATCH, State
import pprint

__doc__ = """
DX Helpers

Functions acting on DBE objects (e.g., a DashboardEngine instance) that improve
the developer experience.
"""


class CodeDisplayModal:
    @staticmethod
    def _update_elements_and_arrangement_displays(n_clicks, elements, arrangement):
        """
        The intended use is as a callback that updates page elements displaying
        the dashboard elements and arrangement from the state and canvas
        respectively.
        Used by register_code_display_callbacks.
        """
        if n_clicks is None or n_clicks <= 0:
            return dash.no_update

        for e in elements:
            e.pop("_error", None)

        return [
            "elements = %s" % pprint.pformat(elements),
            "arrangement = {'grid': {'lg': \n%s\n}}"
            % pprint.pformat(arrangement["grid"]["lg"]),
        ]

    @staticmethod
    def _open_dashboard_code_display_modal(elements_json_children):
        """
        The intended use of this function is as a callback that returns True or
        False to the "expanded" property of a ddk.Modal that opens it when the
        input page element has content.
        """
        if elements_json_children is not None and len(elements_json_children) > 0:
            return True
        return False

    @staticmethod
    def make_code_display_modal(engine_instance, dashboard_id):
        """
        Returns a Div containing places to hold element and arrangement code and
        a modal for showing / hiding this code.
        The `inspectable` button in the Canvas will activate this modal.
        """
        modal_id = engine_instance._make_id(
            type="dashboard-code-display-modal", id=dashboard_id
        )
        elements_id = engine_instance._make_id(
            type="dashboard-code-display-elements", id=dashboard_id
        )
        arrangement_id = engine_instance._make_id(
            type="dashboard-code-display-arrangement", id=dashboard_id
        )
        row_id = engine_instance._make_id(
            type="dashboard-code-display-row", id=dashboard_id
        )
        return html.Div(
            children=[
                ddk.Modal(
                    id=modal_id,
                    target_id=row_id,
                    hide_target=True,
                    expanded=False,
                    style=dict(display="none"),
                ),
                html.Div(
                    [html.Pre("", id=elements_id), html.Pre("", id=arrangement_id)],
                    id=row_id,
                ),
            ],
        )

    @staticmethod
    def register_code_display_callbacks(engine_instance):
        # a callback that will open the modal when the code display contents change
        modal_id = engine_instance._make_id(
            type="dashboard-code-display-modal", id=MATCH
        )
        elements_id = engine_instance._make_id(
            type="dashboard-code-display-elements", id=MATCH
        )
        arrangement_id = engine_instance._make_id(
            type="dashboard-code-display-arrangement", id=MATCH
        )
        engine_instance._app.callback(
            Output(modal_id, "expanded"),
            Input(elements_id, "children"),
            prevent_initial_call=True,
        )(CodeDisplayModal._open_dashboard_code_display_modal)

        # a callback that will inject the most recent elements and arrangement
        # code in the appropriate page elements when a button is clicked
        engine_instance._app.callback(
            [
                Output(elements_id, "children"),
                Output(arrangement_id, "children"),
            ],
            Input(engine_instance.canvas_id(MATCH), "inspect_n_clicks"),
            State(
                engine_instance.state_id(MATCH),
                "elements",
            ),
            State(
                engine_instance.canvas_id(MATCH),
                "arrangement",
            ),
            prevent_initial_call=True,
        )(CodeDisplayModal._update_elements_and_arrangement_displays)
