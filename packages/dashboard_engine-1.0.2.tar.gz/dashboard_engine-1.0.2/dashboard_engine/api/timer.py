import os
import logging
import sys
import time
from flask import request


logger = logging.getLogger("timer")
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))


class Timer(object):
    def __init__(self, *args):
        self.name = ":".join([str(arg) for arg in args])

    def __enter__(self):
        self.tstart = time.time()

    def __exit__(self, type, value, traceback):
        if "DBE_TIMER" in os.environ:
            logger.debug(
                "%s:%s: %.3f"
                % (_get_request_id(), self.name, time.time() - self.tstart)
            )


# similar to the above timer, but also shows how much passes Vaex did over the data
class TimerVaex(Timer):
    def __init__(self, executor, *args):
        self.executor = executor
        super().__init__(*args)

    def __enter__(self):
        super().__enter__()
        self.passes_start = self.executor.passes

    def __exit__(self, type, value, traceback):
        if "DBE_TIMER" in os.environ:
            passes = self.executor.passes - self.passes_start
            logger.debug(
                "%s:%s: %.3f (%s passes)"
                % (_get_request_id(), self.name, time.time() - self.tstart, passes)
            )


def _get_request_id():
    try:
        # when running a test, this might fail
        return request.environ.get("REQUEST_ID")
    except:  # noqa
        return "no-id"
