import numpy as np
import dash_design_kit as ddk
from dashboard_engine.api.constants import DBE_MAPBOX_TOKEN
from dashboard_engine.api.theme import ColorType

from ._base_element import BaseElement, DataField, RadioItems
from ..query import Query
from ._helpers import (
    get_column_def,
    lon_lat_to_easting_northing,
    make_2d_range_selection,
    handle_mapbox_relayout,
)

WIDTH = 450
HEIGHT = 300
FACTOR = 3


def _get_bounds_zoom_level(*, lon_min, lon_max, lat_min, lat_max, map_dim):
    scale = (
        2  # adjustment to reflect MapBox base tiles are 512x512 vs. Google's 256x256
    )
    world_dim = {"height": 256 * scale, "width": 256 * scale}
    zoom_max = 18

    def lat_rad(lat):
        sin = np.sin(lat * np.pi / 180)
        rad_x2 = np.log((1 + sin) / (1 - sin)) / 2
        return max(min(rad_x2, np.pi), -np.pi) / 2

    def zoom(map_px, world_px, fraction):
        return 0.95 * np.log(map_px / world_px / fraction) / np.log(2)

    lat_fraction = (lat_rad(lat_max) - lat_rad(lat_min)) / np.pi

    lng_diff = lon_max - lon_min
    lng_fraction = ((lng_diff + 360) if lng_diff < 0 else lng_diff) / 360

    lat_zoom = zoom(map_dim["height"], world_dim["height"], lat_fraction)
    lng_zoom = zoom(map_dim["width"], world_dim["width"], lng_fraction)

    return min(lat_zoom, lng_zoom, zoom_max)


class RasterMapbox(BaseElement):
    label = "Raster Map"
    fields = [
        DataField(
            name="Longitude", key="lon", required=True, numeric="raw", label=False
        ),
        DataField(
            name="Latitude", key="lat", required=True, numeric="raw", label=False
        ),
        DataField(
            name="Color", key="color", required=False, numeric=False, discrete=20
        ),
        RadioItems(
            "Minimum Opacity",
            "minalpha",
            options=["none", "half", "full"],
            default="half",
        ),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        range_filter = make_2d_range_selection(element)

        return [
            Query(
                columns=[
                    get_column_def(element, "lon", "lon"),
                    get_column_def(element, "lat", "lat"),
                    get_column_def(element, "color", "color"),
                ],
                crossfilters=range_filter,
                filters=range_filter,
                rasterization={
                    "plot_width": WIDTH,
                    "plot_height": HEIGHT,
                    "x_column": element.get("lon"),
                    "y_column": element.get("lat"),
                    "color": element.get("color"),
                    "x_limits": element.get("range", {}).get("lon", None),
                    "y_limits": element.get("range", {}).get("lat", None),
                },
            )
        ]

    @staticmethod
    def handle_ROOT_relayoutData(value, elements, index, data_schema):  # noqa: N802
        handle_mapbox_relayout(value, elements, index, data_schema)

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]

        lat = element["lat"]
        lon = element["lon"]
        color = element.get("color", None)

        import datashader.transfer_functions as tf
        import xarray as xr
        import datashader as ds

        if not query_result.is_empty():
            agg = query_result.rasterized_array

            color_name = element.get("color")
            lon_values = agg.coords[lon].values
            lat_values = agg.coords[lat].values

            lat0, lat1 = lat_values[0], lat_values[-1]
            lon0, lon1 = lon_values[0], lon_values[-1]

            coordinates = [
                [lon0, lat1],
                [lon1, lat1],
                [lon1, lat0],
                [lon0, lat0],
            ]

            eastings, northings = lon_lat_to_easting_northing(lon_values, lat_values)
            agg_en = agg.assign_coords({lon: eastings, lat: northings})
            agg_en.name = "agg_en"
            cvs = ds.Canvas(
                plot_width=FACTOR * WIDTH,
                plot_height=FACTOR * HEIGHT,
                x_range=[float(eastings[0]), float(eastings[-1])],
                y_range=[float(northings[0]), float(northings[-1])],
            )

            if color_name:
                layers = [
                    cvs.quadmesh(agg_en.sel({color_name: val}), lon, lat)
                    for val in agg_en[color_name]
                ]
                agg = (
                    xr.concat(layers, dim=color_name)
                    .assign_coords({color_name: agg_en[color_name]})
                    .transpose(*agg_en.dims)
                )
            else:
                agg = cvs.quadmesh(agg_en, lon, lat)

            img = tf.shade(
                agg.astype("uint64"),
                min_alpha=dict(none=0, half=128, full=255)[element["minalpha"]],
                color_key=query_result.make_color_map("color", color, ColorType.HEX),
                cmap=query_result.get_colorscale(ColorType.HEX),
            ).to_pil()

            layers = [
                {
                    "sourcetype": "image",
                    "source": img,
                    "coordinates": coordinates,
                }
            ]
        else:
            customdata = [None]
            layers = []
            lat_values = element.get("range", {}).get("lat", [])
            lon_values = element.get("range", {}).get("lon", [])

            if not (lon_values and lat_values):
                return BaseElement.render_no_data()

        # Do not display any mapbox markers
        customdata = [None]
        marker = {}

        position = {"zoom": element.get("_zoom"), "center": element.get("_center")}

        zoom = position.get("zoom")
        center = position.get("center")

        if not zoom:
            zoom_level = _get_bounds_zoom_level(
                lon_min=np.min(lon_values),
                lon_max=np.max(lon_values),
                lat_min=np.min(lat_values),
                lat_max=np.max(lat_values),
                map_dim={"height": 255, "width": 255},
            )
            position["zoom"] = zoom_level

        if not center:
            center_lon = np.mean(lon_values)
            center_lat = np.mean(lat_values)
            position["center"] = {
                "lon": center_lon,
                "lat": center_lat,
            }

        # Build map figure
        map_graph = {
            "data": [
                {
                    "type": "scattermapbox",
                    "lat": [None],
                    "lon": [None],
                    "customdata": customdata,
                    "marker": marker,
                    "hovertemplate": (
                        "x: %{customdata[0]}<br>" "y: %{customdata[1]}<br>"
                    ),
                }
            ],
            "layout": {
                "uirevision": True,
                "mapbox": {"style": "carto-positron", "layers": layers}
                if DBE_MAPBOX_TOKEN is None
                else {"accesstoken": DBE_MAPBOX_TOKEN, "layers": layers},
                "margin": {"r": 0, "t": 0, "l": 0, "b": 0},
            },
        }
        map_graph["layout"]["mapbox"].update(position)
        fig = map_graph

        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d", "select2d"]},
        )
