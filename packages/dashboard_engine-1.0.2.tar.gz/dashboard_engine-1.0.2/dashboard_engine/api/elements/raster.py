import PIL.Image
import dash_design_kit as ddk
from ._helpers import (
    get_column_def,
    update_axis,
    make_2d_range_selection,
    handle_cartesian_relayout,
)
import plotly.express as px
from ..query import Query
from ._base_element import BaseElement, DataField, RadioItems

from dashboard_engine.api.theme import ColorType


class Raster(BaseElement):
    label = "Raster Plot"
    fields = [
        DataField(name="X Axis", key="x", required=True, numeric="raw"),
        DataField(name="Y Axis", key="y", required=True, numeric="raw"),
        DataField(
            name="Color", key="color", required=False, numeric=False, discrete=20
        ),
        RadioItems(
            "Minimum Opacity",
            "minalpha",
            options=["none", "half", "full"],
            default="half",
        ),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        range_filter = make_2d_range_selection(element)

        return [
            Query(
                columns=[
                    get_column_def(element, "x", "x"),
                    get_column_def(element, "y", "y"),
                    get_column_def(element, "color", "color"),
                ],
                crossfilters=range_filter,
                filters=range_filter,
                rasterization={
                    "plot_width": 300,
                    "plot_height": 200,
                    "x_column": element.get("x"),
                    "y_column": element.get("y"),
                    "color": element.get("color"),
                    "x_limits": element.get("range", {}).get("x", None),
                    "y_limits": element.get("range", {}).get("y", None),
                },
            )
        ]

    @staticmethod
    def handle_ROOT_relayoutData(value, elements, index, data_schema):  # noqa: N802
        handle_cartesian_relayout(value, elements, index, data_schema)

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        if query_result.is_empty() and not element.get("range", {}):
            return BaseElement.render_no_data()

        x = element["x"]
        y = element["y"]
        color = element.get("color", None)

        import datashader.transfer_functions as tf

        agg = query_result.rasterized_array
        if not query_result.is_empty():
            shaded = tf.shade(
                agg.astype("uint64"),
                min_alpha=dict(none=0, half=128, full=255)[element["minalpha"]],
                color_key=query_result.make_color_map("color", color, ColorType.HEX),
                cmap=query_result.get_colorscale(ColorType.HEX),
            )

            img = shaded.to_pil().resize((900, 600), PIL.Image.NEAREST)

            x = agg.coords[x].values
            x_min = x[0]
            x_max = x[-1]
            range_x = [x_min, x_max]

            y = agg.coords[y].values
            y_min = y[0]
            y_max = y[-1]
            range_y = [y_min, y_max]

        else:
            x = element["range"]["x"]
            x_min = x[0]
            x_max = x[-1]
            range_x = [x_min, x_max]

            y = element["range"]["y"]
            y_min = y[0]
            y_max = y[-1]
            range_y = [y_min, y_max]
            img = None

        fig = px.line(x=range_x, y=range_y)  # start with a line plot so autorange works

        fig.update_traces(opacity=0, hoverinfo="skip")  # make the line invisible
        fig.add_layout_image(  # add the image
            xref="x",  # data coordinates
            x=x_min,
            sizex=x_max - x_min,
            yref="y",
            y=y_max,  # note, images use y-goes-down orientation!
            sizey=y_max - y_min,
            sizing="stretch",
            opacity=1.0,
            source=img,
        )

        fig.update_layout(
            dragmode=element.get("_dragmode", "zoom"),
            uirevision="yes",
            showlegend=False,
        )
        update_axis(fig, element)

        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d", "select2d"]},
        )
