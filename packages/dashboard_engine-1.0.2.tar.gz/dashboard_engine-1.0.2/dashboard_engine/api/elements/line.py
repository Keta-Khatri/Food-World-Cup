import dash_design_kit as ddk
from ._helpers import (
    make_selection_shapes,
    make_label,
    handle_cartesian_selection,
    get_column_def,
)
import plotly.express as px
import numpy as np
from ..query import Query
from ._base_element import BaseElement, Checkbox, DataField


class Line(BaseElement):
    label = "Line Chart"
    fields = [
        DataField(
            name="X Axis",
            key="x",
            required=True,
            numeric="raw",
            discrete=True,
            datetime=True,
            binners=True,
        ),
        DataField(
            name="Y Axis",
            key="y",
            required=True,
            numeric="agg",
        ),
        DataField(
            name="Color",
            key="color",
            required=False,
            discrete=20,
            binners=True,
        ),
        Checkbox("Show legend", "show_legend", default=True),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                columns=[
                    get_column_def(element, "x", "x"),
                    get_column_def(element, "y", "y"),
                    get_column_def(element, "color", "color"),
                ],
                crossfilters=element.get("selections", []),
                crossfilter_mask_key="crossfilter_mask",
            )
        ]

    @staticmethod
    def handle_ROOT_selectedData(value, elements, index, data_schema):  # noqa: N802
        handle_cartesian_selection(value, elements, index, data_schema, ["x"])

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]

        if query_result.is_empty():
            return BaseElement.render_no_data()

        df = query_result.df
        x = element.get("x", None)
        color = element.get("color", None)

        if color and df["color"].dtype == "object":
            # only color in floats has problems displaying data
            df["color"] = df["color"].fillna(" ")

        fig = px.line(
            df.sort_values("x"),
            x="x",
            y="y",
            color="color" if color else None,
            labels={
                "x": make_label(element, "x"),
                "y": make_label(element, "y"),
                "color": make_label(element, "color"),
            },
            category_orders=query_result.make_category_orders({"x": x, "color": color}),
            color_discrete_map=query_result.make_color_map("color", color),
            custom_data=["crossfilter_mask"],  # TODO add PX feature for this in v5
        )
        fig.update_layout(
            dragmode="select",
            hovermode="closest",
            selectdirection="h",
            shapes=make_selection_shapes(element, directions=["x"]),
        )
        fig.update_traces(mode="lines+markers", marker=dict(opacity=0))
        for t in fig.data:
            t.selectedpoints = np.where(np.array(t.customdata).ravel())[0]
        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False, coloraxis_showscale=False)
        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )
