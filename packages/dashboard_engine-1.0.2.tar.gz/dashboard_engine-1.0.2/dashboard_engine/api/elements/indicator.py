import dash_design_kit as ddk
from ._helpers import make_label, get_column_def
from ..query import Query
from ._base_element import BaseElement, DataField


class Indicator(BaseElement):
    label = "Indicator"
    fields = [DataField(name="Value", key="value", required=True, numeric="agg")]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [Query(columns=[get_column_def(element, "value", "value")])]

    @staticmethod
    def render(id, element, query_results: list):
        query_result = query_results[0]
        if query_result.is_empty():
            return BaseElement.render_no_data()

        return ddk.Graph(
            id=id(),
            figure={
                "data": [
                    {
                        "type": "indicator",
                        "value": query_result.df["value"].iloc[0],
                        "mode": "number",
                        "title": {"text": make_label(element, "value")},
                    }
                ],
                "layout": {"margin": {"t": 50, "r": 0, "l": 0, "b": 0}},
            },
        )
