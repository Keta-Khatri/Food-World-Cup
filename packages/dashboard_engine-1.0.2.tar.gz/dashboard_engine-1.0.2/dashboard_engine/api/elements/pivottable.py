from ._helpers import (
    make_label,
    get_column_def,
    get_column_list_def,
)
from ..query import Query
from ._base_element import BaseElement, DataField, Checkbox, DataFieldList, RadioItems
from ..dash_imports import html, Format, Scheme
from ...PivotTable import PivotTable as PivotTableComponent


from functools import cmp_to_key
import pandas as pd


def make_selection_output(selection):
    return {
        item["key"]: item["values"]
        for item in selection
        if item.get("type") == "points"
    }


def get_duplicates(columns):
    return {x for x in columns if columns.count(x) > 1}


class PivotTable(BaseElement):
    label = "Pivot Table"
    fields = [
        DataField(
            name="Value",
            key="value",
            required=True,
            numeric="agg",
            number_formatting=True,
        ),
        DataFieldList(
            "Rows",
            "rows",
            numeric=20,
            discrete=20,
            binners=True,
            top_n_from="value",
        ),
        DataFieldList(
            "Columns",
            "columns",
            numeric=20,
            discrete=20,
            binners=True,
            top_n_from="value",
        ),
        RadioItems(
            "Heatmap Coloring",
            "heatmap",
            options=["none", "accent", "color scale"],
            default="none",
        ),
        Checkbox("Include title", "include_title", default=True),
        Checkbox("Include totals", "include_totals", default=True),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element) -> list:

        value_def = get_column_def(element, "value", "value")
        rows = get_column_list_def(element["rows"], "column", "row")
        cols = get_column_list_def(element["columns"], "column", "col")

        s1 = Query(
            columns=[value_def] + rows + cols,
            crossfilters=element.get("selections", []),
        )

        s2 = Query(columns=[value_def] + rows)
        s3 = Query(columns=[value_def] + cols)
        s4 = Query(columns=[value_def])

        s1.exclude_filtering_group.append(s2.id)
        s1.exclude_filtering_group.append(s3.id)
        s1.exclude_filtering_group.append(s4.id)
        return [s1, s2, s3, s4]

    @staticmethod
    def handle_ROOT_selectionOutput(value, elements, index, data_schema):  # noqa: N802
        def get_target_from_key(key):
            dimension, ind = key.split("_")
            dimension = "rows" if dimension == "row" else "columns"
            column_list = elements[index][dimension]
            target = column_list[int(ind)]["column"]

            return target

        elements[index]["selections"] = [
            {
                "type": "points",
                "target": get_target_from_key(key),
                "values": values,
                "key": key,
            }
            for key, values in value.items()
        ]

    @staticmethod
    def render(id, element, query_results: list):
        rows = [
            x["key"]
            for x in get_column_list_def(element["rows"], "column", "row")
            if x is not None
        ]
        columns = [
            x["key"]
            for x in get_column_list_def(element["columns"], "column", "col")
            if x is not None
        ]

        duplicates = get_duplicates(rows + columns)
        if duplicates:
            message = (
                "A column can only be used once. Duplicate column(s):"
                f" {', '.join(duplicates)}."
            )
            return html.Div(
                className="placeholder",
                children=[html.P(message, style={"fontSize": "20px"})],
            )

        table_result = query_results[0]
        table_df = table_result.df
        rows_df = query_results[1].df
        cols_df = query_results[2].df
        total_df = query_results[3].df

        if total_df is None and table_result.is_empty():
            return BaseElement.render_no_data()

        table_colors = False
        include_col_totals = False
        include_row_totals = False
        grand_total_color = False
        grand_total = False

        if len(columns) == 0 and len(rows) == 0:
            include_row_totals = False
            include_col_totals = False
            table = {
                "index": [],
                "columns": [],
                "data": [],
            }
            if element["include_totals"]:
                grand_total = total_df["value"][0]
                grand_total_color = False

        elif len(columns) == 0 or len(rows) == 0:
            if len(columns) == 0:
                table = {
                    "index": rows_df[rows].values.tolist(),
                    "columns": [],
                    "data": [],
                }
                include_row_totals = True
            else:
                table = {
                    "index": [],
                    "columns": cols_df[columns].values.tolist(),
                    "data": [],
                }
                include_col_totals = True

            if element["include_totals"]:
                grand_total = total_df["value"][0]
                grand_total_color = False
        else:
            pivot = table_df.pivot(
                columns=columns,
                index=rows,
                values="value",
            )

            table = pivot.to_dict("split")
            if element["include_totals"]:
                include_col_totals = True
                include_row_totals = True
                grand_total = total_df["value"][0]

            if element["heatmap"] != "none":
                v_min = pivot.min().min()
                v_max = pivot.max().max()
                v_diff = v_max - v_min

                table_colors_raw = (pivot - v_min) / v_diff if v_diff != 0 else None
                if table_colors_raw is not None:
                    table_colors = table_colors_raw.to_dict("split")["data"]

        number_format = Format(
            precision=element.get("value_number_precision", None),
            scheme=getattr(Scheme, (element.get("value_number_format", "default"))),
        )
        if element.get("value_thousands_separator", False):
            number_format = number_format.group(True)

        cats = {
            key: x.get("column")
            for key, (i, x) in zip(
                rows + columns,
                enumerate([*element.get("rows"), *element.get("columns")]),
            )
        }
        order = table_result.make_category_orders(cats)
        order = {key: order.get(key) for key in cats.keys()}

        row_orders = {
            key: order.get(key) for key in cats.keys() if key.startswith("row")
        }

        col_orders = {
            key: order.get(key) for key in cats.keys() if key.startswith("col")
        }

        row_order = [
            x[1]
            for x in sorted(row_orders.items(), key=lambda x: int(x[0].split("_")[1]))
        ]
        col_order = [
            x[1]
            for x in sorted(col_orders.items(), key=lambda x: int(x[0].split("_")[1]))
        ]

        def sort_dimensions(order, dimensions):
            def fetch_n(x):
                return_orders = []
                for i, n in enumerate(x if isinstance(x, (list, tuple)) else [x]):
                    if order[i] and n in order[i]:
                        return_orders.append(order[i].index(n))
                    else:
                        return_orders.append(n) if pd.notna(n) else float("-inf")
                return return_orders

            def cmp_func(x, y):
                x = fetch_n(x)
                y = fetch_n(y)

                if x < y:
                    return -1
                elif x == y:
                    return 0
                else:
                    return 1

            sorted_dimensions = sorted(
                dimensions,
                key=cmp_to_key(cmp_func),
            )

            sorted_index = [dimensions.index(x) for x in sorted_dimensions]

            return sorted_dimensions, sorted_index

        sorted_rows, sorted_rows_index = sort_dimensions(row_order, table["index"])
        sorted_columns, sorted_columns_index = sort_dimensions(
            col_order, table["columns"]
        )

        def sort_data(data):
            if not data:
                return data
            if sorted_columns_index:
                data = [data[i] for i in sorted_rows_index]
            if sorted_columns_index:
                data = [[cols[i] for i in sorted_columns_index] for cols in data]
            return data

        table["index"] = sorted_rows
        table["columns"] = sorted_columns
        table["data"] = sort_data(table["data"])

        table_colors = sort_data(table_colors)

        def sort_totals(order, dimensions, df):
            def fetch_n(x):
                return_orders = []
                for i, n in enumerate(x[: len(dimensions)]):
                    if order[i] and n in order[i]:
                        return_orders.append(order[i].index(n))
                    else:
                        return_orders.append(n) if pd.notna(
                            n
                        ) else return_orders.append(float("-inf"))

                return return_orders

            def cmp_func(x, y):
                x = fetch_n(x)
                y = fetch_n(y)

                if x < y:
                    return -1
                elif x == y:
                    return 0
                else:
                    return 1

            return [
                x[-1]
                for x in sorted(
                    df[[*dimensions, "value"]].values.tolist(),
                    key=cmp_to_key(cmp_func),
                )
            ]

        col_totals = include_col_totals and sort_totals(col_order, columns, cols_df)
        row_totals = include_row_totals and sort_totals(row_order, rows, rows_df)

        def total_colors(totals):
            if element["heatmap"] == "none" or not totals:
                return False

            v_min = min(totals)
            v_max = max(totals)
            v_diff = v_max - v_min

            scaled_weights = [
                (v - v_min) / v_diff if v_diff != 0 else None for v in totals
            ]

            return scaled_weights

        col_totals_colors = total_colors(col_totals)
        row_totals_colors = total_colors(row_totals)

        sel = make_selection_output(element.get("selections", []))

        return PivotTableComponent(
            id=id(),
            data={
                "table": table,
                "col_totals": col_totals,
                "row_totals": row_totals,
                "grand_total": grand_total,
                "table_colors": table_colors,
                "col_totals_colors": col_totals_colors,
                "row_totals_colors": row_totals_colors,
                "grand_total_color": grand_total_color,
                "colorscale": ["var(--background_content)", "var(--accent)"]
                if element["heatmap"] == "accent"
                else query_results[0].get_colorscale(),
            },
            axis_assignment={
                "columns": {
                    key: make_label(c, "column")
                    for c, key in zip(element["columns"], columns)
                },
                "rows": {
                    key: make_label(c, "column")
                    for c, key in zip(element["rows"], rows)
                },
            },
            selectionOutput=sel,
            title=make_label(element, "value") if element["include_title"] else None,
            format=number_format,
        )
