from nested_lookup import nested_lookup
from collections.abc import Iterable
from ..data_schema import DataSchema

DATA_SCHEMA = {
    "int64": {"dtype": "int64", "cardinality": 4},
    "float64": {"dtype": "float64", "cardinality": 4},
    "object": {"dtype": "object", "cardinality": 3},
    "datetime64[ns]": {"dtype": "datetime64[ns]", "cardinality": 4},
}


def inject_docstring(el):
    # Generate schema
    schema = el.schema(DataSchema(DATA_SCHEMA, None))
    schema = schema["jsonSchema"]

    # Start building out the docstring
    docstring = []
    if hasattr(el, "label"):
        docstring.append([el.label, ""])

    # Build list of input arguments
    if len(_find_properties(schema, 0)):
        docstring.append(["Args:\n"])
        docstring += _find_properties(schema, 0)
    else:
        docstring.append(["Takes no user-supplied arguments."])

    # Inject final docstring
    docstring = flatten(docstring)
    el.__init__.__doc__ = "\n".join(docstring)


def _find_properties(schema, level=1):
    required = schema.get("required", [])
    properties = schema.get("properties", [])
    dependencies = schema.get("dependencies", [])

    docstring = []

    docstring += [
        _format_property(
            name, properties, required=name in required, indent_level=level
        )
        for name in properties
    ]

    # dependencies
    for properties in nested_lookup("properties", dependencies):
        docstring += [
            _format_property(
                name, properties, required=name in required, indent_level=level
            )
            for name in properties
        ]

    return [d for d in docstring if d]


def _format_property(name, properties, required=True, indent_level=1):
    property = properties[name]

    if "title" not in property:
        return []

    extra = []
    if "enum" in property:
        type = "str"
        if len(property["enum"]) > 0:
            e = ['"{}"'.format(p) for p in property["enum"] if p is not None]
            if property["enum"][0] in DATA_SCHEMA:
                extra = [
                    "The name of a column with a dtype in [{}]".format(", ".join(e))
                ]
            else:
                extra = ["One of {}".format(", ".join(e))]
        else:
            extra = ["Accepted values are determined at runtime by the connection."]

    if "type" in property:
        type = property["type"]

    if type == "string":
        type = "str"

    if type == "array":
        type = "list"
        if "items" in property:
            type = "list of dict"
            extra += ["Each element in the list must be a dict with:"]
            extra += _find_properties(property["items"], level=indent_level)

    if type == "object":
        type = "dict"

    if type == "integer":
        type = "int"

    required_str = "required" if required else "optional"

    default_str = ""
    if "default" in property:
        p = property["default"]
        default_str = ", default {}".format(
            '"{}"'.format(p) if isinstance(p, str) else p
        )

    extra = flatten(extra)
    extra = list(map(lambda x: "\t" * (indent_level) + x, extra))
    extra = [
        s.replace(" [", r" \[").replace(" ]", r" \]").replace("[ns]", r"\[ns\]")
        for s in extra
    ]
    docstring = [
        "- {}{} ({}, {}{}): {}\n".format(
            "\t" * indent_level,
            name,
            type,
            required_str,
            default_str,
            property["title"],
        )
    ] + extra

    return docstring + [""]


def flatten(list):
    for el in list:
        if isinstance(el, Iterable) and not isinstance(el, (str, bytes)):
            yield from flatten(el)
        else:
            yield el
