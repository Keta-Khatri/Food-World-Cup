import numpy as np
import dash_design_kit as ddk
import plotly.express as px
from dashboard_engine.api.constants import DBE_MAPBOX_TOKEN

from ._base_element import BaseElement, DataField, Checkbox
from ..query import Query
from ._helpers import (
    make_label,
    get_column_def,
    handle_mapbox_relayout,
    make_2d_range_selection,
)

px.set_mapbox_access_token(DBE_MAPBOX_TOKEN)


class ScatterMapbox(BaseElement):
    label = "Bubble Map"
    fields = [
        DataField(
            name="Longitude", key="lon", required=True, numeric="raw", label=False
        ),
        DataField(
            name="Latitude", key="lat", required=True, numeric="raw", label=False
        ),
        DataField(
            name="Color",
            key="color",
            required=False,
            numeric="agg",
            discrete=20,
        ),
        DataField(
            name="Size",
            key="size",
            required=False,
            numeric="agg",
        ),
        Checkbox("Show legend", "show_legend", default=True),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                columns=[
                    get_column_def(element, "lat", "lat"),
                    get_column_def(element, "lon", "lon"),
                    get_column_def(element, "color", "color"),
                    get_column_def(element, "size", "size"),
                ],
                crossfilters=element.get("selections", []),
                filters=make_2d_range_selection(element),
                crossfilter_mask_key="crossfilter_mask",
            )
        ]

    @staticmethod
    def handle_ROOT_selectedData(value, elements, index, schema):  # noqa: N802
        element = elements[index]
        selections = []

        if value and "range" in value:
            for var, pos in [("lon", 0), ("lat", 1)]:
                selections.append(
                    {
                        "type": "range",
                        "target": element[var],
                        "bounds": [
                            value["range"]["mapbox"][0][pos],
                            value["range"]["mapbox"][1][pos],
                        ],
                    }
                )
        element["selections"] = selections

    @staticmethod
    def handle_ROOT_relayoutData(value, elements, index, data_schema):  # noqa: N802
        handle_mapbox_relayout(value, elements, index, data_schema)

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        if query_result.is_empty():
            return BaseElement.render_no_data()
        else:
            threshold = 100_000
            if query_result.df.shape[0] >= threshold:
                return ScatterMapbox.render_too_much_data(threshold)

        df = query_result.df
        lat = element["lat"]
        lon = element["lon"]
        color = element.get("color", None)
        size = element.get("size", None)

        if color and df["color"].dtype == "object":
            df["color"] = df["color"].fillna(" ")

        if size:
            df["size"] = df["size"].fillna(0.0)

        fig = px.scatter_mapbox(
            df,
            lat="lat",
            lon="lon",
            color="color" if color else None,
            size="size" if size else None,
            labels={
                "lat": lat,
                "lon": lon,
                "size": make_label(element, "size"),
                "color": make_label(element, "color"),
            },
            category_orders=query_result.make_category_orders(
                {"lat": lat, "lon": lon, "color": color}
            ),
            color_discrete_map=query_result.make_color_map("color", color),
            color_continuous_scale=query_result.get_colorscale(),
            mapbox_style="carto-positron" if DBE_MAPBOX_TOKEN is None else None,
            custom_data=["crossfilter_mask"],
            zoom=element.get("_zoom", 4),
            center=element.get("_center"),
        )

        for t in fig.data:
            t.selectedpoints = np.where(np.array(t.customdata).ravel())[0]

        fig.update_layout(
            dragmode=element.get("_dragmode") or "select",
            uirevision="yes",
            margin={"t": 0, "r": 0, "l": 0, "b": 0},
        )

        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False, coloraxis_showscale=False)

        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )
