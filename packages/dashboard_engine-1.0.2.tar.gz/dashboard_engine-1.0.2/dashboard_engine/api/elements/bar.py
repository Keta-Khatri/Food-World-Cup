import dash_design_kit as ddk
import plotly.express as px
import numpy as np

from ._base_element import BaseElement, Checkbox, RadioItems, DataField
from ..query import Query

from ._helpers import (
    get_column_def,
    make_label,
    make_selection_shapes,
    handle_cartesian_selection,
)


class Bar(BaseElement):
    label = "Bar Chart"
    fields = [
        DataField(
            name="X Axis",
            key="x",
            required=True,
            numeric=100,
            discrete=100,
            datetime=200,
            binners=True,
            top_n_from="y",
        ),
        DataField(name="Y Axis", key="y", required=True, numeric="agg"),
        DataField(
            name="Color",
            key="color",
            required=False,
            numeric="agg",
            discrete=20,
            binners=True,
            top_n_from="y",
        ),
        RadioItems(
            "Bar mode", "barmode", options=["stacked", "grouped"], default="stacked"
        ),
        Checkbox("Show legend", "show_legend", default=True),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def handle_ROOT_selectedData(value, elements, index, data_schema):  # noqa: N802
        handle_cartesian_selection(value, elements, index, data_schema, ["x"])

    @staticmethod
    def get_queries(element) -> list:

        return [
            Query(
                columns=[
                    get_column_def(element, "x", "x"),
                    get_column_def(element, "y", "y"),
                    get_column_def(element, "color", "color"),
                ],
                crossfilters=element.get("selections", []),
                crossfilter_mask_key="crossfilter_mask",
            )
        ]

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        df = query_result.df
        if query_result.is_empty():
            return BaseElement.render_no_data()

        x = element.get("x", None)
        color = element.get("color", None)

        if color and df["color"].dtype == "object":
            # only color in floats has problems displaying data
            df["color"] = df["color"].fillna(" ")

        if df["x"].dtype == "object":
            df["x"] = df["x"].fillna(" ")

        fig = px.bar(
            df,
            x="x",
            y="y",
            color="color" if color else None,
            labels={
                "x": make_label(element, "x"),
                "y": make_label(element, "y"),
                "color": make_label(element, "color"),
            },
            category_orders=query_result.make_category_orders({"x": x, "color": color}),
            color_discrete_map=query_result.make_color_map("color", color),
            color_continuous_scale=query_result.get_colorscale(),
            barmode="relative" if element["barmode"] == "stacked" else "group",
            custom_data=["crossfilter_mask"],  # TODO add PX feature for this in v5
        )
        fig.update_layout(
            dragmode="select",
            hovermode="closest",
            selectdirection="h",
            shapes=make_selection_shapes(element, directions=["x"]),
        )
        for t in fig.data:
            t.selectedpoints = np.where(np.array(t.customdata).ravel())[0]

        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False, coloraxis_showscale=False)
        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )
