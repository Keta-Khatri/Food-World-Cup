from ..dash_imports import ddk, Scheme, Format
from ._helpers import make_label, get_column_list_def
from ..query import Query
from ._base_element import BaseElement, DataFieldList, NumberField

import math

from ..data_schema import NUMERIC_TYPES, DATE_TYPES


def get_datatable_type(col):
    col_type = str(col.dtype)
    if col_type in NUMERIC_TYPES:
        return "numeric"
    elif col_type in DATE_TYPES:
        return "datetime"
    else:
        return "any"


class Table(BaseElement):
    label = "Table"
    fields = [
        DataFieldList(
            "Columns",
            "columns",
            required=True,
            numeric="raw+agg",
            discrete=True,
            datetime=True,
            binners=True,
            number_formatting=True,
        ),
        NumberField(
            "Page Size", "page_size", required=False, default=10, min=1, max=100
        ),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element) -> list:
        return [
            Query(
                columns=get_column_list_def(element["columns"], "column", "col"),
                order_by=[
                    (s["column_id"], s["direction"]) for s in element.get("sort_by", [])
                ],
            )
        ]

    @staticmethod
    def handle_ROOT_page_current(  # noqa: N802
        page_current, elements, index, data_schema
    ):
        elements[index]["page_current"] = page_current

    @staticmethod
    def handle_ROOT_sort_by(sort_by, elements, index, data_schema):  # noqa: N802
        elements[index]["sort_by"] = sort_by

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        if query_result.is_empty():
            return BaseElement.render_no_data()
        df = query_result.df

        # Paging
        page_size = element.get("page_size", 10)
        page_current = min(
            element.get("page_current", 0), math.ceil(df.shape[0] / page_size) - 1
        )

        # Column type and formating
        columns = []
        for i, col in enumerate(sorted(df.columns)):
            datatable_type = get_datatable_type(df[col])

            # Retrieve associated column with this possibly aggregated metric
            column = element["columns"][i]
            col_metadata = {
                "name": make_label(column, "column"),
                "id": col,
                "type": datatable_type,
            }

            # Specify formatting
            format = Format(
                precision=column.get("column_number_precision", None),
                scheme=getattr(Scheme, (column.get("column_number_format", "default"))),
            )
            if column.get("column_thousands_separator", False):
                format = format.group(True)
            col_metadata["format"] = format

            columns.append(col_metadata)

        return ddk.DataTable(
            id=id(),
            columns=columns,
            data=df.iloc[
                page_current * page_size : (page_current + 1) * page_size
            ].to_dict("records"),
            page_size=page_size,
            page_current=page_current,
            page_action="custom",
            sort_by=element.get("sort_by", []),
            sort_action="custom",
            sort_mode="single",
        )
