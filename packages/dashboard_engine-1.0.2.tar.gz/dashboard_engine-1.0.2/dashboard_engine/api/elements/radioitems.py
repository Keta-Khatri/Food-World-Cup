from ..dash_imports import dcc, html
from ._base_element import BaseElement, DataField
from ..query import Query
from ._helpers import make_label


class RadioItems(BaseElement):
    label = "Radio Buttons"
    fields = [
        DataField(
            name="Value",
            key="value",
            required=True,
            numeric=20,
            discrete=20,
            force_selection=True,
        )
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element) -> list:
        return [
            Query(
                crossfilters=element.get(
                    "selections",
                    [{"type": "points", "target": element["value"], "values": []}],
                ),
            )
        ]

    @staticmethod
    def handle_ROOT_value(value, elements, index, data_schema):  # noqa: N802
        # Get this element
        element = elements[index]
        element["selections"] = [
            {"type": "points", "target": element["value"], "values": [value]}
        ]

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        value = None
        for sel in element.get("selections", []):
            if "values" in sel and len(sel["values"]) > 0:
                value = sel["values"][0]
        labels = query_result.order_for_category(element["value"], dropna=True)
        # if nothing was selected (value is None) then the first label is the default
        if value is None:
            # TODO: is len(labels) > 0 always?
            value = labels[0]

        return html.Div(
            [
                html.Div(make_label(element, "value"), className="control--label"),
                html.Div(
                    dcc.RadioItems(
                        id=id(),
                        options=[{"label": label, "value": label} for label in labels],
                        value=value,
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )
