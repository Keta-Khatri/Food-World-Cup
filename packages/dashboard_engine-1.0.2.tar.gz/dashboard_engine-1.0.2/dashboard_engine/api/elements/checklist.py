from ..dash_imports import dcc, html
from ._base_element import BaseElement, DataField
from ._helpers import flatten, make_label
from ..query import Query


class Checklist(BaseElement):
    label = "Checklist"
    fields = [
        DataField(
            name="Value",
            key="value",
            required=True,
            numeric=20,
            discrete=20,
            binners=False,
        )
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                crossfilters=element.get(
                    "selections",
                    [],
                ),
            )
        ]

    @staticmethod
    def handle_ROOT_value(value, elements, index, data_schema):  # noqa: N802
        # Get this element
        element = elements[index]
        if value is None:
            # Delete selections so the default can take over
            element.pop("selections", None)
            return
        element["selections"] = [
            {"type": "points", "target": element["value"], "values": [v for v in value]}
        ]

    @staticmethod
    def render(id, element, query_results):
        query_result = query_results[0]
        values = []
        for sel in element.get("selections", []):
            for pt in sel["values"]:
                values.append(pt)

        values = list(flatten(values))
        element_value = element.get("value", None)
        labels = (
            query_result.order_for_category(element_value, dropna=True)
            if element_value is not None
            else []
        )

        return html.Div(
            [
                html.Div(make_label(element, "value"), className="control--label"),
                html.Div(
                    dcc.Checklist(
                        id=id(),
                        options=[{"label": label, "value": label} for label in labels],
                        value=values,
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )
