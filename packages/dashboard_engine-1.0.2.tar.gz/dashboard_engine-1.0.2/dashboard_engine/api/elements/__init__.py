from .dropdown import Dropdown
from .scatter import Scatter
from .scattermapbox import ScatterMapbox
from .table import Table
from .bar import Bar
from .indicator import Indicator
from .reset import Reset
from .daterangepicker import DateRangePicker
from .line import Line
from .rangeslider import RangeSlider
from .checklist import Checklist
from .radioitems import RadioItems
from .pivottable import PivotTable
from .raster import Raster
from .rastermapbox import RasterMapbox


def builtin_elements(exclude=[], include_raster=False):
    """
    Get a list of built-in Element classes to pass into
    `DashboardEngine(element_types=)`.

    Arguments:
        - `exclude`: names (`label`) of elements to exclude
        - `include_raster`: should Raster elements be included? Note: when
        setting this to `True`, ensure that the `theme` argument of
        `DashboardEngine` is set to a valid DDK Theme object.

    Returns:
        - `element_types` (list): list of element classes.
    """
    all = [
        Bar,
        Scatter,
        Raster,
        Line,
        ScatterMapbox,
        RasterMapbox,
        PivotTable,
        Table,
        Indicator,
        Dropdown,
        DateRangePicker,
        RangeSlider,
        Checklist,
        RadioItems,
        Reset,
    ]

    if not include_raster:
        all.remove(RasterMapbox)
        all.remove(Raster)

    return [element for element in all if element.label not in exclude]
