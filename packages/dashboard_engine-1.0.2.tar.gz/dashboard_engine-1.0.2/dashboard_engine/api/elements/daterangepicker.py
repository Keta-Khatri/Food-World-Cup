from ..dash_imports import dcc, html
from ..query import Query
from ._base_element import BaseElement, DataField
from ._helpers import make_label


def get_date_range(element):
    selection = element.get("selections", [])
    if len(selection) == 0:
        return [None, None]
    else:
        return selection[0]["bounds"]


class DateRangePicker(BaseElement):
    label = "Date Range Picker"
    fields = [
        DataField(
            name="Date column", key="date", required=True, datetime=True, binners=False
        )
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                crossfilters=element.get("selections", []),
            )
        ]

    @staticmethod
    def handle_ROOT_start_date(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        _, end_date = get_date_range(element)
        element["selections"] = [
            {"type": "range", "target": element["date"], "bounds": [value, end_date]}
        ]

    @staticmethod
    def handle_ROOT_end_date(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        start_date, _ = get_date_range(element)
        element["selections"] = [
            {"type": "range", "target": element["date"], "bounds": [start_date, value]}
        ]

    @staticmethod
    def render(id, element, query_results: list):

        start_date, end_date = get_date_range(element)

        return html.Div(
            [
                html.Div(make_label(element, "date"), className="control--label"),
                html.Div(
                    dcc.DatePickerRange(
                        id=id(), start_date=start_date, end_date=end_date
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )
