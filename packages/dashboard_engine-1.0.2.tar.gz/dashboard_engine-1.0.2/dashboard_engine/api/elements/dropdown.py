from ..dash_imports import dcc, html
from ._helpers import flatten, make_label
from ..query import Query
from ._base_element import BaseElement, Checkbox, DataField


class Dropdown(BaseElement):
    label = "Dropdown Menu"
    fields = [
        DataField(
            name="Value",
            key="value",
            required=True,
            numeric=500,
            discrete=500,
            force_selection="clearable",
        ),
        Checkbox("Clearable", "clearable", default=True),
        Checkbox("Allow multiple selections", "multi"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                crossfilters=element.get("selections", []),
            )
        ]

    @staticmethod
    def handle_ROOT_value(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        if value is None:
            # Delete selections so the default can take over
            element.pop("selections", None)
            return

        if isinstance(value, str) or not hasattr(value, "__iter__"):
            value = [value]
        element["selections"] = [
            {"type": "points", "target": element["value"], "values": [v for v in value]}
        ]

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        multi = element["multi"]
        value = []
        for sel in element.get("selections", []):
            for pt in sel["values"]:
                value.append(pt)

        value = list(flatten(value))
        labels = query_result.order_for_category(element["value"], dropna=True)
        if not multi:
            value = value[0] if len(value) > 0 else None

        return html.Div(
            [
                html.Div(make_label(element, "value"), className="control--label"),
                html.Div(
                    dcc.Dropdown(
                        id=id(),
                        options=[{"label": label, "value": label} for label in labels],
                        multi=multi,
                        value=value,
                        clearable=element["clearable"],
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )
