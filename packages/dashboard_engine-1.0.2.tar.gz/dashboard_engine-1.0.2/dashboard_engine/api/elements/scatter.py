import dash_design_kit as ddk

from ._helpers import (
    make_selection_shapes,
    make_label,
    handle_cartesian_selection,
    get_column_def,
    update_axis,
    make_2d_range_selection,
    handle_cartesian_relayout,
)
import pandas as pd
import plotly.express as px
import numpy as np
from ..query import Query
from ._base_element import BaseElement, Checkbox, DataField


class Scatter(BaseElement):
    label = "Scatter Plot"
    fields = [
        DataField(
            name="X Axis",
            key="x",
            required=True,
            numeric="raw+agg",
            discrete=True,
            datetime=True,
            binners=True,
        ),
        DataField(
            name="Y Axis",
            key="y",
            required=True,
            numeric="raw+agg",
            discrete=True,
            datetime=True,
            binners=True,
        ),
        DataField(
            name="Color",
            key="color",
            required=False,
            numeric="agg",
            discrete=20,
            binners=True,
        ),
        DataField(
            name="Size",
            key="size",
            required=False,
            numeric="agg",
        ),
        Checkbox("Show legend", "show_legend", default=True),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [
            Query(
                columns=[
                    get_column_def(element, "x", "x"),
                    get_column_def(element, "y", "y"),
                    get_column_def(element, "color", "color"),
                    get_column_def(element, "size", "size"),
                ],
                crossfilters=element.get("selections", []),
                filters=make_2d_range_selection(element),
                crossfilter_mask_key="crossfilter_mask",
            )
        ]

    @staticmethod
    def handle_ROOT_relayoutData(value, elements, index, data_schema):  # noqa: N802
        handle_cartesian_relayout(value, elements, index, data_schema)

    @staticmethod
    def handle_ROOT_selectedData(value, elements, index, data_schema):  # noqa: N802
        handle_cartesian_selection(value, elements, index, data_schema, ["x", "y"])

    @staticmethod
    def render(id, element, query_results: list):

        query_result = query_results[0]
        if query_result.is_empty() and not element.get("range", {}):
            return BaseElement.render_no_data()

        if query_result.is_empty():
            df = pd.DataFrame(
                {"x": [], "y": [], "color": [], "size": [], "crossfilter_mask": []}
            )
        else:
            threshold = 100_000
            if query_result.df.shape[0] >= threshold:
                return Scatter.render_too_much_data(threshold)
            df = query_result.df

        x = element["x"]
        y = element["y"]
        color = element.get("color", None)
        size = element.get("size", None)

        if size:
            # only size in floats has problems displaying data
            df["size"] = df["size"].fillna(0.0)

        if color and df["color"].dtype == "object":
            # only color in floats has problems displaying data
            df["color"] = df["color"].fillna(" ")

        if df["x"].dtype == "object":
            df["x"] = df["x"].fillna(" ")

        if df["y"].dtype == "object":
            df["y"] = df["y"].fillna(" ")

        fig = px.scatter(
            df,
            x="x",
            y="y",
            color="color" if color else None,
            size="size" if size else None,
            labels={
                "x": make_label(element, "x"),
                "y": make_label(element, "y"),
                "size": make_label(element, "size"),
                "color": make_label(element, "color"),
            },
            category_orders=query_result.make_category_orders(
                {"x": x, "y": y, "color": color}
            ),
            color_discrete_map=query_result.make_color_map("color", color),
            color_continuous_scale=query_result.get_colorscale(),
            custom_data=["crossfilter_mask"],
        )
        for t in fig.data:
            t.selectedpoints = np.where(np.array(t.customdata).ravel())[0]

        fig.update_layout(shapes=make_selection_shapes(element))

        fig.update_layout(dragmode=element.get("_dragmode", "select"), uirevision="yes")
        update_axis(fig, element)

        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False, coloraxis_showscale=False)

        return ddk.Graph(
            id=id(),
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )
