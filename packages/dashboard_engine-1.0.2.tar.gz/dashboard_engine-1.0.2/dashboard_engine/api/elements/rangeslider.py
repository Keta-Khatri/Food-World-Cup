from ..dash_imports import dcc, html
from ._base_element import BaseElement, DataField
from ..query import Query
from ._helpers import make_label

N_MARKS = 5


def calc_marks(minval, maxval, n_marks=N_MARKS):
    if n_marks < 2:
        raise ValueError("Must have 2 or more marks, not %d." % (n_marks,))
    lval = minval
    rval = maxval
    diff = maxval - minval
    middlevals = [minval + diff * v / (n_marks - 1) for v in range(1, n_marks - 1)]
    return [lval] + middlevals + [rval]


def fltfmt(f):
    """convert floats to strings in a unified way"""
    return "%.2f" % (f,)


NUMBERSTEP = 0.01


class RangeSlider(BaseElement):
    label = "Range Slider"
    fields = [
        DataField(name="Value", key="value", required=True, numeric="raw"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def get_queries(element):
        return [Query(crossfilters=element.get("selections", []))]

    @staticmethod
    def handle_slider_value(value, elements, index, data_schema):  # noqa: N802
        # Get this element
        element = elements[index]
        element["selections"] = [
            {"type": "range", "target": element["value"], "bounds": value}
        ]

    @staticmethod
    def handle_leftinput_value(value, elements, index, data_schema):  # noqa: N802
        # Get this element
        element = elements[index]
        old_selections = element.get("selections", [])
        column = element["value"]
        rval = data_schema.max_value(column)
        lval = data_schema.min_value(column)
        if value is None:
            value = lval
        if len(old_selections) > 0:
            rval = old_selections[0]["bounds"][1]
        element["selections"] = [
            {"type": "range", "target": element["value"], "bounds": [value, rval]}
        ]

    @staticmethod
    def handle_rightinput_value(value, elements, index, data_schema):  # noqa: N802
        # Get this element
        element = elements[index]
        old_selections = element.get("selections", [])
        column = element["value"]
        rval = data_schema.max_value(column)
        lval = data_schema.min_value(column)
        if value is None:
            value = rval
        if len(old_selections) > 0:
            lval = old_selections[0]["bounds"][0]
        element["selections"] = [
            {"type": "range", "target": element["value"], "bounds": [lval, value]}
        ]

    @staticmethod
    def render(id, element, query_results: list):
        value = None
        for sel in element.get("selections", []):
            if "bounds" in sel and len(sel["bounds"]) == 2:
                value = sel["bounds"]

        data_schema = query_results[0].data_schema
        min_val = data_schema.min_value(element["value"])
        max_val = data_schema.max_value(element["value"])

        marks = calc_marks(min_val, max_val)
        markticks = {float(k): fltfmt(k) for k in marks}
        if value is None:
            value = [min_val, max_val]

        return html.Div(
            [
                html.Div(make_label(element, "value"), className="control--label"),
                html.Div(
                    [
                        dcc.Input(
                            id=id("leftinput"),
                            value=fltfmt(value[0]),
                            debounce=True,
                            type="number",
                            min=min_val,
                            max=max_val,
                            style=dict(width="25%"),
                        ),
                        html.Div(
                            dcc.RangeSlider(
                                id=id("slider"),
                                min=min_val,
                                max=max_val,
                                value=value,
                                marks=markticks,
                                step=NUMBERSTEP,
                            ),
                        ),
                        dcc.Input(
                            id=id("rightinput"),
                            value=fltfmt(value[1]),
                            debounce=True,
                            type="number",
                            min=min_val,
                            max=max_val,
                            style=dict(width="25%"),
                        ),
                    ],
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )
