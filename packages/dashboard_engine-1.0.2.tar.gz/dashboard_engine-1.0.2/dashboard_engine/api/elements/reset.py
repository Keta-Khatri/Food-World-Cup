from ..dash_imports import html
from ._base_element import BaseElement, TextField


class Reset(BaseElement):
    label = "'Clear selections' button"
    fields = [TextField(name="Button text", key="text", required=False)]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def handle_ROOT_n_clicks(value, elements, index, data_schema):  # noqa: N802
        for element in elements:
            if "selections" in element:
                del element["selections"]

    @staticmethod
    def render(id, element, query_results: list):
        return html.Button(element.get("text") or "Clear selections", id=id())
