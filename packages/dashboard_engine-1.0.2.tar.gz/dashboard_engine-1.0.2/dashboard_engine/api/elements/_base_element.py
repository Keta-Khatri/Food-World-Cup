from ..dash_imports import dcc, html, ddk
from collections import defaultdict
from ._helpers import (
    discrete_aggfuncs,
    aggfuncs,
    weightable_aggfuncs,
    datetime_binning_options,
    aggfunc_labels,
    nearest_pow10,
)
from dash import callback_context as ctx
import json


def triggered_child_id():
    return json.loads((".".join(ctx.triggered[0]["prop_id"].split(".")[:-1]))).get(
        "child-id"
    )


def _label_wrapper(name, required):
    if required:
        return name + "*"
    else:
        return name


def _label_style_wrapper(required, value, extra):
    if required:
        if value is None:
            extra.update({"fontWeight": "bold"})
        else:
            extra.update({"fontWeight": "normal"})
    return extra


def _none_or_out_of_range(x, lower, upper):
    return x is None or not (lower <= x <= upper)


def _not_none_but_out_of_range(x, lower, upper):
    return x is not None and not (lower <= x <= upper)


def _is_None_or_none(x):  # noqa: N802
    return x is None or x == "none"


formatters = {
    "Default": "default",
    "Decimal": "decimal",
    "Decimal or integer": "decimal_integer",
    "Decimal or exponent": "decimal_or_exponent",
    "Decimal with SI Suffix": "decimal_si_prefix",
    "Exponent": "exponent",
    "Fixed": "fixed",
    "Percentage": "percentage",
    "Percentage (rounded)": "percentage_rounded",
    "Binary": "binary",
    "Octal": "octal",
    "Hexadecimal (lowercase)": "lower_case_hex",
    "Hexadecimal (uppercase)": "upper_case_hex",
    "Unicode": "unicode",
}


def _render_data_problem(description):
    children = [ddk.Icon(icon_name="square", icon_category="regular")]

    children.append(html.P(description, style={"fontSize": "20px"}))

    return html.Div(
        className="placeholder", children=children
    )  # TODO: get DDK's theme color


class BaseElement:
    def __init__(self, **kwargs):  # part of legacy CanvasConfig system
        self._config = kwargs

    @classmethod
    def render_no_data(cls):
        return _render_data_problem("No data available")

    @classmethod
    def render_too_much_data(cls, threshold):
        return _render_data_problem(
            f"{cls.label} cannot render more than {threshold:,} points."
        )

    @classmethod
    def validate_and_coerce(cls, data_schema, element):
        # TODO typo-detection by rejecting unexpected values in element?
        first_missing_message = None
        top_n_from = []
        for field in cls.fields:
            if getattr(field, "top_n_from", None) is not None:
                top_n_from.append(getattr(field, "top_n_from"))

        # if one field (e.g. X) has top_n_from another (e.g. Y)
        # then coerce Y first, so X can rely on its values
        reordered_fields = sorted(
            cls.fields,
            key=lambda f: -1 if f.key in top_n_from else cls.fields.index(f),
        )
        for field in reordered_fields:
            value = element.get(field.key)
            if value is None and field.required:
                if first_missing_message is None:
                    first_missing_message = f"Field '{field.name}' is required."
            else:
                try:
                    field.validate_and_coerce(data_schema, element, element)
                except ValidationException as e:
                    return dict(message=str(e))
        if first_missing_message:
            return dict(message=first_missing_message)
        return None

    @classmethod
    def render_editor(cls, id, element, query_result):
        result = []
        no_card_controls = []
        for field in cls.fields:
            controls = field.controls(id, element, query_result)
            if isinstance(controls, ddk.ControlCard):
                if len(no_card_controls):
                    result.append(
                        ddk.ControlCard(no_card_controls, style={"marginBottom": "0px"})
                    )
                    no_card_controls = []
                result.append(controls)
            else:
                no_card_controls += controls
        if len(no_card_controls):
            result.append(
                ddk.ControlCard(no_card_controls, style={"marginBottom": "0px"})
            )
            no_card_controls = []
        return html.Div(result)

    @classmethod
    def handle_editor_ALL_value(cls, value, elements, i, data_schema):  # noqa: N802
        for field in cls.fields:
            field.handle_value(value, elements[i], data_schema)

    @classmethod
    def handle_editor_ALL_n_clicks(cls, value, elements, i, data_schema):  # noqa: N802
        for field in cls.fields:
            field.handle_n_clicks(value, elements[i], data_schema)


class ValidationException(Exception):
    pass


def has_countable(functions):
    for c in functions:
        if "count" in functions[c]:
            return True
    return False


class DataField:
    _accepted_numeric_arguments = [
        "False",
        '"raw"',
        '"agg"',
        '"raw+agg"',
        "a non-negative integer",
    ]

    def _numeric_arg_value_error(self):
        return ValueError(
            "Accepted arguments for numeric are: "
            + ", ".join(DataField._accepted_numeric_arguments)
            + ". Got %s." % (str(self.numeric),)
        )

    def __init__(
        self,
        name,
        key,
        required,
        numeric=False,
        discrete=False,
        datetime=False,
        binners=False,
        force_selection=False,
        top_n_from=None,
        number_formatting=False,
        label=True,
    ):
        """
        A way for an element to bind a key to some data function Args:
        - numeric: False, number or flaglist("raw", "agg") - controls if/which
          numeric outputs can be bound (either none, cardinality-limited if a
          number, or raw and/or aggregated values)
        - discrete: False, number or True - controls if/which discrete outputs
          can be bound (either none, cardinality-limited if a number, or any
          cardinality)
        - datetime: False, number or True  - controls if/which datetime outputs
          can be bound (either none, cardinality-limited if a number, or any
          cardinality)
        - binners: boolean - controls whether or not
          numeric_bin/datetime_bin/top_n are included as options to deal with
          cardinality (eventually should disappear, once top-N 'other' selection
          is resolved)
        - force_selection: boolean or string - controls whether or not a
          selection is always required for this field. string means "depends on
          the named key" (used in Dropdown and Radio Buttons)
        - top_n_from_y: boolean - controls whether or not the top_n sorting
          function should implicitly be the one from the "y" key (used in Bar
          and Line)
        - number_formatting: boolean - show number-formatting controls (used in
          Table)
        - label: boolean - show custom-label controls (used in Table and
          Indicator, eventually everywhere)
        """
        # TODO min/max on the values, for lon/lat bounds?
        self.name = name
        self.key = key
        self.required = required
        self.numeric = numeric
        self.discrete = discrete
        self.datetime = datetime
        self.binners = binners
        self.force_selection = force_selection
        self.number_formatting = number_formatting
        self.label = label

        if not binners or top_n_from:
            self.top_n_from = top_n_from
        else:
            self.top_n_from = None

        if "_top_n_col" not in key:
            self.top_n_col_field = DataField(
                f"Sort {self.name} Top-N by",
                key + "_top_n_col",
                True,
                numeric="agg",
            )

    def handle_n_clicks(self, value, element, data_schema):
        pass

    def handle_value(self, value, element, data_schema):
        for suffix in [
            "",
            "_aggfunc",
            "_weighted_by",
            "_top_n_number",
            "_top_n_col_weighted_by",
            "_top_n_col_aggfunc",
            "_top_n_col",
            # "_include_others",
            "_datetime_binsize",
            "_binsize",
            "_label",
            "_number_precision",
            "_number_format",
            "_thousands_separator",
        ]:
            key = self.key + suffix
            if value.get(key) is not None:
                # generally easier not to drag around Nones
                if suffix in [
                    # "_include_others",
                    "_thousands_separator"
                ]:
                    element[key] = len(value[key]) > 0
                else:
                    element[key] = value[key]
            else:
                # if they're none now, erase the previous value
                element.pop(key, None)

    def _feasible_datetime_bin_opts(self, data_schema, value):
        if value not in data_schema.dates():
            return []
        if isinstance(self.datetime, int) and not isinstance(self.datetime, bool):
            return [
                x
                for x in datetime_binning_options
                if data_schema.datebinned_cardinality(value, x) <= self.datetime
            ]
        else:
            return datetime_binning_options

    def _auto_numeric_bin_size(self, value, data_schema):
        if (
            value in data_schema.numeric()
            and isinstance(self.numeric, int)
            and data_schema.cardinality(value) > self.numeric
        ):
            return nearest_pow10(
                (data_schema.max_value(value) - data_schema.min_value(value))
                / self.numeric
            )
        return None

    def validate_and_coerce(self, data_schema, element, context):
        value = element.get(self.key)
        if value is None:
            return
        functions = self.functions_for_columns(data_schema)
        if value not in functions and value != "__count__":
            raise ValidationException(f"Invalid value for '{self.name}'")

        # Automatically set _top_n_number if there are too many discrete values
        # (categories, say) on an axis
        if (
            value in data_schema.discrete()
            and isinstance(self.discrete, int)
            and (not isinstance(self.discrete, bool))
            and data_schema.cardinality(value) > self.discrete
            and _none_or_out_of_range(
                element.get(self.key + "_top_n_number"),
                0,
                min(self.discrete, data_schema.cardinality(value)),
            )
            and _is_None_or_none(element.get(self.key + "_aggfunc"))
        ):
            element[self.key + "_top_n_number"] = self.discrete
            element[self.key + "_aggfunc"] = "top_n"
        elif (
            value in data_schema.discrete()
            and (not isinstance(self.discrete, bool))
            and _not_none_but_out_of_range(
                element.get(self.key + "_top_n_number"),
                0,
                min(self.discrete, data_schema.cardinality(value)),
            )
        ):
            element[self.key + "_top_n_number"] = data_schema.cardinality(value)
            element[self.key + "_aggfunc"] = "top_n"

        # Automatically set a bin size if there are too many datapoints on a
        # numeric axis
        if (
            element.get(self.key + "_aggfunc") is None
            or element.get(self.key + "_aggfunc") == "none"
        ) and element.get(self.key + "_binsize") is None:
            auto_bin_size = self._auto_numeric_bin_size(value, data_schema)
            if auto_bin_size is not None:
                element[self.key + "_aggfunc"] = "numerical_bin"
                element[self.key + "_binsize"] = auto_bin_size

        if value == "__count__":
            element[self.key + "_aggfunc"] = "count"
            element[self.key] = list(functions.keys())[0]
        value = element.get(self.key)

        # TODO remove this eventually... hack to emulate former behaviour
        # by detecting aggfunc based on presence of arguments alone
        if element.get(self.key + "_aggfunc") is None:
            if element.get(self.key + "_binsize"):
                element[self.key + "_aggfunc"] = "numerical_bin"
            elif element.get(self.key + "_datetime_binsize"):
                element[self.key + "_aggfunc"] = "datetime_bin"
            elif element.get(self.key + "_top_n_number"):
                element[self.key + "_aggfunc"] = "top_n"

        if element.get(self.key + "_aggfunc") not in functions[value]:
            element[self.key + "_aggfunc"] = functions[value][0]
        aggfunc = element.get(self.key + "_aggfunc")

        # clear out inapplicable aggfunc args e.g. when user switches aggfunc
        if aggfunc not in weightable_aggfuncs:
            element.pop(self.key + "_weighted_by", None)
        if aggfunc != "top_n":
            element.pop(self.key + "_top_n_number", None)
            element.pop(self.key + "_include_others", None)
            element.pop(self.key + "_top_n_col_weighted_by", None)
            element.pop(self.key + "_top_n_col_aggfunc", None)
            element.pop(self.key + "_top_n_col", None)
        if aggfunc != "datetime_bin":
            element.pop(self.key + "_datetime_binsize", None)
        if aggfunc != "numerical_bin":
            element.pop(self.key + "_binsize", None)

        if aggfunc == "top_n" and element.get(self.key + "_top_n_number"):
            if self.top_n_from:
                element[self.key + "_top_n_col_weighted_by"] = context.get(
                    self.top_n_from + "_weighted_by"
                )
                element[self.key + "_top_n_col_aggfunc"] = context.get(
                    self.top_n_from + "_aggfunc"
                )
                element[self.key + "_top_n_col"] = context.get(self.top_n_from)
            else:
                self.top_n_col_field.validate_and_coerce(data_schema, element, element)
            if not element.get(self.key + "_top_n_col_aggfunc") or not element.get(
                self.key + "_top_n_col"
            ):
                raise ValidationException(
                    f"Incomplete Top-N specification for {self.name}"
                )

        # Force datetime binsize to one in the list of reasonable ones
        if value in data_schema.dates():
            dt_bin_opts = self._feasible_datetime_bin_opts(data_schema, value)
            if element.get(self.key + "_datetime_binsize") not in dt_bin_opts:
                if len(dt_bin_opts) > 0:
                    element[self.key + "_datetime_binsize"] = dt_bin_opts[0]
                else:
                    raise ValidationException(
                        'No feasible datetime bin size for "{value}".'.format(
                            value=value
                        )
                    )
        else:
            element.pop(self.key + "_datetime_binsize", None)

        if self.number_formatting:
            if aggfunc in ["count", "count_unique"] or data_schema.is_numeric(value):
                element[self.key + "_thousands_separator"] = element.get(
                    self.key + "_thousands_separator", True
                )
            else:
                element.pop(self.key + "_number_format", None)
                element.pop(self.key + "_number_precision", None)
                element.pop(self.key + "_thousands_separator", None)

        if self.force_selection:  # dropdown, radio-items
            # if the selections are wrong somehow, clear them out
            selections = element.get("selections", [])
            if "selections" in element and (
                len(selections) == 0
                or len(selections[0]["values"]) == 0
                or selections[0]["target"] != value
            ):
                del element["selections"]

            if self.force_selection is True or not element.get(
                self.force_selection, False
            ):
                if not element.get("selections"):
                    element["selections"] = [
                        {
                            "type": "points",
                            "target": value,
                            "values": [data_schema.first_value(value)],
                        }
                    ]

    def controls(self, id, element, query_result):
        data_schema = query_result[0].data_schema
        controls = []
        value = element.get(self.key)
        functions = self.functions_for_columns(data_schema)
        count_func = []
        if has_countable(functions):
            count_func = [{"label": "Count", "value": "__count__"}]
        aggfunc = element.get(self.key + "_aggfunc")
        if aggfunc == "count":
            value = "__count__"

        controls.append(
            ddk.ControlItem(
                dcc.Dropdown(
                    id=id(self.key, strict=False),
                    options=count_func
                    + [{"label": x, "value": x} for x in functions.keys()],
                    value=value,
                    clearable=not self.required,
                ),
                label=_label_wrapper(self.name, self.required),
                label_style=_label_style_wrapper(
                    self.required, value, {"paddingBottom": "0px"}
                ),
            )
        )

        if value:
            column_functions = functions[value]
            if value != "__count__" and len(column_functions) > 1:
                controls.append(
                    ddk.ControlItem(
                        dcc.Dropdown(
                            id=id(self.key + "_aggfunc", strict=False),
                            options=[
                                {"label": aggfunc_labels[x], "value": x}
                                for x in column_functions
                                if x != "count"
                            ],
                            value=aggfunc,
                            clearable=False,
                        ),
                        label=_label_wrapper(f"{self.name} Function", self.required),
                        label_style=_label_style_wrapper(
                            self.required, aggfunc, {"paddingBottom": "0px"}
                        ),
                        style={"paddingLeft": "30px"},
                    )
                )
            if aggfunc in weightable_aggfuncs:
                weighted_by = element.get(self.key + "_weighted_by")
                controls.append(
                    ddk.ControlItem(
                        dcc.Dropdown(
                            id=id(self.key + "_weighted_by", strict=False),
                            options=[
                                {"label": x, "value": x}
                                for x in data_schema.numeric()
                                if x != value
                            ],
                            value=weighted_by,
                        ),
                        label=f"{self.name} Weighted By",
                        label_style={"paddingBottom": "0px"},
                        style={"paddingLeft": "30px"},
                    )
                )
            elif aggfunc == "top_n":
                top_n_max = None
                if value in data_schema.discrete():
                    top_n_max = min(
                        data_schema.cardinality(value),
                        self.discrete
                        if not isinstance(self.discrete, bool)
                        else float("inf"),
                    )
                top_n_number = element.get(self.key + "_top_n_number")
                controls.append(
                    ddk.ControlItem(
                        dcc.Input(
                            id=id(self.key + "_top_n_number", strict=False),
                            value=top_n_number,
                            type="number",
                            min=0,
                            max=top_n_max,
                        ),
                        label=f"Limit {self.name} to top N values",
                        label_style={"paddingBottom": "0px"},
                        style={"paddingLeft": "30px"},
                    )
                )
                if top_n_number:
                    if False:
                        include_others = element.get(
                            self.key + "_include_others", False
                        )
                        text = "Include Others"
                        controls.append(
                            ddk.ControlItem(
                                dcc.Checklist(
                                    id=id(self.key + "_include_others", strict=False),
                                    value=[text] if include_others else [],
                                    options=[{"label": text, "value": text}],
                                ),
                                style={"paddingLeft": "30px"},
                            )
                        )

                    if self.top_n_from is None:
                        controls += self.top_n_col_field.controls(
                            id, element, query_result
                        ).children

            elif aggfunc == "datetime_bin":
                dt_bin_opts = self._feasible_datetime_bin_opts(data_schema, value)
                binsize = element.get(self.key + "_datetime_binsize", "none")
                controls.append(
                    ddk.ControlItem(
                        dcc.Dropdown(
                            id=id(self.key + "_datetime_binsize", strict=False),
                            options=[{"label": x, "value": x} for x in dt_bin_opts],
                            value=binsize,
                        ),
                        label=f"{self.name} Binned By",
                        label_style={"paddingBottom": "0px"},
                        style={"paddingLeft": "30px"},
                    )
                )
            elif aggfunc == "numerical_bin":
                # getting auto_bin_size to see if we need to set the min
                auto_bin_size = self._auto_numeric_bin_size(value, data_schema)
                binsize = element.get(self.key + "_binsize")
                controls.append(
                    ddk.ControlItem(
                        dcc.Input(
                            id=id(self.key + "_binsize", strict=False),
                            value=binsize,
                            type="number",
                            min=auto_bin_size if auto_bin_size is not None else 0,
                        ),
                        label=f"{self.name} Binned By",
                        label_style={"paddingBottom": "0px"},
                        style={"paddingLeft": "30px"},
                    )
                )

        format_controls = []

        if value and self.label:
            label = element.get(self.key + "_label")
            format_controls.append(
                ddk.ControlItem(
                    dcc.Input(
                        id=id(self.key + "_label", strict=False),
                        value=label,
                    ),
                    label="Custom Label",
                    label_style={"paddingBottom": "0px"},
                )
            )

        if (
            value
            and self.number_formatting
            and (aggfunc in ["count", "count_unique"] or data_schema.is_numeric(value))
        ):
            format = element.get(self.key + "_number_format", "default")
            format_controls.append(
                ddk.ControlItem(
                    dcc.Dropdown(
                        id=id(self.key + "_number_format", strict=False),
                        value=format,
                        options=[
                            {"label": k, "value": formatters[k]} for k in formatters
                        ],
                    ),
                    label="Number Format",
                    label_style={"paddingBottom": "0px"},
                )
            )
            precision = element.get(self.key + "_number_precision")
            format_controls.append(
                ddk.ControlItem(
                    dcc.Input(
                        id=id(self.key + "_number_precision", strict=False),
                        value=precision,
                        type="number",
                        min=0,
                    ),
                    label="Number Precision",
                    label_style={"paddingBottom": "0px"},
                )
            )
            separator = element.get(self.key + "_thousands_separator", True)
            text = "Thousands Separator"
            format_controls.append(
                ddk.ControlItem(
                    dcc.Checklist(
                        id=id(self.key + "_thousands_separator", strict=False),
                        value=[text] if separator else [],
                        options=[{"label": text, "value": text}],
                    ),
                )
            )

        if len(format_controls) > 0:
            controls.append(
                html.Details(
                    [
                        html.Summary("Display Options", style={"fontSize": "14px"}),
                        ddk.ControlCard(
                            format_controls,
                            type="flat",
                            style={"margin": 0, "width": "100%"},
                        ),
                    ],
                    style={"margin": "5px 15px"},
                )
            )

        return ddk.ControlCard(controls, style={"marginBottom": "0px"})

    def functions_for_columns(self, data_schema):
        functions = defaultdict(list)

        if isinstance(self.numeric, bool) and self.numeric:
            raise self._numeric_arg_value_error()
        if isinstance(self.numeric, str):
            if not any(s == self.numeric for s in ["raw", "agg", "raw+agg"]):
                raise self._numeric_arg_value_error()

            if "raw" in self.numeric:
                for c in data_schema.numeric():
                    functions[c].insert(0, "none")

            if "agg" in self.numeric:
                for c in data_schema.numeric():
                    functions[c] += aggfuncs
                for c in data_schema.non_numeric():
                    functions[c] += discrete_aggfuncs
        elif self.numeric is not False and isinstance(self.numeric, int):
            if self.numeric < 0:
                raise self._numeric_arg_value_error()
            for c in data_schema.numeric():
                if self.binners:
                    functions[c] += ["numerical_bin"]
                if data_schema.cardinality(c) <= self.numeric:
                    functions[c].insert(0, "none")

        if self.discrete is True:
            for c in data_schema.discrete():
                functions[c].insert(0, "none")
                if self.binners:
                    functions[c] += ["top_n"]
        elif self.discrete is not False and isinstance(self.discrete, int):
            for c in data_schema.discrete():
                if self.binners:
                    functions[c] += ["top_n"]
                if data_schema.cardinality(c) <= self.discrete:
                    functions[c].insert(0, "none")

        if self.datetime is True:
            for c in data_schema.dates():
                functions[c].insert(0, "none")
                if self.binners:
                    if len(self._feasible_datetime_bin_opts(data_schema, c)) > 0:
                        functions[c] += ["datetime_bin"]
        elif self.datetime is not False and isinstance(self.datetime, int):
            for c in data_schema.dates():
                if self.binners:
                    if len(self._feasible_datetime_bin_opts(data_schema, c)) > 0:
                        functions[c] += ["datetime_bin"]
                if data_schema.cardinality(c) <= self.datetime:
                    functions[c].insert(0, "none")

        display_order = [
            "none",
            "top_n",
            "datetime_bin",
            "numerical_bin",
            "mean",
            "sum",
            "min",
            "max",
            "std",
            "count_unique",
            "count",
        ]
        for c in functions:
            functions[c] = sorted(functions[c], key=lambda v: display_order.index(v))

        return functions


class DataFieldList:
    def __init__(
        self,
        name,
        key,
        required=False,
        numeric=False,
        discrete=False,
        datetime=False,
        binners=False,
        number_formatting=False,
        label=True,
        top_n_from=None,
    ):
        self.name = name
        self.key = key
        self.required = required
        self.data_field = DataField(
            name="Value",
            key="column",
            required=required,
            numeric=numeric,
            discrete=discrete,
            datetime=datetime,
            binners=binners,
            number_formatting=number_formatting,
            label=label,
            top_n_from=top_n_from,
        )

    def handle_n_clicks(self, value, element, data_schema):
        id = triggered_child_id()
        if id.startswith(self.key):
            values = element.get(self.key, [])
            if "add" in id:
                values.append({})
            if "delete" in id:
                i = int(id.split("_")[-1])
                del values[i]
            if "swap" in id:
                i = int(id.split("_")[-1])
                if 0 < i < len(values):
                    values[i], values[i - 1] = values[i - 1], values[i]
            element[self.key] = values

    def handle_value(self, value, element, data_schema):
        for i, sub_element in enumerate(element.get(self.key, [])):
            sub_value = value.get(self.key, [])[i]
            self.data_field.handle_value(sub_value, sub_element, data_schema)

    def validate_and_coerce(self, data_schema, element, context):
        element[self.key] = element.get(self.key, [])
        for sub_element in element.get(self.key, []):
            self.data_field.validate_and_coerce(data_schema, sub_element, element)

    def controls(self, id, element, query_result):
        controls = [
            html.P(
                _label_wrapper(self.name, self.required), style={"marginBottom": "0px"}
            )
        ]
        sub_elements = element.get(self.key, [])
        for i, sub_element in enumerate(sub_elements):
            sub_control = self.data_field.controls(
                lambda child_id, strict: id(f"{self.key}[{i}].{child_id}", strict),
                sub_element,
                query_result,
            )
            sub_control.children.insert(
                0,
                html.P(
                    children=[
                        html.A(
                            id=id(f"{self.key}_swap_{i}", strict=False),
                            children=["↑ Up"],
                            style={
                                "margin": "0 5px",
                                "opacity": 1 if i > 0 else 0.5,
                            },
                        ),
                        html.A(
                            id=id(f"{self.key}_swap_{i+1}", strict=False),
                            children=["↓ Down"],
                            style={
                                "margin": "0 5px",
                                "opacity": 1 if i < len(sub_elements) - 1 else 0.5,
                            },
                        ),
                        html.A(
                            id=id(f"{self.key}_delete_{i}", strict=False),
                            children=["× Delete"],
                            style={"margin": "0 5px"},
                        ),
                    ],
                    style={
                        "width": "100%",
                        "textAlign": "center",
                        "fontSize": "15px",
                        "margin": "5px",
                    },
                ),
            )
            controls.append(sub_control)
        controls.append(
            html.Button(
                id=id(self.key + "_add", strict=False),
                children=["+ Add"],
                style={"width": "100px", "margin": "0 auto", "marginTop": "10px"},
            )
        )

        return ddk.ControlCard(controls, style={"marginBottom": "0px"})


class TextField:
    def __init__(self, name, key, required):
        self.name = name
        self.key = key
        self.required = required

    def handle_n_clicks(self, value, element, data_schema):
        pass

    def handle_value(self, value, element, data_schema):
        element[self.key] = value[self.key]

    def validate_and_coerce(self, data_schema, element, context):
        pass

    def controls(self, id, element, query_result):
        controls = []
        value = element.get(self.key)
        controls.append(
            ddk.ControlItem(
                dcc.Input(
                    id=id(self.key, strict=False),
                    value=value,
                ),
                label=_label_wrapper(self.name, self.required),
                label_style=_label_style_wrapper(
                    self.required, value, {"paddingBottom": "0px"}
                ),
            )
        )
        return controls


class NumberField:
    def __init__(self, name, key, required, default, min, max):
        self.name = name
        self.key = key
        self.required = required
        self.default = default
        self.min = min
        self.max = max

    def handle_n_clicks(self, value, element, data_schema):
        pass

    def handle_value(self, value, element, data_schema):
        element[self.key] = (
            value[self.key] if value[self.key] is not None else self.default
        )

    def validate_and_coerce(self, data_schema, element, context):
        pass

    def controls(self, id, element, query_result):
        controls = []
        value = element.get(self.key, self.default)
        controls.append(
            ddk.ControlItem(
                dcc.Input(
                    id=id(self.key, strict=False),
                    value=value,
                    type="number",
                    max=self.max,
                    min=self.min,
                ),
                label=_label_wrapper(self.name, self.required),
                label_style=_label_style_wrapper(
                    self.required, value, {"paddingBottom": "0px"}
                ),
            )
        )
        return controls


class Checkbox:
    def __init__(self, name, key, default=False):
        self.name = name
        self.key = key
        self.required = False
        self.default = default

    def handle_n_clicks(self, value, element, data_schema):
        pass

    def handle_value(self, value, element, data_schema):
        element[self.key] = value.get(self.key, None) == [self.name]

    def validate_and_coerce(self, data_schema, element, context):
        value = element.get(self.key, self.default)
        element[self.key] = bool(value)

    def controls(self, id, element, query_result):
        controls = []
        controls.append(
            ddk.ControlItem(
                dcc.Checklist(
                    id=id(self.key, strict=False),
                    value=[self.name] if element.get(self.key) else [],
                    options=[{"label": self.name, "value": self.name}],
                ),
            )
        )
        return controls


class RadioItems:
    def __init__(self, name, key, options, default):
        self.name = name
        self.key = key
        self.required = False
        self.options = options
        self.default = default

    def handle_n_clicks(self, value, element, data_schema):
        pass

    def handle_value(self, value, element, data_schema):
        element[self.key] = value.get(self.key, None)

    def validate_and_coerce(self, data_schema, element, context):
        element[self.key] = element.get(self.key, self.default)

    def controls(self, id, element, query_result):
        controls = []
        value = element.get(self.key)
        controls.append(
            ddk.ControlItem(
                dcc.RadioItems(
                    id=id(self.key, strict=False),
                    value=value if value is not None else self.default,
                    options=[{"label": x, "value": x} for x in self.options],
                ),
                label=self.name,
                label_style={"paddingBottom": "0px"},
            )
        )
        return controls
