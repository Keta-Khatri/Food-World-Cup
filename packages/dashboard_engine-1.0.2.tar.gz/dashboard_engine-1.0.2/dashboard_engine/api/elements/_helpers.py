from collections.abc import Iterable

import numpy as np

from ..connections._helpers import (  # noqa: F401
    discrete_aggfuncs,
    non_weightable_aggfuncs,
    weightable_aggfuncs,
    aggfuncs,
    BinnedFuncs,
    PeriodTypes,
)
from dashboard_engine.api.data_schema import DateParts

datetime_binning_options = list(
    reversed([name for name, _ in PeriodTypes.__members__.items()])
) + list(DateParts.keys())


aggfunc_labels = dict(
    sum="Sum",
    count="Count",
    min="Minimum",
    max="Maximum",
    mean="Average",
    count_unique="Count Unique",
    std="Standard Deviation",
    none="None",
    top_n="Top-N",
    numerical_bin="Numerical Bin",
    datetime_bin="Date Bin",
    weighted_mean="Weighted Average",
    normalized_sum="Sum Divided by Sum",
)


def make_label(element, dimension):
    # TODO add a unit test someday
    column_def = get_column_def(element, dimension, "n/a")
    if column_def is None:
        return ""
    if dimension + "_label" in element and element[dimension + "_label"]:
        return element[dimension + "_label"]

    func = column_def["function"]
    args = column_def["args"]

    if func == "none":
        return args

    if func == "count":
        return "Count"

    if func == "numerical_bin":
        col, bin = args
        return f"{col}, grouped in bins of size {bin}"

    if func in ["datetime_bin", "date_part_extractor"]:
        col, bin = args
        if bin == "none":
            return col
        return f"{col}, grouped by {bin}"

    if func == "weighted_mean":
        col, wgt = args
        return f"Average of {col}, weighted by {wgt}"

    if func == "normalized_sum":
        col, wgt = args
        return f"Sum of {col} / Sum of {wgt}"

    if func == "top_n":
        n = args.get("n")
        base_column = args.get("base_column")

        if base_column[-1] == "y" and base_column[-2] not in "aeiou":
            base_column_name = base_column[:-1] + "ies"
        elif base_column[-1] == "s":
            base_column_name = base_column + "es"
        else:
            base_column_name = f"{base_column}s"

        return f"Top {n} {base_column_name}"

    if func in aggfunc_labels:
        return "%s of %s" % (aggfunc_labels[func], args)

    raise Exception(f"cannot format function {func}")


def get_column_list_def(element_list, dimension, key_prefix):
    return [
        get_column_def(c, dimension, f"{key_prefix}_{i:03}")
        for i, c in enumerate(element_list)
    ]


def get_column_def(element, dimension, key):
    # TODO add a unit test someday

    column = element.get(dimension)
    if column is None:
        return None

    aggfunc = element.get(f"{dimension}_aggfunc", "none")

    weightable_aggfuncs_map = {"mean": "weighted_mean", "sum": "normalized_sum"}
    weighted_col_name = element.get(f"{dimension}_weighted_by", "none")
    if weighted_col_name != "none":
        return {
            "function": weightable_aggfuncs_map[aggfunc],
            "args": (column, weighted_col_name),
            "key": key,
        }

    if aggfunc == "numerical_bin":
        bin_size = element.get(dimension + "_binsize")
        if not bin_size:
            aggfunc = "none"
        else:
            return {
                "function": "numerical_bin",
                "args": (column, bin_size),
                "key": key,
            }

    if aggfunc == "datetime_bin":
        datetime_bin_size = element.get(dimension + "_datetime_binsize", "none")
        if datetime_bin_size == "none":
            aggfunc = "none"
        else:
            assert datetime_bin_size in datetime_binning_options
            aggfunc = select_datetime_bin_func(datetime_bin_size)
            return {
                "function": aggfunc,
                "args": (column, datetime_bin_size),
                "key": key,
            }

    if aggfunc == "top_n":
        top_n_number = element.get(dimension + "_top_n_number")
        if not top_n_number:
            aggfunc = "none"
        else:
            # Force this to true for now
            include_others = element.get(dimension + "_include_others", True)

            sort_column = element.get(dimension + "_top_n_col")
            sort_aggfunc = element.get(dimension + "_top_n_col_aggfunc")
            sort_weighted_by_column = element.get(dimension + "_top_n_col_weighted_by")
            if (
                sort_weighted_by_column is not None
            ) and sort_aggfunc in weightable_aggfuncs_map:
                sort_aggfunc = weightable_aggfuncs_map[sort_aggfunc]
                sort_column = (sort_column, sort_weighted_by_column)

            return {
                "function": "top_n",
                "args": {
                    "n": top_n_number,
                    "base_column": column,
                    "sort_order": (sort_aggfunc, sort_column),
                    "include_others": include_others,
                },
                "key": key,
            }

    return {"function": aggfunc, "args": column, "key": key}


def flatten(list):
    for el in list:
        if isinstance(el, Iterable) and not isinstance(el, (str, bytes)):
            yield from flatten(el)
        else:
            yield el


def update_axis(fig, element):
    fig.update_layout(
        **{k + "axis_range": v for k, v in element.get("range", {}).items()}
    )


def handle_mapbox_relayout(value, elements, index, data_schema):
    element = elements[index]
    center = value.get("mapbox.center", element.get("_center"))
    element["_center"] = center
    element["_zoom"] = value.get("mapbox.zoom", element.get("_zoom"))
    element["_dragmode"] = value.get("dragmode", element.get("_dragmode"))

    coordinates = value.get("mapbox._derived", {}).get("coordinates", None)

    if not coordinates:
        coordinates = element.get("_coordinates", None)

    if coordinates:

        lon0, lat0 = coordinates[3]
        lon1, lat1 = coordinates[1]

        if center:
            e_center, n_center = lon_lat_to_easting_northing(
                center["lon"], center["lat"]
            )
            (e0, e1), (n0, n1) = lon_lat_to_easting_northing([lon0, lon1], [lat0, lat1])

            e_delta_corrected = min(e_center - e0, e1 - e_center)
            e0 = e_center - e_delta_corrected
            e1 = e_center + e_delta_corrected
            n_delta_corrected = min(n_center - n0, n1 - n_center)
            n0 = n_center - n_delta_corrected
            n1 = n_center + n_delta_corrected

            (lon0, lon1), (lat0, lat1) = easting_northing_to_lon_lat([e0, e1], [n0, n1])

        selections = {}

        for var, (lower, upper) in (("lat", (lat0, lat1)), ("lon", (lon0, lon1))):
            selections[var] = [lower, upper]
        element["range"] = selections
        element["_coordinates"] = coordinates


def handle_cartesian_relayout(value, elements, index, data_schema):
    element = elements[index]
    element["range"] = element.get("range", {})
    for axis in ["x", "y"]:
        start = "{}axis.range[0]".format(axis)
        end = "{}axis.range[1]".format(axis)
        autorange = "{}axis.autorange".format(axis)
        if (
            value
            and start in value
            and end in value
            and data_schema.is_continuous(element[axis])
        ):
            element["range"][axis] = [value[start], value[end]]
        elif autorange in value and value[autorange] is True:
            element["range"].pop(axis, None)

    if "dragmode" in value:
        element["_dragmode"] = value["dragmode"]


def make_2d_range_selection(element):
    return [
        {"type": "range", "target": element[axis], "bounds": bounds}
        for axis, bounds in element.get("range", {}).items()
    ]


def handle_cartesian_selection(value, elements, index, data_schema, axes):
    element = elements[index]
    selections = []

    for axis in axes:
        if value:
            if "points" in value and data_schema.is_discrete(element[axis]):
                added = set()

                unique_sorted_points = [
                    point[axis]
                    for point in value["points"]
                    if not (point[axis] in added or added.add(point[axis]))
                ]
                selections.append(
                    {
                        "type": "points",
                        "target": element[axis],
                        "values": unique_sorted_points,
                    }
                )

            elif "range" in value and data_schema.is_continuous(element[axis]):
                column_def = get_column_def(element, axis, "n/a")
                function = column_def.get("function", "none")
                args = column_def.get("args")

                if function in [b.value for b in BinnedFuncs]:
                    target = dict(function=function, args=args)
                else:
                    target = args

                selections.append(
                    {
                        "type": "range",
                        "target": target,
                        "bounds": value["range"][axis],
                    }
                )
    element["selections"] = selections


def make_selection_shapes(element, mode=None, directions=None):
    if directions is None:
        directions = ["x", "y"]
    axes = {}
    shapes = []
    selections = element.get("selections", [])

    for selection in selections:
        if "_rectangle" in selection:
            x = selection["_rectangle"]["x"]
            y = selection["_rectangle"]["y"]
            shapes.append(
                dict(
                    type="rect",
                    x0=x[0],
                    x1=x[1],
                    y0=y[0],
                    y1=y[1],
                    line=dict(width=1, dash="dot"),
                )
            )
            continue

        if "type" in selection and selection["type"] == "range":
            for axis in directions:
                target = selection["target"]
                if isinstance(target, dict):
                    target, _ = target["args"]
                if element.get(axis, None) == target:
                    if axis not in axes:
                        axes[axis] = selection["bounds"]
                    else:
                        a0, a1 = axes[axis]
                        b0, b1 = selection["bounds"]
                        axes[axis] = [max(a0, b0), min(a1, b1)]

    if "x" in axes:
        x = axes["x"]
        if "y" in axes:
            y = axes["y"]
            yref = "y"
        else:
            y = [0, 1]
            yref = "paper"

        if x[0] < x[1] and y[0] < y[1]:
            shapes.append(
                dict(
                    type="rect",
                    x0=x[0],
                    x1=x[1],
                    yref=yref,
                    y0=y[0],
                    y1=y[1],
                    line=dict(width=1, dash="dot"),
                )
            )

    if mode == "overlay" and "x" in axes and "y" in axes:
        range = {x.get("target"): x.get("bounds") for x in element.get("selections")}

        x = element.get("x")
        y = element.get("y")
        shapes.append(
            dict(
                type="path",
                xref="x",
                xsizemode="scaled",
                yref="y",
                ysizemode="scaled",
                fillcolor="white",
                opacity=0.75,
                line=dict(width=0),
                path="M{} {} V{} H{} V{} H{} M{},{} H{} V{} H{} V{}".format(
                    range[x][0],
                    range[y][0],
                    range[y][1],
                    range[x][1],
                    range[y][0],
                    range[x][0],
                    axes["x"][1],
                    axes["y"][0],
                    axes["x"][0],
                    axes["y"][1],
                    axes["x"][1],
                    axes["y"][0],
                ),
            )
        )

    return shapes


def lon_lat_to_easting_northing(longitude, latitude):
    """
    Projects the given longitude, latitude values into Web Mercator
    (aka Pseudo-Mercator or EPSG:3857) coordinates.

    Longitude and latitude can be provided as scalars, Pandas columns,
    or Numpy arrays, and will be returned in the same form.  Lists
    or tuples will be converted to Numpy arrays.

    Args:
        longitude
        latitude

    Returns:
        (easting, northing)

    Examples:
       easting, northing = lon_lat_to_easting_northing(-74,40.71)

       easting, northing = lon_lat_to_easting_northing(
           np.array([-74]),np.array([40.71])
       )

       df=pandas.DataFrame(dict(longitude=np.array([-74]),latitude=np.array([40.71])))
       df.loc[:, 'longitude'], df.loc[:, 'latitude'] = lon_lat_to_easting_northing(
           df.longitude,df.latitude
       )
    """
    if isinstance(longitude, (list, tuple)):
        longitude = np.array(longitude)
    if isinstance(latitude, (list, tuple)):
        latitude = np.array(latitude)

    origin_shift = np.pi * 6378137
    easting = longitude * origin_shift / 180.0
    with np.errstate(divide="ignore", invalid="ignore"):
        northing = (
            np.log(np.tan((90 + latitude) * np.pi / 360.0)) * origin_shift / np.pi
        )
    return easting, northing


def easting_northing_to_lon_lat(easting, northing):
    """
    Projects the given easting, northing values into
    longitude, latitude coordinates.

    easting and northing values are assumed to be in Web Mercator
    (aka Pseudo-Mercator or EPSG:3857) coordinates.

    Args:
        easting
        northing

    Returns:
        (longitude, latitude)
    """
    if isinstance(easting, (list, tuple)):
        easting = np.array(easting)
    if isinstance(northing, (list, tuple)):
        northing = np.array(northing)

    origin_shift = np.pi * 6378137
    longitude = easting * 180.0 / origin_shift
    with np.errstate(divide="ignore"):
        latitude = (
            np.arctan(np.exp(northing * np.pi / origin_shift)) * 360.0 / np.pi - 90
        )
    return longitude, latitude


def nearest_pow10(x, style="up"):
    if style == "closest":
        lower_exp = np.floor(np.log10(x))
        higher_exp = np.ceil(np.log10(x))
        # has to be done this way (can't just use round(log10(x))) because we want
        # e.g., 40000 to round to 10000 not 100000
        rounded_exp = list(
            sorted([lower_exp, higher_exp], key=lambda e: np.abs(np.power(10, e) - x))
        )[0]
    elif style == "up":
        rounded_exp = np.ceil(np.log10(x))
    else:
        raise ValueError('Bad style argument: "%s"' % (style,))
    return np.power(10.0, rounded_exp)


def select_datetime_bin_func(datetime_bin_size):
    """
    Extracts value at key='{axis_key}_datetime_binsize' from element.
    If the binsize is an absolutely qualified date (e.g., year_month), then
    this will use the "datetime_bin" aggfunc.
    If the binsize is a date part (e.g., "month"), then this will use the
    "date_part_extractor" aggfunc.
    """
    if datetime_bin_size in DateParts.keys():
        return "date_part_extractor"
    elif datetime_bin_size in PeriodTypes.__members__.keys():
        return "datetime_bin"
    else:
        raise ValueError(
            'No aggfunc for datetime_bin_size: "{s}".'.format(s=datetime_bin_size)
        )
