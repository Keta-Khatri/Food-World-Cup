from .dashboard_engine import DashboardEngine  # noqa: F401
from .connections.pandas_connection import (
    PandasConnection,
    PandasConnectionProvider,
    MultiPandasConnectionProvider,
)  # noqa: F401
from .elements import builtin_elements

try:
    import vaex  # noqa: F401

    VAEX_ENABLED = True
except ModuleNotFoundError:
    VAEX_ENABLED = False

from . import demo_data

__all__ = [
    "DashboardEngine",
    "PandasConnection",
    "PandasConnectionProvider",
    "MultiPandasConnectionProvider",
    "builtin_elements",
    "demo_data",
]

if VAEX_ENABLED is True:
    from .connections.vaex_connection import (
        VaexConnection,
        VaexConnectionProvider,
    )  # noqa: F401

    __all__ += [
        "VaexConnection",
        "VaexConnectionProvider",
    ]
