import json
import functools

import pandas as pd

from ..data_schema import DataSchema


class DataFrameConnection:
    def __init__(self, df, data_schema=None, orders=None, color_maps=None):
        """
        Abstract base class for DataFrame-powered Connection classes

        Arguments:
          - df (DataFrame): DataFrame object (e.g. Pandas or Vaex)
          - data_schema: dict[str:Any]
          - orders dict[str:list] | None: map of col-> order of values in column
          - color_maps dict[str:dict[Any:str]] | None: map col->(values->color)
        """
        self._df = df
        self._data_schema = data_schema if data_schema is not None else DataSchema(df)
        self._order_cache = orders if orders else {}
        self._colormap_cache = color_maps if color_maps else {}

    def get_data_schema(self):
        return self._data_schema

    def update_order_for_category(self, column, values):
        # TODO: make sure you don't override user-orders
        self._order_cache[column] = values

    # we might have to move this down to each connection
    def order_for_category(self, column, values=None, dropna=False):
        if column not in self._order_cache:
            if not values:
                # TODO allow full or partial override to be passed in to constructor
                if column is None or column not in self._df:
                    return None

                def cmp_func(x, y):

                    if pd.isna(x) or y == "OTHER":
                        return 1
                    elif pd.isna(y) or x == "OTHER":
                        return -1

                    if x < y:
                        return -1
                    elif x == y:
                        return 0
                    elif x > y:
                        return 1

                categories = [
                    c
                    for c in self._df[column].unique()
                    if c is not None and pd.notna(c)
                ]
                self._order_cache[column] = sorted(
                    categories, key=functools.cmp_to_key(cmp_func)
                )
            else:
                self._order_cache[column] = values

        elif column in self._df:
            categories = [
                c
                for c in self._df[column].unique()
                if c is not None and pd.notna(c) and c not in self._order_cache[column]
            ]
            categories = sorted(categories)
            self._order_cache[column] = self._order_cache[column] + sorted(categories)

        if dropna:
            self._order_cache[column] = [
                order for order in self._order_cache[column] if pd.notna(order)
            ]
        return self._order_cache[column]

    # we might have to move this down to each connection
    # theme can't be None
    def colormap_for_category(self, column, theme, color_type=None):
        if column not in self._colormap_cache:
            # TODO allow full or partial override to be passed in to constructor
            if column is None or column not in self._df:
                return None

            self._colormap_cache[column] = {
                c: theme.get_discrete_color(i, color_type=color_type)
                for i, c in enumerate(self.order_for_category(column))
            }
        else:
            # assume that theme is always present
            # recalcualte colors if theme!=None
            for i, c in enumerate(self.order_for_category(column)):
                # column key exists so value must be a dict
                if (
                    c not in self._colormap_cache[column]
                    or self._colormap_cache[column][c].split("(")[0] == "var"
                ):
                    self._colormap_cache[column][c] = theme.get_discrete_color(
                        i, color_type=color_type
                    )
        return self._colormap_cache[column]


class DataFrameConnectionProvider:
    """
    Abstract base class for a Connection Provider that always returns the same
    DataFrameConnection based on the same single in-memory DataFrame.
    """

    def __init__(self, df, orders=None, color_maps=None):
        """
        Initialize a DataFrameConnectionProvider with a DataFrame

        Arguments:
            - df (DataFrame): a single DataFrame
            - orders (dict): a category orders dictionary
            - color_maps (dict): a color map dictionary
        """
        self._connection = self._cls(df, orders=orders, color_maps=color_maps)

    def get_connection(self, connection_params, user_data={}):
        """
        Returns DataFrameConnection wrapping the stored dataframe.

        `connection_params` is ignored.

        `user_data` is ignored.

        Returns:
        A `DataFrameConnection`.
        """
        return self._connection


class MultiDataFrameConnectionProvider:
    """
    Abstract base class for a Connection Provider that always returns a new
    DataFrameConnection based one of a set of in-memory DataFrames.
    """

    def __init__(self, dfs, orders=None, color_maps=None):
        """
        Initialize a Connection Provider which will return DataFrameConnections
        wrapping one of a collection of in-memory DataFrames.

        Arguments:
            - dfs (dict of str: DataFrame): a mapping of keys to DataFrames
            - orders (dict of str: dict): a mapping of keys to category orders
            - color_maps (dict of str: dict): a mapping of keys to color maps
        """

        orders = orders or dict()
        color_maps = color_maps or dict()
        self._connections = {
            k: self._cls(dfs[k], orders=orders.get(k), color_maps=color_maps.get(k))
            for k in dfs
        }

    def get_connection(self, connection_params, user_data={}):
        # TODO: elaborate/fill in docstring
        """
        Returns a DataFrameConnection wrapping a stored dataframe.

        `connection_params` must be a valid key from the `dfs` dictionary
        provided in the constructor.

        `user_data` is ignored.

        Returns:
        A `DataFrameConnection`.
        """
        return self._connections[connection_params]


class CachingConnectionProvider:
    """Abstract base class providing connection caching"""

    def __init__(self):
        self._connection_cache = dict()

    def get_connection(self, connection_params, user_data={}):
        # TODO: elaborate/fill in docstring
        """
        Retreives a cached connection.

        Returns:
        A cached connection.
        """
        connection_params_json = json.dumps(connection_params)
        if connection_params_json not in self._connection_cache:
            connection = self._get_uncached_connection(connection_params, user_data)
            self._connection_cache[connection_params_json] = connection
        return self._connection_cache[connection_params_json]
