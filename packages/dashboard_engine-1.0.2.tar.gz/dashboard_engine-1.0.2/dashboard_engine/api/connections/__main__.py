import pickle
import sys
import argparse
from .vaex_connection import VaexFileConnectionProvider
from .pandas_connection import PandasFileConnectionProvider

providers = {
    "vaex": VaexFileConnectionProvider,
    "pandas": PandasFileConnectionProvider,
}

usage = """

Run a previously saved query for performing profiling/debugging

e.g.
$ DBE_QUERY_PICKLE="query-cell-towers.pickle" DBE_TIMER=1 PORT=5058\
    HOST=0.0.0.0 python app.py
....
wrote to /some/path/query-cell-towers.pickle
....

(Ctrl-c)
$ python -m dashboard_engine.api.connection cell_towers.parquet.hdf5\
    /some/path/query-cell-towers.pickle
$ viztracer --ignore_frozen -o viztracer-query-cell-towers.html -m \
    dashboard_engine.api.connection cell_towers.parquet.hdf5\
    /some/path/query-cell-towers.pickle
$ python -m pdb -m dashboard_engine.api.connection cell_towers.parquet.hdf5 \
    /some/path/query-cell-towers.pickle
"""


def main(args=sys.argv):
    parser = argparse.ArgumentParser(
        args[0], formatter_class=argparse.RawDescriptionHelpFormatter, usage=usage
    )
    parser.add_argument("--provider", default="vaex", choices=providers.keys())
    parser.add_argument("param")
    parser.add_argument("queryfile")
    args = parser.parse_args(args[1:])
    conn_provider = providers[args.provider]()
    connection = conn_provider.get_connection(args.param)

    with open(args.queryfile, "rb") as f:
        selections = pickle.load(f)

    # when debugging, we often need to add some custom code, e.g.
    # if "cell_towers" in args.param:
    #     df = connection._df
    #     df["created_date"] = df.created.astype("datetime64[ns]")
    #     df["range_log10"] = df.range.log10()
    # or trigger a non-cachable query (by changing the where condition)
    # import random
    # msec = random.randint(0, 999)
    # selections[-5].where[0].bounds[0] = f'1929-04-05 09:17:34.{msec}'

    print("run query", selections)
    connection._execute_queries(selections)


if __name__ == "__main__":
    main()
