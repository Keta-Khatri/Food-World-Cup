from enum import Enum
import pandas as pd
from dashboard_engine.api.data_schema import DateParts

try:
    import vaex

    VAEX_ENABLED = True
except ModuleNotFoundError:
    VAEX_ENABLED = False

import numpy as np
from typing import Iterable


discrete_aggfuncs = ["count", "count_unique"]
non_weightable_numeric_aggfuncs = ["min", "max", "std"]
non_weightable_aggfuncs = discrete_aggfuncs + non_weightable_numeric_aggfuncs
weightable_aggfuncs = ["mean", "sum"]
numeric_aggfuncs = weightable_aggfuncs + non_weightable_numeric_aggfuncs
aggfuncs = discrete_aggfuncs + numeric_aggfuncs
weighted_aggfuncs = ["weighted_mean", "normalized_sum"]


class BinnedFuncs(Enum):
    NUMERICAL_BIN = "numerical_bin"
    DATETIME_BIN = "datetime_bin"


class PeriodTypes(Enum):
    year = "datetime64[Y]"
    month = "datetime64[M]"
    day = "datetime64[D]"
    hour = "datetime64[h]"
    minute = "datetime64[m]"
    second = "datetime64[s]"


def numerical_bin(element_df, args):
    column, bin_size = args
    return bin_size / 2 + bin_size * (element_df[column] // bin_size)


# these are required because Pandas day_name and month_name are methods, whereas
# vaex always returns a vaex expression (pandas otherwise returns dataframes).
def get_day_name(df, column):
    if isinstance(df, pd.core.frame.DataFrame):
        return lambda: df[column].dt.day_name()
    else:
        return lambda: df[column].dt.day_name


def get_month_name(df, column):
    if isinstance(df, pd.core.frame.DataFrame):
        return lambda: df[column].dt.month_name()
    else:
        return lambda: df[column].dt.month_name


def date_part_extractor(df, args):
    column, date_part = args
    if date_part in DateParts.keys():
        date_part = DateParts[date_part]
    fmt_dict = {
        "dayofweek": lambda: df[column].dt.dayofweek,
        "day_name": get_day_name(df, column),
        "day": lambda: df[column].dt.day,  # day of month
        "dayofmonth": lambda: df[column].dt.day,
        "month": lambda: df[column].dt.month,
        "month_name": get_month_name(df, column),
        "year": lambda: df[column].dt.year,
        "hour": lambda: df[column].dt.hour,
        "minute": lambda: df[column].dt.minute,
        "second": lambda: df[column].dt.second,
    }
    try:
        fmt = fmt_dict[date_part]
    except KeyError:
        raise ValueError(
            "Bad date_part %s, accepted are " % date_part,
            ", ".join(['"%s"' % (k,) for k, v in fmt_dict.items()]),
        )
    # convert x, assumed to be an array of np.datetime64, to a day of the week
    # representation
    return fmt()


def datetime_bin(df, args):
    column, bin_type = args
    period_type = PeriodTypes[bin_type]
    # see above for series.astype vs series.values.astype
    if VAEX_ENABLED is True and isinstance(df, vaex.dataframe.DataFrame):
        return df[column].astype(period_type.value)
    else:
        return df[column].values.astype(period_type.value)


LARGE_NO = 999999999


def calculate_rank_vaex(df, args: dict):
    n = args["n"]
    base_column = args["base_column"]
    (sort_aggfunc, sort_aggfunc_args) = args["sort_order"]

    df_grouped = df.groupby(base_column)
    if sort_aggfunc in ["normalized_sum", "weighted_mean"]:
        column, denom_col = sort_aggfunc_args
        sort_order = weighted_func_sort_order_col(sort_aggfunc, column, denom_col)
        tmp_numer_col = weighted_func_numer_col(column, sort_aggfunc)
        tmp_denom_col = weighted_func_denom_col(column, sort_aggfunc)
        agg = {tmp_denom_col: vaex.agg.sum(df[denom_col])}
        if sort_aggfunc == "normalized_sum":
            agg[tmp_numer_col] = vaex.agg.sum(df[column])
        elif sort_aggfunc == "weighted_mean":
            agg[tmp_numer_col] = vaex.agg.sum(df[column] * df[denom_col])
        temp_df = df.groupby(base_column, agg=agg)
        temp_df[sort_order] = temp_df[tmp_numer_col] / temp_df[tmp_denom_col]
        temp_df.drop([tmp_numer_col, tmp_denom_col])
        ranked_col = get_top_n_ranked_column_name(args)
    else:
        column = sort_aggfunc_args
        sort_order = sort_order_col(sort_aggfunc, column)
        agg_cols = {}
        agg_cols[sort_order] = getattr(vaex.agg, sort_aggfunc)(df[column])
        temp_df = df_grouped.agg(agg_cols)
        ranked_col = get_top_n_ranked_column_name(args)

    temp_df[ranked_col] = np.argsort(-1 * temp_df[sort_order].to_numpy()).argsort()

    temp_df[ranked_col] = (temp_df[ranked_col] < n).where(temp_df[ranked_col], LARGE_NO)

    temp_df = df.join(temp_df, how="left", on=base_column)

    temp_df = temp_df.drop(sort_order)

    return temp_df


PANDAS_AGGFUNC_MAP = {"count": "size", "count_unique": "nunique"}


def calculate_rank_pandas(df, args: dict):
    n = args["n"]
    base_column = args["base_column"]
    (sort_aggfunc, sort_aggfunc_args) = args["sort_order"]

    df_grouped = df.groupby(base_column)
    if sort_aggfunc in ["normalized_sum", "weighted_mean"]:
        column, denom_col = sort_aggfunc_args
        sort_order = weighted_func_sort_order_col(sort_aggfunc, column, denom_col)
        if sort_aggfunc == "normalized_sum":
            temp_series = df_grouped.apply(
                lambda df: df[column].sum() / df[denom_col].sum()
            )
        elif sort_aggfunc == "weighted_mean":
            temp_series = df_grouped.apply(
                lambda df: (df[column] * df[denom_col]).sum() / df[denom_col].sum()
            )
        temp_df = pd.DataFrame({sort_order: temp_series})
    else:
        aggfunc = sort_aggfunc
        if sort_aggfunc in PANDAS_AGGFUNC_MAP:
            aggfunc = PANDAS_AGGFUNC_MAP[sort_aggfunc]
        column = sort_aggfunc_args
        sort_order = sort_order_col(sort_aggfunc, column)
        agg_cols = {sort_order: (column, aggfunc)}
        temp_df = df_grouped.agg(**agg_cols).reset_index()

    # TODO: Why is this not computed via rank_column_name?
    ranked_col = get_top_n_ranked_column_name(args)

    temp_df[ranked_col] = temp_df[sort_order].rank(method="first", ascending=False)
    temp_df[ranked_col] = temp_df[ranked_col].mask(
        temp_df[ranked_col] > n, lambda x: float("inf")
    )

    # TODO: this is costly
    temp_df = (
        df.reset_index().merge(temp_df, how="left", on=base_column).set_index("index")
    )
    return temp_df[ranked_col]


def calculate_rank(df, args: dict):
    if isinstance(df, vaex.dataframe.DataFrame):
        return calculate_rank_vaex(df, args)
    elif isinstance(df, pd.DataFrame):
        return calculate_rank_pandas(df, args)


groupfuncs = dict(
    numerical_bin=numerical_bin,
    datetime_bin=datetime_bin,
    top_n=calculate_rank,
    date_part_extractor=date_part_extractor,
)


def _flatten(args):
    for el in args:
        if isinstance(el, Iterable) and not isinstance(el, (str, bytes)):
            yield from _flatten(el)
        else:
            yield el


def virtual_column_name(func: str, args: Iterable):
    if func == "none":
        return args  # special case: non-virtual column

    result = func
    result += "_" + "_".join(str(x) for x in _flatten(args))
    return result


def get_top_n_ranked_column_name(args: dict):
    vcol = virtual_column_name(
        "top_n",
        [args["n"], args["base_column"], args["sort_order"], args["include_others"]],
    )
    return f"rank_{vcol}"


def scaled_col(x):
    return f"{x}_scaled_col"


def sum_scaled_col(x):
    return f"{x}_scaled_col_sum"


def sum_weighted_col(x):
    return f"{x}_weighted_col_sum"


def sort_order_col(sort_aggfunc, column):
    return f"{sort_aggfunc}_{column}"


def weighted_func_sort_order_col(sort_aggfunc, column, denom_col):
    return f"{sort_aggfunc}_{column}_weighted_by_{denom_col}"


def weighted_func_numer_col(column, sort_aggfunc):
    return f"{column}_as_{sort_aggfunc}_numerator"


def weighted_func_denom_col(column, sort_aggfunc):
    return f"{column}_as_{sort_aggfunc}_denominator"


def is_weighted(aggfunc: str):
    return aggfunc in weighted_aggfuncs


def dataframe_slice(df, offset, limit):
    if limit != -1 or offset != 0:
        if limit == -1:
            to = None
        else:
            to = offset + limit
        df = df[offset:to]
    return df
