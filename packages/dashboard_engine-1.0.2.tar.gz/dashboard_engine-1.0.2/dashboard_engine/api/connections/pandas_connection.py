from functools import reduce
from operator import and_
import re

import datashader as ds
import numpy as np
import pandas as pd

from .connection import (
    DataFrameConnection,
    DataFrameConnectionProvider,
    MultiDataFrameConnectionProvider,
    CachingConnectionProvider,
)

from ..query import QueryResult
from ..timer import Timer

from ._helpers import (
    dataframe_slice,
    groupfuncs,
    virtual_column_name,
    get_top_n_ranked_column_name,
    scaled_col,
    sum_weighted_col,
    sum_scaled_col,
    is_weighted,
)


def unique_or_other_factory(rank_series):
    def unique_or_other(x):
        ind = x.index[0]
        rank = rank_series.loc[ind]
        if rank == float("inf"):
            return "OTHER"
        else:
            return x.values[0]

    return unique_or_other


# TODO: fk: aggregate is doing too many things
def aggregate(df, select, group_by, rasterization=None):
    key_to_label = {}
    weighted_key_to_label = {}
    grouped_cols = []
    aggregated_cols = {}
    weighted_keys = []
    cols_to_drop = set()
    rank_cols = []
    xarray = None
    order_cache = {}

    # processing for top_n, numerical and date binning should go here
    for groupfunc, args, key in group_by:
        vcolumn = virtual_column_name(groupfunc, args)
        key_to_label[key] = vcolumn

        if groupfunc == "top_n":
            n = args["n"]
            base_column = args["base_column"]
            sort_order = args["sort_order"]
            include_others = args["include_others"]
            vcolumn = virtual_column_name(
                "top_n", [n, base_column, sort_order, include_others]
            )

            key_to_label[key] = vcolumn

            ranked_col_name = get_top_n_ranked_column_name(args)

            unique_or_other = unique_or_other_factory(df[ranked_col_name])
            aggregated_cols[vcolumn] = (base_column, unique_or_other)

            if ranked_col_name not in grouped_cols:
                grouped_cols.append(ranked_col_name)
                rank_cols.append((vcolumn, ranked_col_name))

            cols_to_drop.add(ranked_col_name)
            continue

        if vcolumn not in grouped_cols:
            grouped_cols.append(vcolumn)

    # new aggregators like count-unique, weighted-mean etc should go here
    for aggfunc, args, key in select:

        label = "%s_%s" % (
            aggfunc,
            args if isinstance(args, str) else "_".join(args),
        )

        key_to_label[key] = label
        if label not in aggregated_cols:
            if aggfunc == "count":
                aggfunc = "size"  # count should count even non-null!

            elif aggfunc == "count_unique":

                def nunique_with_drop(x):
                    return x.nunique(dropna=False)

                aggfunc = nunique_with_drop

            elif is_weighted(aggfunc):
                base_column, weighted_by = args

                if aggfunc == "weighted_mean":
                    numerator = scaled_col(key)
                elif aggfunc == "normalized_sum":
                    numerator = base_column

                label = "%s_%s" % ("sum", numerator)
                weighted_key_to_label[sum_scaled_col(key)] = label
                aggregated_cols[label] = (numerator, "sum")

                label = "%s_%s" % ("sum", weighted_by)
                weighted_key_to_label[sum_weighted_col(key)] = label
                aggregated_cols[label] = (
                    weighted_by,
                    "sum",
                )
                weighted_keys.append(key)
                continue

            aggregated_cols[label] = (args, aggfunc)

    if df.size == 0:
        for label in aggregated_cols:
            df[label] = ""
        return df, key_to_label

    if len(aggregated_cols) == 0:
        if len(grouped_cols) == 0:
            raise ValueError("nothing to aggregate!")

        # TODO: we should probably reset the index here
        result = df[grouped_cols].drop_duplicates()
        if rasterization:
            # TODO: fk, should we check for continuous here
            cvs = ds.Canvas(
                plot_width=rasterization.plot_width,
                plot_height=rasterization.plot_height,
                x_range=rasterization.x_limits,
                y_range=rasterization.y_limits,
            )

            if rasterization.color:
                result[rasterization.color] = result[rasterization.color].astype(
                    "category"
                )

                xarray = cvs.points(
                    result,
                    rasterization.x_column,
                    rasterization.y_column,
                    agg=ds.count_cat(rasterization.color),
                )

            else:
                xarray = cvs.points(
                    result, rasterization.x_column, rasterization.y_column
                )
    else:
        if grouped_cols:
            groupings = df.groupby(grouped_cols, dropna=False)
            result = groupings.agg(**aggregated_cols).reset_index()

            for vcolumn, rank_col in rank_cols:
                result = result.sort_values(by=rank_col).reset_index(drop=True)

                # if it is requested, then it will eventually be calculated
                order_cache[vcolumn] = list(result[vcolumn].unique())
        else:
            try:
                result = (
                    df.agg(**aggregated_cols)  # output != groupby().agg()
                    .melt(ignore_index=False)  # one row per agg per column
                    .drop(["variable"], axis=1)  # drop the dummy column
                    .dropna()
                    .T
                )
            except ValueError:
                for value in aggregated_cols.values():
                    col, _ = value

                    if df[col][df[col].notna()].shape[0] == 0:
                        df[col] = df[col].fillna("inf")

                result = (
                    df.agg(**aggregated_cols)  # output != groupby().agg()
                    .replace(np.inf, np.nan)
                    .melt(ignore_index=False)  # one row per agg per column
                    .drop(["variable"], axis=1)  # drop the dummy column
                )

                if any(result.index.duplicated()):
                    # drop only if there are duplicated cols
                    # make sure the nans are at the end
                    result = result.sort_values(by=["value"])[
                        ~result.index.duplicated()
                    ].T
                else:
                    result = result.T

        for key in weighted_keys:
            result[key_to_label[key]] = (
                result[weighted_key_to_label[sum_scaled_col(key)]]
                / result[weighted_key_to_label[sum_weighted_col(key)]]
            )

        # drop all columns that we added just for weighted functions
        # without dropping columns that are also used for unweighted functions
        # in the same query
        result.drop(
            set(weighted_key_to_label.values()) - set(key_to_label.values()),
            inplace=True,
            axis=1,
        )

        if cols_to_drop:
            result.drop(cols_to_drop, inplace=True, axis=1)

    return result, key_to_label, xarray, order_cache


def compute_top_n_mask(df, group_by):
    mask = np.full(len(df), True)

    for group_func, args, key in group_by:
        if group_func == "top_n":
            ranked_col_name = get_top_n_ranked_column_name(args)

            if not args.get("include_others"):
                mask &= df[ranked_col_name] != float("inf")

    return mask


def compute_mask(df, where):
    # Compute masks using where statements
    mask = np.full(len(df), True)
    mask_all = np.full(len(df), False)

    for selection in where:
        if selection:
            col = selection["target"]
            # no need to check for str because it works by default
            # TODO: fk this should be moved to Query
            # compute mask should not worry about the type of col
            if isinstance(col, dict):
                col = virtual_column_name(col["function"], col["args"])

            # TODO: fk: make separate functions out of this similar to vaex
            if selection["type"] == "range":
                range = selection["bounds"]
                if None not in range:
                    range.sort()
                if range[0] is not None:
                    mask &= df[col] >= range[0]
                if range[1] is not None:
                    mask &= df[col] <= range[1]

            # TODO: fk: make separate functions out of this similar to vaex
            if selection["type"] == "points":
                if len(selection["values"]) == 0:
                    continue

                local_mask = np.copy(mask_all)
                for value in selection["values"]:
                    local_mask |= df[col] == value

                mask &= local_mask

    return mask


# TODO: fk: find a right place for this, maybe connection helpers
# TODO: fk: this is doing multiple things break it down
def _populate_virtual_cols(df, queries) -> None:
    for query in queries:
        if not query:
            continue

        # pre-aggregate preparation: select
        for aggfunc, args, key in query.select:
            if is_weighted(aggfunc):
                base_column, weighted_by = args
                if aggfunc == "weighted_mean" and scaled_col(key) not in df.columns:
                    df[scaled_col(key)] = df[base_column] * df[weighted_by]

        # pre-aggregage preparation: grouping
        for group_func, args, key in query.group_by:
            if group_func not in ("none", "top_n"):
                vcol = virtual_column_name(group_func, args)
                if vcol not in df.columns:
                    df[vcol] = groupfuncs[group_func](df, args)

        # pre-aggregage preparation: where
        for where_type, target, _ in query.crossfilter_values():
            # TODO: fetch the tuple of where_types from somewhere
            # they should be globally known
            if where_type in ("points", "range"):
                # TODO: fk: this is an anti-pattern
                # TOOD: fk: find a better way to handle this
                if isinstance(target, dict):
                    group_func = target["function"]
                    args = target["args"]
                    vcol = virtual_column_name(group_func, args)
                    if vcol not in df:
                        df[vcol] = groupfuncs[group_func](df, args)


class PandasConnection(DataFrameConnection):
    """
    A Connection wrapping a single Pandas DataFrames.

    Arguments:
      - `df` (DataFrame): Pandas DataFrame
      - `data_schema` (dict with string keys and dict values): each entry in this
        dictionary is used to preload or override the auto-generated schema
        information for this dataset
      - `orders` (dict with string keys and list values): each entry in this
        dictionary is used to override the built-in alphabetical ordering for
        categorical variables. Keys must be columns in df, values must be
        ordered lists of values in those columns.
      - `color_maps` (dict with string keys and dict values): each entry in this
        dictionary is used to override the built-in color-sequence cycling for
        categorical variables. Keys must be columns in df, values must be dicts
        mapping values in those columns to CSS colors.
    """

    def _execute_queries(self, queries):
        """
        Perform a data query described by a list of Query

        This method is responsible for querying data
        based on the provided list of Query object.
        For each Query provided in the list,
        a QueryResult is returned which contains data filtered based
        on every other Query except its own.

        Arguments:
          - queries (list of Query):

        Returns:
          - list of QueryResult
        """

        df = self._df.copy(deep=False)
        data_schema = self.get_data_schema()

        _populate_virtual_cols(df, queries)

        masks = [
            compute_mask(df, query.crossfilters) if query is not None else None
            for query in queries
        ]

        local_masks = [
            compute_mask(df, query.filters) if query is not None else None
            for query in queries
        ]

        # TODO: fk: these are results, not dfs
        dfs = []
        mask_nothing = np.full(len(df), True)
        empty_result = QueryResult(
            None,
            {},
            self.order_for_category,
            self.colormap_for_category,
            data_schema,
        )

        exclude_filtering_groups: list[list] = [
            s.exclude_filtering_group if s is not None else [] for s in queries
        ]

        for i, query in enumerate(queries):
            with Timer("connection", "pandas", i):
                if query is None or (
                    len(query.select) == 0 and len(query.group_by) == 0
                ):
                    dfs.append(empty_result)
                    continue

                # crossfilters
                # TODO: fk: move this to a separate function
                mask = reduce(
                    and_,
                    [
                        m
                        for (nth, m), filter_group in zip(
                            enumerate(masks), exclude_filtering_groups
                        )
                        if nth != i and m is not None
                        if query.id not in filter_group
                    ],
                    mask_nothing,
                )

                working_df = df.copy(deep=False)
                extra_group_by = []

                if query.crossfilter_mask_key:
                    working_df["dbe_mask__"] = masks[i]

                    extra_group_by.append(
                        {
                            "function": "none",
                            "args": "dbe_mask__",
                            "key": query.crossfilter_mask_key,
                        }
                    )

                element_df = working_df[mask & local_masks[i]].reset_index(drop=True)

                # check results after mask is applied
                if len(element_df) == 0:
                    dfs.append(empty_result)
                    continue

                # pre-aggregate populate virtual column
                for group_func, args, key in query.group_by:
                    if group_func == "top_n":

                        vcol = get_top_n_ranked_column_name(args)

                        if vcol not in element_df.columns:
                            element_df[vcol] = groupfuncs[group_func](element_df, args)

                # top_n filters
                top_n_mask = compute_top_n_mask(element_df, query.group_by)
                element_df = element_df[top_n_mask]

                if query.rasterization:
                    # validate the preconditions for rasterization
                    if data_schema.is_discrete(
                        query.rasterization.x_column
                    ) or data_schema.is_discrete(query.rasterization.y_column):
                        raise ValueError(
                            "Both x-column and y-column have to be continuous"
                        )

                element_df, key_to_label, xarray, order_cache = aggregate(
                    element_df,
                    query.select,
                    query.group_by + [extra_gb.values() for extra_gb in extra_group_by],
                    rasterization=query.rasterization,
                )

                # update existing order cache
                for col, order in order_cache.items():
                    self.update_order_for_category(col, values=order)

                # Order_by
                if len(query.order_by):
                    # TODO: support multi columns sorting instead of only one
                    element_df = element_df.sort_values(
                        key_to_label[query.order_by[0][0]],
                        ascending=query.order_by[0][1] == "asc",
                        inplace=False,
                    )

                element_df = dataframe_slice(element_df, query.offset, query.limit)

                dfs.append(
                    QueryResult(
                        element_df,
                        key_to_label,
                        self.order_for_category,
                        self.colormap_for_category,
                        data_schema,
                        rasterized_array=xarray,
                        query=query,
                    )
                )

        return dfs


class PandasConnectionProvider(DataFrameConnectionProvider):
    """
    A Connection Provider that always returns the same PandasConnection based on
    a single in-memory Pandas DataFrame.


    Arguments:
      - `df` (Pandas DataFrame): the data frame this connection provider makes
        accessible
      - `orders` (dict with string keys and list values): passed to the
        PandasConnection.
      - `color_maps` (dict with string keys and dict values): passed to the
        PandasConnection.
    """

    _cls = PandasConnection


class MultiPandasConnectionProvider(MultiDataFrameConnectionProvider):
    """
    A Connection Provider that returns a PandasConnection based on one of a set
    of in-memory Pandas DataFrames.

    Arguments:
      - `dfs` (dict with string keys and Pandas DataFrame values): the data frames
        this connection provider makes accessible
      - `orders` (dict): dictionary of values passed to the PandasConnection, with
        keys matching those of the `dfs` argument.
      - `color_maps` (dict ): dictionary of values passed to the PandasConnection,
        with keys matching those of the `dfs` argument.
    """

    _cls = PandasConnection


class PandasFileConnectionProvider(CachingConnectionProvider):
    """
    Connection provider to data stored in a file

    If `connection_params` is a string, it is interpreted as a filepath.
    If it is a dict, its `url` value is interpreted as a filepath.
    Optionally, the key `parse_dates` can contain a list of column names
    which should be parsed as date.

    The file must have one of the following supported extension:
      - csv(.gz)
      - parquet(.gz)
    """

    def __init__(self, default_connection_params=None, orders=None, color_maps=None):
        super().__init__()
        self.default_connection_params = default_connection_params
        self._orders = orders
        self._color_maps = color_maps

    def _get_uncached_connection(self, connection_params, user_data):
        if not connection_params and self.default_connection_params:
            connection_params = self.default_connection_params

        if isinstance(connection_params, str):
            connection_params = dict(url=connection_params)

        url = connection_params["url"]
        if re.search("csv(.gz)?$", url):
            df = pd.read_csv(url, low_memory=False)
        elif re.search("parquet(.gz)?$", url):
            df = pd.read_parquet(url)
        else:
            raise "Unsupported file extension"

        for col in connection_params.get("parse_dates", []):
            df[col] = pd.to_datetime(df[col], infer_datetime_format=True)
        for col, dtype in connection_params.get("dtype", {}).items():
            df[col] = df[col].astype(dtype)

        return PandasConnection(df, orders=self._orders, color_maps=self._color_maps)
