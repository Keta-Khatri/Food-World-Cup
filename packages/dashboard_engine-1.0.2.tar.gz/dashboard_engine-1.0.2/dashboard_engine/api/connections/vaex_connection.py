from functools import reduce
from operator import and_, or_
import os
import pickle

import numpy as np
import pandas as pd
import pyarrow as pa
import vaex
from vaex.delayed import delayed, delayed_list
import re

# TODO: make sure that connection only contains generic methods, not specific providers
from .connection import (
    DataFrameConnection,
    DataFrameConnectionProvider,
    MultiDataFrameConnectionProvider,
    CachingConnectionProvider,
)

from ..query import QueryResult
from ..timer import TimerVaex
from ._helpers import (
    dataframe_slice,
    groupfuncs,
    virtual_column_name,
    sum_scaled_col,
    sum_weighted_col,
    is_weighted,
)

import logging

logger = logging.getLogger("dbe.vaex")

WHERE_COLUMN_NAME = "_db_where_condition"
FILTER_COLUMN_NAME = "_dbe_filter_condition"

# can be useful to set to 0 to have easier stack traces
VAEX_DELAYED = bool(os.environ.get("DBE_VAEX_DELAYED", "1"))


def and_expressions(df, expressions):
    expressions = [k for k in expressions if k is not None]
    if len(expressions) == 0:
        return None
    else:
        return reduce(and_, expressions)


def selection_expression_range(df, column_name, range):
    if None not in range:
        range.sort()
    if range[1] is None:
        return df[column_name] >= range[0]
    elif range[0] is None:
        return df[column_name] <= range[1]
    else:
        return (df[column_name] >= range[0]) & (df[column_name] <= range[1])


def selection_expression_points(df, column_name, values):
    if len(values) == 0:
        return None
    return reduce(or_, (df[column_name] == value for value in values))


def selection_expression(df, selection):
    # Compute a vaex expression from where selection statements (single one)
    # TODO: fk: all of the keys for where should be a variable stored somewhere
    col = selection["target"]

    # no need to check for the str
    # TODO: this is an anti-pattern
    if isinstance(col, dict):
        col = virtual_column_name(col["function"], col["args"])

    if selection["type"] == "range":
        return selection_expression_range(df, col, selection["bounds"])

    if selection["type"] == "points":
        return selection_expression_points(df, col, selection["values"])


def where_expression(df, where):
    # Compute a vaex expression from where statements
    return and_expressions(
        df,
        [selection_expression(df, selection) for selection in where if selection],
    )


# TODO: this is something vaex should handle
def to_pandas_df_wrapper(df, original_vaex_df):
    columns = df.columns

    for column in columns:
        df[column] = df[column].apply(
            lambda x: x.as_py() if isinstance(x, pa.lib.Scalar) else x
        )

        # vaex categories are different than pandas categories
        if original_vaex_df.is_category(column):
            df[column] = df[column].astype("category")

    return df


def aggregator(df, aggfunc, args, filter):
    # TODO: fk: move all of these names to an enum
    if aggfunc == "count":
        # count should count even non-null!
        return vaex.agg.count(selection=filter)
    elif aggfunc == "count_unique":
        return vaex.agg.nunique(args, selection=filter)
    elif is_weighted(aggfunc):
        base_column, weighted_by = args

        if aggfunc == "weighted_mean":
            numerator = df[base_column] * df[weighted_by]
        elif aggfunc == "normalized_sum":
            numerator = base_column

        # TODO are we computing sum(y) twice here if e.g. y=sum(x)/sum(y)
        # make sure vaex de-duplicates that
        agg1 = vaex.agg.sum(numerator, selection=filter)
        agg2 = vaex.agg.sum(weighted_by, selection=filter)
        agg = agg1 / agg2
        return agg
    else:
        return getattr(vaex.agg, aggfunc)(df[args], selection=filter)


# TODO: fk: break this function down into different chunks
def aggregate(df, select, group_by, rasterization, filter, where_key, where_filter):
    # For better cache hits, we pass filter down to the aggregators
    # If we apply the filter to the dataframe, we change its fingerprints):
    # assert len(df) > 0, "aggregate should not handle empty dataframes"
    # based on connection.py::aggregate
    key_to_label = {}
    grouping_cols = []
    groupers = []
    aggregated_cols = {}
    weighted_keys = []
    cols_to_drop = []

    top_n_exists = False
    top_n_groupings = []
    rank_cols = []
    result = None
    order_cache = {}

    # processing for topN, numerical and date binning should go here
    for groupfunc, args, key in group_by:
        if groupfunc == "top_n":
            vcolumn = virtual_column_name(
                "top_n",
                [
                    args["n"],
                    args["base_column"],
                    args["sort_order"],
                    args["include_others"],
                ],
            )
        else:
            vcolumn = virtual_column_name(groupfunc, args)
        key_to_label[key] = vcolumn

        if groupfunc == "top_n":
            grouping_cols.append(vcolumn)
            base_column = args["base_column"]
            values = args["values"]
            order_cache[vcolumn] = values.unique().to_pylist()
            # fk: this is only here because OTHER is true by default
            if len(order_cache[vcolumn]) < args["n"]:
                order_cache[vcolumn].append("OTHER")
            grouper = vaex.groupby.GrouperLimited(
                df[base_column],
                values,
                keep_other=True,
                other_value="OTHER",
                label=vcolumn,
            )
            groupers.append(grouper)
        elif vcolumn not in grouping_cols:
            grouping_cols.append(vcolumn)
            # this assumes that the where clause is always at the end
            top_n_groupings.append(vcolumn)
            groupers.append(vcolumn)

    if set(top_n_groupings) - set(grouping_cols):
        top_n_exists = True

    for aggfunc, args, key in select:
        label = "%s_%s" % (
            aggfunc,
            args if isinstance(args, str) else "_".join(args),  # type: ignore
        )

        key_to_label[key] = label
        if label not in aggregated_cols:
            aggregated_cols[label] = aggregator(df, aggfunc, args, filter)

    result = df
    if where_key is not None and where_filter is not None:
        where_groupby = vaex.groupby.BinnerInteger(where_filter, label=where_key)
        groupers.append(where_groupby)
        grouping_cols.append(where_key)
        key_to_label[where_key] = where_key

    if len(aggregated_cols) == 0:
        if len(grouping_cols) == 0:
            raise ValueError("nothing to aggregate!")

        if rasterization:
            rasterization_groups = [
                rasterization.y_column,
                rasterization.x_column,
            ]
            min_maxes = [result[x].minmax() for x in rasterization_groups]

            eps = 1e-15
            min_maxes = [[x for x in y] for y in min_maxes]
            limits = [[x[0], x[1] + ((x[1] - x[0]) * eps)] for x in min_maxes]

            limits = [rasterization.y_limits, rasterization.x_limits]
            eps = 1e-15
            for i in range(len(limits)):
                limit = limits[i]
                if limit is None:
                    # Increase range by epsilon factor to take into account the fact
                    # That vaex considers the last binning interval open.
                    # Without this, samples, at the upper limits would be excluded
                    minmax = result[rasterization_groups[i]].minmax()
                    limit = [minmax[0], minmax[1] + (minmax[1] - minmax[0]) * eps]
                    limits[i] = limit

            binners = [
                vaex.groupby.Binner(
                    rasterization.y_column,
                    limits[0][0],
                    limits[0][1],
                    rasterization.plot_height,
                    df=result,
                ),
                vaex.groupby.Binner(
                    rasterization.x_column,
                    limits[1][0],
                    limits[1][1],
                    rasterization.plot_height,
                    df=result,
                ),
            ]

            if rasterization.color:
                binners.append(rasterization.color)
                # remove the relevant keys
                key_to_label = {
                    k: v
                    for k, v in key_to_label.items()
                    if v not in [rasterization.x_column, rasterization.y_column]
                }
            return delayed_list(
                [
                    None,
                    key_to_label,
                    result.binby(
                        binners, agg=vaex.agg.count(selection=filter), delay=True
                    ),
                    order_cache,
                ]
            )
        else:
            # finding unique elements is expensive, can we do without?
            # we use groupby to find unique elements
            result = result.groupby(
                groupers,
                agg={
                    FILTER_COLUMN_NAME: vaex.agg.count(selection=filter),
                },
                delay=True,
                copy=False,
            )

            @vaex.delayed
            def post_process(result):
                result = result[grouping_cols + [FILTER_COLUMN_NAME]]
                if top_n_exists:
                    result = result.sort(rank_cols)
                    result = result.drop(rank_cols)
                return result, key_to_label, None, order_cache

            return post_process(result)
    else:
        for key in weighted_keys:
            result[key_to_label[key]] = (
                result[sum_scaled_col(key)] / result[sum_weighted_col(key)]
            )
            cols_to_drop.append(sum_scaled_col(key))
            cols_to_drop.append(sum_weighted_col(key))

        aggregated_cols[FILTER_COLUMN_NAME] = vaex.agg.count(selection=filter)

        if grouping_cols:
            logger.debug("groupby: %s (agg=%s)", grouping_cols, aggregated_cols)

            @vaex.delayed
            def post_process(df_grouped):
                if top_n_exists:
                    df_grouped = df_grouped.sort(rank_cols)
                    temp_cols_to_drop = rank_cols
                    df_grouped = df_grouped.drop(temp_cols_to_drop)
                df_grouped = df_grouped.drop(cols_to_drop, inplace=True)
                return df_grouped, key_to_label, None, order_cache

            return post_process(
                result.groupby(groupers, agg=aggregated_cols, delay=True, copy=False)
            )
        else:
            aggregated_cols[FILTER_COLUMN_NAME] = vaex.agg.count(selection=filter)
            aggs = {
                name: df._agg(agg, delay=True) for name, agg, in aggregated_cols.items()
            }

            @vaex.delayed
            def make_df(values):
                values = {k: v for k, v in values.items() if k not in cols_to_drop}
                df = vaex.from_scalars(**values)
                return df, key_to_label, None, order_cache

            return make_df(aggs)


@delayed
def process_aggregate(
    query,
    empty_result,
    where_filter,
    order_for_category,
    update_order_for_category,
    colormap_for_category,
    data_schema,
    agg_result,
):
    element_df, key_to_label, xarray, order_cache = agg_result

    for key, order in order_cache.items():
        update_order_for_category(key, order)

    for j, (group_func, args, _) in enumerate(query.group_by):
        if group_func == "top_n":
            if not args.get("include_others"):
                vcolumn = virtual_column_name(
                    "top_n",
                    [
                        args["n"],
                        args["base_column"],
                        args["sort_order"],
                        args["include_others"],
                    ],
                )
                element_df = element_df[element_df[vcolumn] != "OTHER"]

    # order
    if query.order_by:
        assert (
            len(query.order_by) == 1
        )  # TODO: support multi columns sorting instead of only one
        element_df = element_df.sort(
            key_to_label[query.order_by[0][0]],
            ascending=query.order_by[0][1] == "asc",
        )

    # limit/offset
    element_df = dataframe_slice(element_df, query.offset, query.limit)
    if element_df is not None and xarray is None:
        if len(element_df) == 0:
            return empty_result

        # post filtering
        if FILTER_COLUMN_NAME in element_df:
            element_df = element_df[element_df[FILTER_COLUMN_NAME] > 0]
            element_df.drop(FILTER_COLUMN_NAME, inplace=True)
            if len(element_df) == 0:
                return empty_result

    if xarray is not None:
        result_df = None
        color_column = query.rasterization.color
        if color_column:
            xarray.attrs["color"] = color_column

        coord_keys = xarray.coords.keys()
        # use vaex to rename df['with spaces'] to 'with spaces'
        df_dummy = vaex.from_scalars(__workaround__=1)
        new_coord_keys = [
            vaex.expression.Expression(df_dummy, x)._label for x in coord_keys
        ]

        xarray = xarray.rename({x: y for x, y in zip(coord_keys, new_coord_keys)})
    else:
        result_df = (
            to_pandas_df_wrapper(element_df.to_pandas_df(), element_df)
            if element_df
            else None
        )

        # Instead, we put in an all true column
        if query.crossfilter_mask_key and where_filter is None:
            result_df[query.crossfilter_mask_key] = np.full(
                len(result_df), True, dtype="?"
            )
    return QueryResult(
        result_df,
        key_to_label,
        order_for_category,
        colormap_for_category,
        data_schema,
        rasterized_array=xarray,
        query=query,
    )


def _populate_virtual_cols(df, queries):

    for query in queries:
        if query is None:
            continue

        # pre-aggregate preparation: group by
        for group_func, args, _ in query.group_by:
            if group_func not in ("none", "top_n"):
                vcol = virtual_column_name(group_func, args)
                if vcol not in df.columns:
                    df[vcol] = groupfuncs[group_func](df, args)

        # pre-aggregage preparation: where
        for where_type, target, _ in query.crossfilter_values():
            # TODO: fetch the tuple of where_types from somewhere
            # where_types should be dynmaic
            if where_type in ("points", "range"):
                # TODO: fk: this is an anti-pattern
                # TODO: fk: make sure we find a better way to handle this
                if isinstance(target, dict):
                    group_func = target["function"]
                    args = target["args"]
                    vcol = virtual_column_name(group_func, args)
                    df[vcol] = groupfuncs[group_func](df, args)


def topn_labels(df, args, filter):
    n = args["n"]
    base_column = args["base_column"]
    (sort_aggfunc, sort_aggfunc_args) = args["sort_order"]
    agg = aggregator(df, sort_aggfunc, sort_aggfunc_args, filter=filter)

    @vaex.delayed
    def find_labels(dfg):
        labels, values = dfg.evaluate([base_column, "topn"])
        # sort descending using -, causes NaN to be last
        # When we sort ascending, and take the last n items, we also get nans
        indices = np.argsort(-values)
        labels = labels.take(indices[0:n:])
        return labels

    labels = find_labels(df.groupby(base_column, agg={"topn": agg}, delay=True))
    return labels


class VaexConnection(DataFrameConnection):
    def __init__(self, df, data_schema=None, orders=None, color_maps=None):
        if isinstance(df, pd.DataFrame):
            df = vaex.from_pandas(df)
        elif isinstance(df, vaex.dataframe.DataFrame):
            pass
        else:
            raise Exception("We only accept Pandas or Vaex dataframes for now")
        super().__init__(
            df,
            data_schema=data_schema,
            orders=orders,
            color_maps=color_maps,
        )

    def _execute_queries(self, queries):
        """
        Perform a data query described by a list of Query

        This method is responsible for querying data
        based on the provided list of Query object.
        For each Query provided in the list,
        a QueryResult is returned which contains data filtered based
        on every other Query except its own.

        Arguments:
          - queries (list of Query):

        Returns:
          - list of QueryResult
        """
        results = []
        df = self._df.copy()
        data_schema = self.get_data_schema()

        # TOOD: make this a part of the connection provider
        _populate_virtual_cols(df, queries)

        for i, query in enumerate(queries):
            if query and query.crossfilters:
                expression = where_expression(df, query.crossfilters)
                if expression is not None:
                    df[f"_dbe_where_{i}"] = expression
                else:
                    query.crossfilters = []
        filter_expressions = [
            df[f"_dbe_where_{i}"] if query is not None and query.crossfilters else None
            for i, query in enumerate(queries)
        ]

        empty_result = QueryResult(
            None,
            {},
            self.order_for_category,
            self.colormap_for_category,
            data_schema,
        )

        exclude_filtering_groups: list[list] = [
            s.exclude_filtering_group if s is not None else [] for s in queries
        ]

        # create cross filters
        filter_expressions_cross = []
        for i, query in enumerate(queries):
            if query is None or (len(query.select) == 0 and len(query.group_by) == 0):
                filter_expressions_cross.append(None)
            else:
                element_filter_expressions = [
                    e
                    for (j, e), filter_group in zip(
                        enumerate(filter_expressions), exclude_filtering_groups
                    )
                    if i != j and e is not None and query.id not in filter_group
                ]

                if query.filters:
                    element_filter_expressions.append(
                        where_expression(df, query.filters)
                    )

                element_filter_expression = and_expressions(
                    df, element_filter_expressions
                )
                filter_expressions_cross.append(element_filter_expression)

        if "DBE_QUERY_PICKLE" in os.environ:
            filename = os.path.abspath(os.environ["DBE_QUERY_PICKLE"])
            with open(filename, "wb") as f:
                pickle.dump(queries, f)
                print("wrote to", filename)

        with TimerVaex(df.executor, "connection", "vaex"):
            # we first find all values for topn
            with TimerVaex(df.executor, "connection", "vaex", "topn"):
                with TimerVaex(df.executor, "connection", "vaex", "topn", "prepare"):
                    for i, query in enumerate(queries):
                        if query:
                            for j, (group_func, args, _) in enumerate(query.group_by):
                                if group_func == "top_n":
                                    query.group_by[j][1]["values"] = topn_labels(
                                        df, args, filter=filter_expressions_cross[i]
                                    )
                with TimerVaex(df.executor, "connection", "vaex", "topn", "execute"):
                    df.execute()
                for i, query in enumerate(queries):
                    if query:
                        for j, (group_func, args, _) in enumerate(query.group_by):
                            if group_func == "top_n" and isinstance(
                                query.group_by[j][1]["values"],
                                vaex.promise.Promise,
                            ):
                                query.group_by[j][1]["values"] = query.group_by[j][1][
                                    "values"
                                ].get()

            # next pass is doing main aggregation
            with TimerVaex(df.executor, "connection", "vaex", "main"):
                for i, query in enumerate(queries):
                    with TimerVaex(
                        df.executor, "connection", "vaex", "main", "prepare", i
                    ):
                        if query is None or (
                            len(query.select) == 0 and len(query.group_by) == 0
                        ):
                            results.append(empty_result)
                            continue

                        extra_group_by = []

                        if query.rasterization:
                            # validate the preconditions for rasterization
                            data_schema = self.get_data_schema()

                            if data_schema.is_discrete(
                                query.rasterization.x_column
                            ) or data_schema.is_discrete(query.rasterization.y_column):
                                raise ValueError(
                                    "Both x-column and y-column have to be continuous"
                                )

                            elif query.rasterization.color:
                                # populate this before hand so we don't rely on result
                                self.order_for_category(query.rasterization.color)

                        # aggregate
                        agg_result = aggregate(
                            df,
                            query.select,
                            query.group_by
                            + [extra_gb.values() for extra_gb in extra_group_by],
                            rasterization=query.rasterization,
                            filter=filter_expressions_cross[i],
                            where_key=query.crossfilter_mask_key,
                            where_filter=filter_expressions[i],
                        )
                        results.append(
                            (
                                query,
                                empty_result,
                                filter_expressions[i],
                                self.order_for_category,
                                self.update_order_for_category,
                                self.colormap_for_category,
                                data_schema,
                                agg_result,
                            )
                        )
                        if not VAEX_DELAYED:
                            df.execute()
                            agg_result.get()

                with TimerVaex(df.executor, "connection", "vaex", "main", "execute"):
                    df.execute()
            # for testing purposes, we check only the passes doing aggregation,
            # not the vaex->pandas conversion
            passes_before_conversion = df.executor.passes
            # pass phase is converting to pandas
            with TimerVaex(df.executor, "connection", "vaex", "convert"):
                for i, result in enumerate(results):
                    with TimerVaex(df.executor, "connection", "vaex", "convert", i):
                        if not isinstance(result, QueryResult):
                            result = process_aggregate(*result)
                            df.execute()
                            results[i] = result.get()
        df.executor.passes = passes_before_conversion
        return results


class VaexConnectionProvider(DataFrameConnectionProvider):
    _cls = VaexConnection


class MultiVaexConnectionProvider(MultiDataFrameConnectionProvider):
    _cls = VaexConnection


class VaexFileConnectionProvider(CachingConnectionProvider):
    """
    Vaex connection provider to data stored in a file

    If `connection_params` is a string, it is interpreted as a filepath.
    If it is a dict, its `url` value is interpreted as a filepath.
    Optionally, the key `parse_dates` can contain a list of column names
    which should be parsed as date.

    The file must have one of the following supported extension:
      - csv
      - parquet
      - hdf5
    """

    def __init__(self, default_connection_params=None, orders=None, color_maps=None):
        super().__init__()
        self.default_connection_params = default_connection_params
        self._orders = orders
        self._color_maps = color_maps

    def _get_uncached_connection(self, connection_params, user_data):
        if not connection_params and self.default_connection_params:
            connection_params = self.default_connection_params

        if isinstance(connection_params, str):
            connection_params = dict(url=connection_params)

        url = connection_params["url"]
        if re.search("csv(\\?.*)?$", url):
            df = vaex.from_csv(
                url,
                copy_index=False,
                parse_dates=connection_params.get("parse_dates", []),
                convert=True,
                progress=True,
            )
        elif re.search("parquet(\\?.*)?$", url) or re.search("parq(\\?.*)?$", url):
            df = vaex.open(url, convert=True, progress=True)
        elif re.search("hdf5(\\?.*)?$", url):
            df = vaex.open(url)
        else:
            raise "Unsupported file extension"

        return VaexConnection(df, orders=self._orders, color_maps=self._color_maps)
