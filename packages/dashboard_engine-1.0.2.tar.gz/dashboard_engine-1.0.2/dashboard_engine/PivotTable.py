# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class PivotTable(Component):
    """A PivotTable component.
The Pivot Table component is used to power the Pivot Table DBE element.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- axis_assignment (dict; optional):
    The axis assignment.

- data (dict; optional):
    The data.

- format (boolean | number | string | dict | list; optional):
    The number format.

- selectionOutput (dict; optional):
    The selection output.

- title (string; optional):
    The title."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, data=Component.UNDEFINED, axis_assignment=Component.UNDEFINED, selectionOutput=Component.UNDEFINED, title=Component.UNDEFINED, format=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'axis_assignment', 'data', 'format', 'selectionOutput', 'title']
        self._type = 'PivotTable'
        self._namespace = 'dashboard_engine'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'axis_assignment', 'data', 'format', 'selectionOutput', 'title']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(PivotTable, self).__init__(**args)
