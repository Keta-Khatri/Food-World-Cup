# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DashboardEditor(Component):
    """A DashboardEditor component.
The Dashboard Editor is used in conjunction with the Canvas.

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The children of this component.

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- selected_element (number; default -1):
    The element being edited."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, selected_element=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'selected_element']
        self._type = 'DashboardEditor'
        self._namespace = 'dashboard_engine'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'selected_element']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(DashboardEditor, self).__init__(children=children, **args)
