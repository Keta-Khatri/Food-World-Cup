import json
import os
from setuptools import setup


with open("package.json") as f:
    package = json.load(f)

package_name = package["name"].replace(" ", "_").replace("-", "_")

setup(
    name=package_name,
    version=package["version"],
    author=package["author"],
    packages=[
        "dashboard_engine",
        "dashboard_engine/api",
        "dashboard_engine/api/elements",
        "dashboard_engine/api/connections",
    ],
    include_package_data=True,
    license=package["license"],
    description=package.get("description", package_name),
    install_requires=[
        "datashader",
        "dash>=1.21.0",
        "nested_lookup==0.2.22",
        "pandas==1.*",
        "plotly>=5.2.1",
        'cryptography<3.4;python_version<"3.7"',
        "vaex-core>=4.6.0,<5",
        "vaex-hdf5==0.11.0",
        "numpy<=1.20.0",  # because of numba
        "diskcache",
        "cachetools",
        "dash_enterprise_auth",
        "toolz",
        "morph",
        "flask_request_id",
        "pydantic[dotenv]",  # a workaround for DE4, see PR for details
        "blake3<0.3"  # can be removed when Vaex 4.8 is out
    ],
    python_requires='>=3',
    classifiers=[
        "Framework :: Dash",
        "Programming Language :: Python :: 3",
    ],
)
