import dash
from dash.dependencies import Output

if hasattr(dash, 'html'):
    html = dash.html
else:
    import dash_html_components as html

import dash_design_kit as ddk
import traceback


class LayoutNotDDKAppError(Exception):
    """Raised when app.layout is not of type ddk.App"""
    pass


class notification_manager(object):
    def __init__(self, app, notification_store=None):
        self._callback_counter = 0
        self._app = app
        self._app.server.before_first_request(self._add_notifiers_to_layout)
        self.error_store_id = 'ddk_error_notifier'
        self.notifier_store_id = 'ddk_notifier_store'

    def _add_notifiers_to_layout(self):
        if type(self._app.layout) != ddk.App:
            raise LayoutNotDDKAppError(
                """
                Your app's layout of type {} is not of type dash_design_kit.App.
                Dash app instances passed to ddk.notification_manager
                must by of type dash_design_kit.App (ddk.App) for Exception
                Notifications to be displayed. For example:

                app = dash.Dash(__name__)
                notification_manager = ddk.notification_manager(app)
                # this assignment must be ddk.App, instead of html.Div etc.
                app.layout = ddk.App(...)
                """.format(type(self._app.layout))
            )

        if not isinstance(self._app.layout.children, list):
            self._app.layout.children = [self._app.layout.children]

        # Add a Div for each error_notifier.callback
        for i in range(self._callback_counter):
            self._app.layout.children.append(
                html.Div(
                    id='{}_{}'.format(self.error_store_id, i)
                )
            )

    def callback(self, *callback_args, **callback_kwargs):
        # scope callback_counter
        callback = self._create_callback(
            self._callback_counter,
            *callback_args,
            **callback_kwargs
        )
        self._callback_counter += 1
        return callback

    def _create_callback(self, callback_index, *callback_args, **callback_kwargs):
        def inner(func):
            error_message = callback_kwargs.pop(
                'error_message',
                'An error occurred processing this request.'
            )

            # Update the store
            error_notifier_output = Output(
                '{}_{}'.format(self.error_store_id, callback_index),
                'children'
            )

            # Output is the first argument always
            # unless https://github.com/plotly/dash/pull/1180 was implemented.
            n_flat_outputs = len([
                o for o in callback_args if isinstance(o, dash.dependencies.Output)
            ])
            if n_flat_outputs > 1:
                # User is using new flat Output structure as per 1180 like
                # app.callback(Output, Output, Input, Input)
                new_callback_args = (error_notifier_output,) + callback_args
                n_outputs = n_flat_outputs + 1
            else:
                # Output is first argument
                output = callback_args[0]
                if not isinstance(output, list):
                    # convert app.callback(Output, [Input])
                    # to app.callback([error_notifier_output, Output], [Input])
                    output = [error_notifier_output, output]
                else:
                    # app.callback([Output, Output], [Input])
                    output.insert(0, error_notifier_output)

                new_callback_args = (output,) + callback_args[1:]
                n_outputs = len(output)

            def inner_inner(*func_args, **func_kwargs):
                # update the response to include the new error output value
                try:
                    output_value = func(*func_args, **func_kwargs)
                    # No error, so send a `no_update` to the error store
                    if n_outputs == 2:
                        return [dash.no_update, output_value]
                    else:
                        output_value.insert(0, dash.no_update)
                    return output_value
                except Exception as e:
                    print(traceback.format_exc())
                    print(e)
                    if not isinstance(error_message, ddk.Notification):
                        notification = ddk.Notification(
                            error_message,
                            title='Exception Thrown'
                        )
                    else:
                        notification = error_message

                    return (
                        [notification] +
                        ([dash.no_update] * (n_outputs-1))
                    )

            # wrap in a normal callback
            return self._app.callback(
                *new_callback_args,
                **callback_kwargs
            )(inner_inner)

        return inner
