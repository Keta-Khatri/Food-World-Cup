# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class NotificationStore(Component):
    """A NotificationStore component.


Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The list of components that are children of the NotificationStore.
- id (string; optional): The ID of this component, used to identify Dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- timeout (number | boolean; default 5 * 1000): The time in milliseconds for which the NotificationStore will
remain onscreen. Default is 5*1000. -1 indicates no timeout.
- displayed (boolean; default True): Whether or not Notifications in NotificationStore are displayed.
- className (string; optional): Optional user-defined CSS class for the NotificationStore
- style (dict; optional): Optional additional CSS styles.
- If `width`, `padding`, or `margin` are supplied within `style`,
then this will override the component-level `width`, `padding`, or `margin`.
- width (number | string; default '20%'): Default width of each Notification in pixels.
Will be overridden by the `width` property of individual Notifications.
- type_display (list of booleans; default [true, true, true]): Array of booleans for filtering which types of array representing 'info', 'warn', 'danger'"""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, timeout=Component.UNDEFINED, displayed=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, width=Component.UNDEFINED, type_display=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'timeout', 'displayed', 'className', 'style', 'width', 'type_display']
        self._type = 'NotificationStore'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'timeout', 'displayed', 'className', 'style', 'width', 'type_display']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(NotificationStore, self).__init__(children=children, **args)
