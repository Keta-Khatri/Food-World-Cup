# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Header(Component):
    """A Header component.
An app-level header component.

**Example Usage**
```
ddk.Header([
    ddk.Title('FRED Economic Indicators'),
    ddk.Logo(src='/assets/my-logo.png'),
    ddk.Menu([
        ddk.CollapsibleMenu(
            title='Monetary Data',
            children=[
                dcc.Link(
                'Monetary Base',
                href='/monetary-base'
            ),
            dcc.Link(
                'Money Velocity',
                href='/money-velocity'
            ),
            dcc.Link(
                'Reserves',
                href='/reserves'
            ),
            dcc.Link(
                'Borrowings',
                href='/borrowings'
            )
        ]),
        dcc.Link('Conditions', href='/conditions'),
        dcc.Link('Investment', href='/investments'),
        dcc.Link('Other', href='/other'),
    ])
])
```

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The contents of the Header. This is frequently a list containing a
    `ddk.Logo`, a `ddk.Title`, and a `ddk.Menu`: ``` [
    ddk.Logo(src='/assets/logo.png'),     ddk.Title('Header Title'),
    ddk.Menu([         dcc.Link('Historical', href='/historical'),
    dcc.Link('Forecast', href='/forecast')     ]), ] ``` but it can
    also contain arbitrary components like controls or buttons.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- background_color (string; optional):
    The background color applied to the header. Overrides
    theme.header_background_color.

- border_color (string; optional):
    The border color applied to the header. Overrides
    theme.header_border.color.

- border_radius (string; optional):
    The border radius applied to the header. Overrides
    theme.header_border.radius.

- border_style (string; optional):
    The border style applied to the header. Overrides
    theme.header_border.style.

- border_width (string; optional):
    The border width applied to the header. Overrides
    theme.header_border.width.

- box_shadow (string; optional):
    The box shadow(s) applied to the header. Overrides
    theme.header_box_shadow.

- className (string; optional):
    Optional user-defined CSS class for the Header.

- content_alignment (a value equal to: 'spread', 'left', 'right', 'center'; optional):
    The alignment of header content (ddk.Logo, ddk.Title, controls,
    and ddk.Menu). Default (legacy) value is 'spread', where controls
    stretch to fit between other components. (when appropriate). For
    other values, controls will have a min-width of 200px and
    otherwise have a width that fits its content. Overrides
    theme.header_content_alignment.

- font_color (string; optional):
    The font color of Header children. Overrides theme.header_text.

- font_family (string; optional):
    The font family of Header children. Overrides
    theme.font_family_header.

- font_size (string; optional):
    The font size of Header children. Can be a relative size,
    \"smaller\", \"normal\", \"larger\", or a CSS attribute size (e.g.
    `px`, 'em`).

- margin (number; optional):
    Space (in pixels) surrounding the header. Overrides
    theme.header_margin.

- padding (number; optional):
    Space (in pixels) on the inside of the header, between the border
    and the edge of the content. Overrides theme.header_padding.

- style (dict; optional):
    The style object of the outermost div of the Header. Use this to
    override e.g. the Header's height (`{'height': '100px'}`)."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, className=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, background_color=Component.UNDEFINED, box_shadow=Component.UNDEFINED, border_width=Component.UNDEFINED, border_style=Component.UNDEFINED, border_color=Component.UNDEFINED, border_radius=Component.UNDEFINED, content_alignment=Component.UNDEFINED, font_color=Component.UNDEFINED, font_family=Component.UNDEFINED, font_size=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'background_color', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'className', 'content_alignment', 'font_color', 'font_family', 'font_size', 'margin', 'padding', 'style']
        self._type = 'Header'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'background_color', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'className', 'content_alignment', 'font_color', 'font_family', 'font_size', 'margin', 'padding', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Header, self).__init__(children=children, **args)
