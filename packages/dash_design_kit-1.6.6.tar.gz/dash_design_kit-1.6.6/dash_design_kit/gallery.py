# -*- coding: utf-8 -*-
import dash_core_components as dcc
import dash_html_components as html
import dash_design_kit as ddk
from datetime import datetime as dt

# TODO - get rid of pandas requirement
import pandas as pd
from textwrap import dedent

from ._sample_datasets import cone_data

def Dropdowns():
    options = [
        {'label': 'New York City', 'value': 'NYC'},
        {'label': u'Montréal', 'value': 'MTL'},
        {'label': 'San Francisco', 'value': 'SF'}
    ]
    return [
        [
            html.Label('Dropdown'),
            dcc.Dropdown(
                options=options,
                value='MTL',
                clearable=True
            )
        ],

        [
            html.Label('Multi-Select Dropdown'),
            dcc.Dropdown(
                options=options,
                value=['MTL', 'SF'],
                multi=True,
                clearable=True
            )
        ],

        [
            html.Label('Placeholder'),
            dcc.Dropdown(
                options=options,
                placeholder='Select a city'
            )
        ],

        [
            html.Label('Disabling Search'),
            dcc.Dropdown(
                options=options,
                searchable=False
            )
        ],

        [
            html.Label('Disabled Dropdown'),
            dcc.Dropdown(
                options=options,
                value='MTL',
                disabled=True
            )
        ],

        [
            html.Label('Disabled Multi Dropdown'),
            dcc.Dropdown(
                options=options,
                value=['MTL', 'SF'],
                multi=True
            )
        ]
    ]


def Sliders():
    return [
        [
            html.Label('Default Slider'),
            dcc.Slider(
                min=0,
                max=20,
                step=0.5,
                value=10,
            )
        ],

        [
            html.Label('Marks and Steps'),
            dcc.Slider(
                min=0,
                max=10,
                step=None,
                marks={
                    0: '0 °F',
                    3: '3 °F',
                    5: '5 °F',
                    7.65: '7.65 °F',
                    10: '10 °F'
                },
                value=5
            )
        ],

        [
            html.Label('With Dots'),
            dcc.Slider(
                min=0,
                max=20,
                step=2,
                value=10,
            )
        ],

        [
            html.Label('Disabled'),
            dcc.Slider(
                min=0,
                max=20,
                step=2,
                value=10,
                disabled=True
            )
        ],

        [
            html.Label('Included=False'),
            dcc.Slider(
                min=0,
                max=20,
                step=2,
                value=10,
                included=False
            )
        ]
    ]


def RangeSliders():
    return [
        [
            html.Label('Default Slider'),
            dcc.RangeSlider(
                min=0,
                max=20,
                step=0.5,
                value=[10, 12],
            )
        ],

        [
            html.Label('Marks and Steps'),
            dcc.RangeSlider(
                min=0,
                max=10,
                step=None,
                marks={
                    0: '0 °F',
                    3: '3 °F',
                    5: '5 °F',
                    7.65: '7.65 °F',
                    10: '10 °F'
                },
                value=5
            )
        ],

        [
            html.Label('With Dots'),
            dcc.RangeSlider(
                min=0,
                max=20,
                step=2,
                value=[10, 12],
            )
        ],

        [
            html.Label('Disabled'),
            dcc.RangeSlider(
                min=0,
                max=20,
                step=2,
                value=[10, 12],
                disabled=True
            )
        ],

        [
            html.Label('Included=False'),
            dcc.RangeSlider(
                min=0,
                max=20,
                step=2,
                value=[10, 12],
                disabled=True
            )
        ]
    ]


def DatePickerSingles():
    return [
        [
            html.Label('Default'),
            dcc.DatePickerSingle(
                date=dt.now()
            )
        ],

        [
            html.Label('Max and Min Date Allowed'),
            dcc.DatePickerSingle(
                date=dt(2017, 2, 15),
                min_date_allowed=dt(2017, 2, 10),
                max_date_allowed=dt(2017, 2, 20),
            )
        ],

        [
            html.Label('Vertical'),
            dcc.DatePickerSingle(
                date=dt(2017, 2, 15),
                calendar_orientation='vertical'
            )
        ],

        [
            html.Label('Clearable'),
            dcc.DatePickerSingle(
                date=dt(2017, 2, 15),
                min_date_allowed=dt(2017, 2, 10),
                max_date_allowed=dt(2017, 2, 20),
                calendar_orientation='vertical',
                clearable=True
            )
        ],

        [
            html.Label('Number of Months Shown'),
            dcc.DatePickerSingle(
                date=dt(2017, 2, 15),
                number_of_months_shown=3
            )
        ],

        [
            html.Label('Placeholder'),
            dcc.DatePickerSingle(
                placeholder='Select a date...'
            )
        ],

        [
            html.Label('Show Outside Days'),
            dcc.DatePickerSingle(
                date=dt.now(),
                show_outside_days=True
            )
        ],

        [
            html.Label('Full Screen Portal'),
            dcc.DatePickerSingle(
                date=dt.now(),
                with_full_screen_portal=True
            )
        ],

        [
            html.Label('Portal'),
            dcc.DatePickerSingle(
                date=dt.now(),
                with_portal=True
            )
        ],

        [
            html.Label('Day Size'),
            dcc.DatePickerSingle(
                date=dt.now(),
                day_size=50
            )
        ]
    ]


def DatePickerRanges():
    return [
        [
            html.Label('Default'),
            dcc.DatePickerRange(
                start_date=dt.now()
            )
        ],

        [
            html.Label('Max and Min Date Allowed'),
            dcc.DatePickerRange(
                start_date=dt(2017, 2, 15),
                min_date_allowed=dt(2017, 2, 10),
                max_date_allowed=dt(2017, 2, 20),
            )
        ],

        [
            html.Label('Vertical'),
            dcc.DatePickerRange(
                start_date=dt(2017, 2, 15),
                calendar_orientation='vertical'
            )
        ],

        [
            html.Label('Clearable'),
            dcc.DatePickerRange(
                start_date=dt(2017, 2, 15),
                min_date_allowed=dt(2017, 2, 10),
                max_date_allowed=dt(2017, 2, 20),
                calendar_orientation='vertical',
                clearable=True
            )
        ],

        [
            html.Label('Number of Months Shown'),
            dcc.DatePickerRange(
                start_date=dt(2017, 2, 15),
                number_of_months_shown=3
            )
        ],

        [
            html.Label('Placeholder'),
            dcc.DatePickerRange(
                start_date_placeholder_text='Select a date...'
            )
        ],

        [
            html.Label('Show Outside Days'),
            dcc.DatePickerRange(
                start_date=dt.now(),
                show_outside_days=True
            )
        ],

        [
            html.Label('Full Screen Portal'),
            dcc.DatePickerRange(
                start_date=dt.now(),
                with_full_screen_portal=True
            )
        ],

        [
            html.Label('Portal'),
            dcc.DatePickerRange(
                start_date=dt.now(),
                with_portal=True
            )
        ],

        [
            html.Label('Day Size'),
            dcc.DatePickerRange(
                start_date=dt.now(),
                day_size=50
            )
        ],

        [
            html.Label('Minimum Nights'),
            dcc.DatePickerRange(
                start_date=dt.now(),
                minimum_nights=5
            )
        ],
    ]


def TextInputs():
    return [
        [
            html.Label('Input Without Type'),
            dcc.Input()
        ],


        [
            html.Label('Text Input With Value'),
            dcc.Input(
                type='text',
                value='Value'
            )
        ],

        [
            html.Label('Text Input With Placeholder'),
            dcc.Input(
                type='text',
                placeholder='Enter a value...'
            )
        ],

        [
            html.Label('Textarea'),
            dcc.Textarea()
        ],

        [
            html.Label('Textarea With Placeholder'),
            dcc.Textarea(
                placeholder='Enter a value...'
            )
        ],

        [
            html.Label('Textarea With Value'),
            dcc.Textarea(
                value='Value'
            )
        ],
    ]


def Checkboxes():
    options = [
        {'label': 'New York City', 'value': 'NYC'},
        {'label': 'Montréal', 'value': 'MTL'},
        {'label': 'San Francisco', 'value': 'SF'}
    ]
    values = ['MTL', 'SF']
    return [
        [
            html.Label('Checkboxes'),
            dcc.Checklist(options=options, value=values)
        ],
        [
            html.Label('Horizontal Checkboxes'),
            dcc.Checklist(
                options=options,
                value=values,
                labelStyle={'display': 'inline-flex'}
            )
        ]
    ]


def RadioItems():
    options = [
        {'label': 'New York City', 'value': 'NYC'},
        {'label': 'Montréal', 'value': 'MTL'},
        {'label': 'San Francisco', 'value': 'SF'}
    ]
    value = 'MTL'
    return [
        [
            html.Label('RadioItems'),
            dcc.RadioItems(options=options, value=value)
        ],
        [
            html.Label('Horizontal RadioItems'),
            dcc.RadioItems(
                options=options,
                value=value,
                labelStyle={'display': 'inline-flex'}
            )
        ]
    ]


def Buttons():
    return [
        [
            html.Label('Button'),
            html.Button('Submit')
        ],
        [
            html.Label('Button Disabled'),
            html.Button('Submit', disabled=True)
        ],
        [
            html.Label('Button Primary'),
            html.Button('Submit', className="button-primary")
        ]
    ]


def Text():
    return [
        [
            html.Label('Markdown'),
            dcc.Markdown(dedent('''
                #### Dash and Markdown

                Dash supports [Markdown](http://commonmark.org/help).

                Markdown is a simple way to write and format text.
                It includes a syntax for things like **bold text** and
                *italics*,
                [links](http://commonmark.org/help), inline `code` snippets,
                lists, quotes, and more.

                > Don't forget blockquotes!
                > Blockquotes have a simple left border and an indent,
                > there is nothing too fancy here.
                > These styles are meant to be familiar with GitHub markdown.
            '''))
        ],

        [
            html.H1('Heading 1'),
            html.H2('Heading 2'),
            html.H3('Heading 3'),
            html.H4('Heading 4'),
            html.H5('Heading 5'),
            html.H6('Heading 6'),
        ],

        [
            html.Ul([
                html.Li('Unordered Lists have basic styles'),
                html.Li('They use the circle list style'),
                html.Li([
                    'Also, ',
                    html.Ul([
                        html.Li('nested lists feel right'),
                        html.Li('This could be a Ul or a Ol'),
                    ])
                ])
            ])
        ],

        [
            html.Ol([
                html.Li('Ordered Lists have basic styles too'),
                html.Li('They use the decimal list style'),
                html.Li([
                    'And also',
                    html.Ol([
                        html.Li('ordered lists can be nested too'),
                        html.Li('As could unordered lists'),
                    ])
                ])
            ])
        ]
    ]


def Tables():
    return [
        [
            html.Label('Simple Tables'),
            html.Table([
                html.Thead(
                    html.Tr([
                        html.Th('Name'),
                        html.Th('Age'),
                        html.Th('Sex'),
                        html.Th('Location'),
                    ])
                ),
                html.Tbody([
                    html.Tr([
                        html.Td('Dave Gamache'),
                        html.Td(26),
                        html.Td('Male'),
                        html.Td('San Francisco'),
                    ]),
                    html.Tr([
                        html.Td('Dwayne Johnson'),
                        html.Td(42),
                        html.Td('Male'),
                        html.Td('Hayward'),
                    ])
                ])
            ])
        ]
    ]

def Graphs():
    df_streamtube = ddk.datasets.df_streamtube()
    df_choropleth = ddk.datasets.df_choropleth()
    df_scattergeo = ddk.datasets.df_scattergeo()
    df_iris = ddk.datasets.df_iris()

    x = [1, 2, 3]
    labels = ['Montreal', 'Tofu Bowl', 'Tropical Beaches']
    labels_long = [
        'Montreal', 'New York City', 'Tokyo',
        'Cincinatti', 'Miami', 'London', 'Vancouver'
    ]
    values_long = [1, 2, 3, 1, 5, 6, 7]
    y1 = [3, 1, 2]
    y2 = [4, 10, 4]
    y3 = [5, 2, 3]
    y4 = [9, 3, 8]
    y5 = [10, 5, 12]
    y6 = [11, 8, 10]
    y7 = [1, 2, 1]
    y8 = [5, 3, 1]
    z = [5, 3, 1]
    matrix = [
        [1, 2, 3],
        [4, 1, 2],
        [1, 3, 4]
    ]

    open = [33.0, 33.3, 33.5, 33.0, 34.1]
    high = [33.1, 33.3, 33.6, 33.2, 34.8]
    low = [32.7, 32.7, 32.8, 32.6, 32.8]
    close = [33.0, 32.9, 33.3, 33.1, 33.1]
    dates = [dt(year=2013, month=10, day=10),
             dt(year=2013, month=11, day=10),
             dt(year=2013, month=12, day=10),
             dt(year=2014, month=1, day=10),
             dt(year=2014, month=2, day=10)]

    r = [0.5, 1, 2, 2.5, 3, 4]
    theta = [35, 70, 120, 155, 205, 240]


    datas = [
        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'lines'},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y3, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y4, 'mode': 'lines'},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y3, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y4, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y5, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y6, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y7, 'mode': 'lines'},
            {'type': 'scatter', 'x': x, 'y': y8, 'mode': 'lines'},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'markers'},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y3, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y4, 'mode': 'markers'},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y3, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y4, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y5, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y6, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y7, 'mode': 'markers'},
            {'type': 'scatter', 'x': x, 'y': y8, 'mode': 'markers'},
        ],

        [
            {
                'type': 'scatter', 'x': x, 'y': y1, 'marker': {'color': y2},
                'mode': 'markers'
            },
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'lines+markers'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'lines+markers'},
        ],

        [
            {'type': 'bar', 'x': labels, 'y': y1},
            {'type': 'bar', 'x': labels, 'y': y2},
        ],

        [
            {'type': 'bar', 'x': labels, 'y': y1},
            {'type': 'bar', 'x': labels, 'y': y2},
            {'type': 'bar', 'x': labels, 'y': y3},
            {'type': 'bar', 'x': labels, 'y': y4},
        ],

        [
            {'type': 'bar', 'x': labels, 'y': y1},
            {'type': 'bar', 'x': labels, 'y': y2},
            {'type': 'bar', 'x': labels, 'y': y3},
            {'type': 'bar', 'x': labels, 'y': y4},
            {'type': 'bar', 'x': labels, 'y': y5},
            {'type': 'bar', 'x': labels, 'y': y6},
            {'type': 'bar', 'x': labels, 'y': y7},
            {'type': 'bar', 'x': labels, 'y': y8},
        ],

        [
            {'type': 'scatter', 'x': x, 'y': y1, 'mode': 'lines', 'fill': 'tonexty'},
            {'type': 'scatter', 'x': x, 'y': y2, 'mode': 'lines', 'fill': 'tonexty'},
        ],

        [
            {'type': 'heatmap', 'z': matrix}
        ],

        [
            {'type': 'contour', 'z': matrix}
        ],

        [
            {'type': 'histogram2d', 'x': x, 'y': y1}
        ],

        [
            {'type': 'histogram2dcontour', 'x': x, 'y': y1}
        ],

        [
            {'type': 'pie', 'labels': labels, 'values': y1}
        ],

        [
            {'type': 'pie', 'labels': labels_long, 'values': values_long}
        ],

        [
            {'type': 'box', 'y': y1},
            {'type': 'box', 'y': y2}
        ],

        [
            {'type': 'box', 'y': y1, 'boxpoints': 'all'},
            {'type': 'box', 'y': y2, 'boxpoints': 'all'}
        ],

        [
            {'type': 'violin', 'y': y1},
            {'type': 'violin', 'y': y2}
        ],

        [
            {'type': 'violin', 'y': y1, 'points': 'all'},
            {'type': 'violin', 'y': y2, 'points': 'all'}
        ],

        [
            {'type': 'histogram', 'y': y1}
        ],

        [
            {'type': 'scatter3d', 'x': x, 'y': y1, 'z': z, 'mode': 'markers'},
            {'type': 'scatter3d', 'x': x, 'y': y2, 'z': z, 'mode': 'markers'}
        ],

        [
            {'type': 'scatter3d', 'x': x, 'y': y1, 'z': z, 'mode': 'lines'},
            {'type': 'scatter3d', 'x': x, 'y': y2, 'z': z, 'mode': 'lines'}
        ],

        [
            {'type': 'scatter3d', 'x': x, 'y': y1, 'z': z, 'mode': 'markers+lines'},
            {'type': 'scatter3d', 'x': x, 'y': y2, 'z': z, 'mode': 'markers+lines'}
        ],

        [
            {'type': 'surface', 'z': matrix}
        ],

        [
            {
                'type': 'cone',
                'x': [row[0] for row in cone_data],
                'y': [row[1] for row in cone_data],
                'z': [row[2] for row in cone_data],
                'u': [row[3] for row in cone_data],
                'v': [row[4] for row in cone_data],
                'w': [row[5] for row in cone_data],
            }
        ],

        [
            {
                'type': 'streamtube',
                'x': df_streamtube['x'],
                'y': df_streamtube['y'],
                'z': df_streamtube['z'],
                'u': df_streamtube['u'],
                'v': df_streamtube['v'],
                'w': df_streamtube['w'],
                'sizeref': 0.5
            }
        ],

        [
            {
                'type': 'choropleth',
                'z': df_choropleth['GDP (BILLIONS)'],
                'locations': df_choropleth['CODE'],
                'text': df_choropleth['COUNTRY']
            }
        ],

        [
            {
                'type': 'scattergeo',
                'lon': df_scattergeo['long'],
                'lat': df_scattergeo['lat'],
                'mode': 'markers',
            }
        ],

        [
            {
                'type': 'scattermapbox',
                'lon': df_scattergeo['long'],
                'lat': df_scattergeo['lat'],
                'mode': 'markers',
            }
        ],

        [
            {
                'type': 'candlestick',
                'open': open,
                'high': high,
                'low': low,
                'close': close
            }
        ],

        [
            {
                'type': 'ohlc',
                'open': open,
                'high': high,
                'low': low,
                'close': close
            }
        ],

        [
            {'type': 'scatterternary', 'a': x, 'b': y1, 'c': y2, 'mode': 'markers'},
        ],

        [
            {'type': 'scatterternary', 'a': x, 'b': y1, 'c': y2, 'mode': 'lines'},
        ],

        [
            {'type': 'scatterpolar', 'r': r, 'theta': theta, 'mode': 'markers'},
        ],
        [
            {'type': 'scatterpolar', 'r': r, 'theta': theta, 'mode': 'lines'},
        ],

        [
            dict(
                type='parcoords',
                dimensions=list([
                    dict(range=[0,8],
                        constraintrange=[4,8],
                        label='Sepal Length', values=df_iris['sepal_length']),
                    dict(range=[0,8],
                        label='Sepal Width', values=df_iris['sepal_width']),
                    dict(range=[0,8],
                        label='Petal Length', values=df_iris['petal_length']),
                    dict(range=[0,8],
                        label='Petal Width', values=df_iris['petal_width'])
                ])
            )
        ],

        [
            dict(
                type='sankey',
                node=dict(
                    label=["Nuclear", "Wind Energy", "Thermal", "Bio Conversion", "Airline Industry", "Losses"],
                ),
                link=dict(
                    source=[0, 1, 0, 2, 3, 3],
                    target=[2, 3, 3, 4, 4, 5],
                    value=[8, 4, 2, 8, 4, 2]
                )
            )
        ],

        [
            {
                'type': 'carpet',
                'a': [4, 4, 4, 4.5, 4.5, 4.5, 5, 5, 5, 6, 6, 6],
                'b': [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3],
                'y': [2, 3.5, 4, 3, 4.5, 5, 5.5, 6.5, 7.5, 8, 8.5, 10],
            }
        ],

        [
            {
                'type': 'contourcarpet',
                'a': [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3],
                'b': [4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6],
                'z': [1, 1.96, 2.56, 3.0625, 4, 5.0625, 1, 7.5625, 9, 12.25, 15.21, 14.0625],
            },
            {
                'type': 'carpet',
                'a': [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3],
                'b': [4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6],
                'x': [2, 3, 4, 5, 2.2, 3.1, 4.1, 5.1, 1.5, 2.5, 3.5, 4.5],
                'y': [1, 1.4, 1.6, 1.75, 2, 2.5, 2.7, 2.75, 3, 3.5, 3.7, 3.75],
            }
        ]

    ]

    return html.Div([
        ddk.Card(width=25, children=[
            ddk.CardHeader(title=data[0]['type']),
            ddk.Graph(
                id='graph-{}'.format(i),
                figure={
                    'data': data,
                    'layout': {
                        'title': 'Hello World',
                    }
                }
            )
        ])
        for (i, data) in enumerate(datas)
    ])


layout = html.Div(
    [Graphs()] +
    [html.Div(
        className='container',
        children=[
            ddk.Block(example, width=33)
            for example in suite()
        ]) for suite in [
            Dropdowns,
            Sliders,
            DatePickerSingles,
            DatePickerRanges,
            TextInputs,
            Checkboxes,
            RadioItems,
            Buttons,
            Text,
            Tables
        ]
    ]
)
