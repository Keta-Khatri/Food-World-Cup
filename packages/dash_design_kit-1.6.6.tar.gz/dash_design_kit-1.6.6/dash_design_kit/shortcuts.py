import dash_design_kit as ddk

import dash
if hasattr(dash, 'html'):
    html = dash.html
else:
    import dash_html_components as html

from ._utils import _merge


def create_sparklines_figure(x, y):
    axis = dict(
        showgrid=False,
        ticks='',
        showticklabels=False,
        showline=False
    )

    fig = {
        'data': [{
            'x': x,
            'y': y,
            'type': 'scatter',
            'mode': 'lines',
        }],
        'layout': {
            'margin': {
                'l': 0,
                'r': 0,
                't': 0,
                'b': 0
            },
            'xaxis': axis,
            'yaxis': axis,
            'height': 120
        }
    }

    return fig


def create_pie(value, name, color='rgba(59, 64, 72, 100)', **card_props):
    # TODO: Read in bgcolor from theme
    fig = {
        'data': [{
            'values': value,
            'textinfo': 'none',
            'hoverinfo': 'value+percent',
            'type': 'pie',
            'hole': 0.5,
            'marker': {'colors': [color, 'var(--border)'],
                       'line': {'width': 20, 'color': 'var(--background)'}}
        }],
        'layout': {
            'margin': {
                'l': 10,
                'r': 10,
                't': 10,
                'b': 10
            },
            'showlegend': False,
            'height': 200,
        }
    }

    pie = ddk.Graph(
        id='id'+name,
        figure=fig,
        config={'displayModeBar': False}
    )

    return ddk.Card(pie, **card_props)


def create_percent_table(percent, col, bar_color='var(--accent)',
                         row_height=40, **card_props):
    # TODO: GET TEXT WRAPPING FOR HIGH OR LOW %
    row_style = {'height': row_height,
                 'borderBottom': 'thin gray solid',
                 'display': 'inline-block',
                 'lineHeight': str(row_height)+'px'}
    child_divs = []

    for i in range(len(percent)):
        child_divs.append(
            html.Div([
                html.Div(
                    col[i],
                    style=_merge(row_style, {
                        'width': str(percent[i])+'%',
                        'backgroundColor':bar_color,
                        'padding-left':10
                    })
                ),
                html.Div(
                    [html.B(str(percent[i])+'%')],
                    style=_merge(row_style, {
                        'width': str(100-percent[i])+'%',
                        'textAlign':'right',
                        'padding-right':10
                    })
                )
            ])
        )
    ptable = html.Div(children=child_divs, style={'border': 'thin gray solid'})

    return ddk.Card(ptable, **card_props)
