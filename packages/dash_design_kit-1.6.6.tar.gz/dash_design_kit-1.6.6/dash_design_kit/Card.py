# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Card(Component):
    """A Card component.
A layout component used for easily arranging groups of elements.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Card(
        width=30,
        children=[
            # this content takes up 30% of the screen's width
        ]
    ),
    ddk.Card(
        width=70,
        children=[
            # this content takes up 70% of the screen's width
        ]
    ),
    ddk.Card(
        width=50,
        children=[
             # this content wraps onto the next line
             # (below the cards above) and takes up 50%
             # of the screen's width
        ]
    )
])
```

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The list of components that are children of the Card container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- border_color (string; optional):
    The border color applied to the card. Overrides
    theme.card_border.color.

- border_radius (string; optional):
    The border radius applied to the card. Overrides
    theme.card_border.radius.

- border_style (string; optional):
    The border width applied to the card. Overrides
    theme.card_border.style.

- border_width (string; optional):
    The border width applied to the card. Overrides
    theme.card_border.width.

- box_shadow (string; optional):
    The box shadow(s) applied to the card. Overrides
    theme.card_box_shadow.

- card_hover (boolean; optional):
    Add a box-shadow to the card on hover.

- className (string; optional):
    Optional user-defined CSS class for the Card container.

- margin (number; optional):
    Space (in pixels) surrounding the card. Overrides
    theme.card_margin.

- modal_config (dict; optional):
    Object that takes 'width' and 'height' arguments to define modal
    dimensions Width or height can either be a string or a num N that
    gets converted to N%.

    `modal_config` is a dict with keys:

    - height (string | number; optional)

    - width (string | number; optional)

- padding (number; optional):
    Space (in pixels) on the inside of the card, between the border
    and the edge of the content. Overrides theme.card_padding.

- padding_inner (string; default '5px'):
    Space (in pixels) on the inside of the card content, between the
    bounding box of the content and the content itself.

- rounded (boolean; optional):
    Applies a border-radius to the card's border.

- shadow_weight (a value equal to: 'light', 'medium', 'heavy'; optional):
    The appearance of the card's box-shadow, if set.

- style (dict; optional):
    Optional additional CSS styles. - If `width`, `padding`, or
    `margin` are supplied within `style`, then this will override the
    component-level `width`, `padding`, or `margin`.

- type (a value equal to: 'shadow', 'color', 'simple-border', 'flat'; default 'shadow'):
    The appearance of the card's border.

- width (number; default 100):
    Number between 0 and 100 representing the width of the component
    with respect to its parent. - This is a percentage by default:
    `25` means take up 25% of the space. - Unless <1, in which it
    represents a decimal: 0.25 is the same as 25  Note that these
    units are different than the CSS `style` units where
    `style={'width': 25}` means _25 pixels_, not 25%."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, type=Component.UNDEFINED, shadow_weight=Component.UNDEFINED, card_hover=Component.UNDEFINED, modal_config=Component.UNDEFINED, rounded=Component.UNDEFINED, width=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, padding_inner=Component.UNDEFINED, box_shadow=Component.UNDEFINED, border_width=Component.UNDEFINED, border_style=Component.UNDEFINED, border_color=Component.UNDEFINED, border_radius=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'card_hover', 'className', 'margin', 'modal_config', 'padding', 'padding_inner', 'rounded', 'shadow_weight', 'style', 'type', 'width']
        self._type = 'Card'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'border_color', 'border_radius', 'border_style', 'border_width', 'box_shadow', 'card_hover', 'className', 'margin', 'modal_config', 'padding', 'padding_inner', 'rounded', 'shadow_weight', 'style', 'type', 'width']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Card, self).__init__(children=children, **args)
