# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class PageFooter(Component):
    """A PageFooter component.
The PageFooter component allows you to customize the content and style
within the bottom margin of your page. A default PageFooter will be included
in each Page with the dimensions specified by the `page_margin.bottom`, which 
can be set globally in the `ddk.Report` component or in an individual
Page component.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Page([
        ddk.Graph(
            figure = my_figure,
        ),
        # Place an italicized copyright message in the bottom margin
        ddk.PageFooter(
            'Copyright © 2020 Dash Enterprises, Inc. All Rights Reserved',
            style={'font-style': 'italic'}
        )
    ]),
])
```

Keyword arguments:

- children (boolean | number | string | dict | list; optional):
    The list of components that are children of the PageFooter
    container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the PageFooter container.

- className_page_number (string; optional):
    Optional user-defined CSS class for the PageFooter's page number
    child component.

- display_page_number (boolean; optional):
    Display the page number for the associated Page in this
    PageFooter.

- style (dict; optional):
    Overrides the default (inline) styles for the this component.

- style_page_number (dict; optional):
    Overrides the default (inline) styles for the this component's
    page number child element."""
    @_explicitize_args
    def __init__(self, children=None, display_page_number=Component.UNDEFINED, style=Component.UNDEFINED, style_page_number=Component.UNDEFINED, className_page_number=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'className_page_number', 'display_page_number', 'style', 'style_page_number']
        self._type = 'PageFooter'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'className_page_number', 'display_page_number', 'style', 'style_page_number']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(PageFooter, self).__init__(children=children, **args)
