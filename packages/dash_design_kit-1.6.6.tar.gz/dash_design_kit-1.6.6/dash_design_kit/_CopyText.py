# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class _CopyText(Component):
    """A CopyText component.
This component copies the innerText at the given id to the clipboard`

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The element that, when clicked, will copy the innerText of the given id
- id (string; optional): The optional id of the component
- className (string; optional): The optional className of the component
- target_id (string; optional): The id of the DOM element that contains the innerText to copy
- width (string | number; optional): The width of the element when expanded (% or px)
- setProps (boolean | number | string | dict | list; optional): Dash-assigned callback that gets fired when the value changes.
- style (dict; optional): Overrides the default (inline) styles for the this component."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, className=Component.UNDEFINED, target_id=Component.UNDEFINED, width=Component.UNDEFINED, style=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'target_id', 'width', 'setProps', 'style']
        self._type = 'CopyText'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'target_id', 'width', 'setProps', 'style']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(_CopyText, self).__init__(children=children, **args)
