# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Page(Component):
    """A Page component.
A component that describes a single page.
This component must be defined within the `children` of a ddk.Report.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Report(display_page_numbers=True, children=[
        ddk.Page([
            html.H1('Quarterly Earnings'),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x1', y='y1'
                ))
            ]),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x2', y='y2'
                ))
            ]),

            html.H2('Expected Returns'),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x2', y='y2'
                ))
            ]),
            ddk.Block(width=50, margin=5, children=[
                ddk.Graph(figure=px.scatter(
                    ddk.datasets.bubble(),
                    x='x1', y='y1'
                ))
            ]),
            ddk.PageFooter("Past Performance Is No Guarantee of Future Returns.")
        ]),
    ])
])
```

Keyword arguments:

- children (boolean | number | string | dict | list; optional):
    The list of components that are children of the Page container.

- id (string; optional):
    The ID of this component, used to identify Dash components in
    callbacks. The ID needs to be unique across all of the components
    in an app.

- className (string; optional):
    Optional user-defined CSS class for the Page container.

- display_page_number (boolean; optional):
    Display the page number for this particular Page in the
    PageFooter. Alternatively, set the page numbers for _all_ of the
    pages in the report with the `display_page_numbers` property in
    `ddk.Report`.

- page_margin (dict; optional):
    Set the (left, right, top, bottom) margin dimensions for this
    particular Page in units (`in`, `px`, `em`, etc.).

    `page_margin` is a dict with keys:

    - bottom (string; optional)

    - left (string; optional)

    - right (string; optional)

    - top (string; optional)

- style (dict; optional):
    Overrides the default (inline) styles for the this component."""
    @_explicitize_args
    def __init__(self, children=None, style=Component.UNDEFINED, className=Component.UNDEFINED, id=Component.UNDEFINED, display_page_number=Component.UNDEFINED, page_margin=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'display_page_number', 'page_margin', 'style']
        self._type = 'Page'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'display_page_number', 'page_margin', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Page, self).__init__(children=children, **args)
